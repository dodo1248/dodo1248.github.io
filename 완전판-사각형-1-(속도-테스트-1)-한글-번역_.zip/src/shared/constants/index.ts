import { MenuCategory, MenuItem } from '../types';

export const MAIN_CATEGORIES: MenuCategory[] = ['HEART 메인 (메인 안주 1)', 'WATT 메인 (메인 안주 2)'];

// Time-based thresholds in minutes for staff UI warnings.
export const ORDER_OVERDUE_THRESHOLD_MINUTES = 5;
export const ORDER_CRITICAL_THRESHOLD_MINUTES = 10;
export const TABLE_CLEAR_WARNING_THRESHOLD_MINUTES = 15;

// --- Application Configuration ---
// Polling intervals in milliseconds
export const CUSTOMER_POLL_INTERVAL = 7000;

// UI Behavior
export const NEW_ORDER_FLASH_DURATION = 2500; // Duration for the new order card flash animation

// Validation
export const MAX_TABLE_NUMBER = 60;
export const MAX_ORDER_REQUEST_LENGTH = 50;
export const STAFF_PIN_LENGTH = 6;
export const CUSTOMER_PIN_LENGTH = 4;


// Centralized keys for localStorage and sessionStorage
export const STORAGE_KEYS = {
  // Local Storage
  DARK_MODE: 'hbwatt_dark_mode',
  // Session Storage
  APP_MODE: 'hbwatt_app_mode',
  TABLE: 'hbwatt_table',
  LATEST_ORDER: 'hbwatt_latest_order',
  STAFF_LOGGED_IN: 'hbwatt_staff',
  STAFF_ROLE: 'hbwatt_staff_role',
  STAFF_ACTIVE_PAGE: 'hbwatt_staff_active_page',
  HAS_ORDERED_PREFIX: 'hbwatt_has_ordered_',
  REORDER_ITEM: 'hbwatt_reorder_item',
};


// MENU_DATA is provided for fallback purposes, but the primary source of truth is the Google Sheet.
export const MENU_DATA: (Omit<MenuItem, 'isSoldOut' | 'category'> & { category: string })[] = [
  // HEART 메인
  { id: 1, name: '골뱅이 무침 & 납작만두', price: 22900, category: 'HEART 메인 (메인 안주 1)', imageUrl: 'https://picsum.photos/seed/hbw_menu1/400/300' },
  { id: 2, name: '두부대패김치', price: 22900, category: 'HEART 메인 (메인 안주 1)', imageUrl: 'https://picsum.photos/seed/hbw_menu2/400/300' },
  // WATT 메인
  { id: 3, name: '닭꼬치 (8개)', price: 19900, category: 'WATT 메인 (메인 안주 2)', imageUrl: 'https://picsum.photos/seed/hbw_menu3/400/300' },
  { id: 4, name: '치즈김치전', price: 19900, category: 'WATT 메인 (메인 안주 2)', imageUrl: 'https://picsum.photos/seed/hbw_menu4/400/300' },
  // BEAT 사이드
  { id: 5, name: '나쵸', price: 9900, category: 'BEAT 사이드 (사이드 안주)', imageUrl: 'https://picsum.photos/seed/hbw_menu5/400/300' },
  { id: 6, name: '콘치즈', price: 9900, category: 'BEAT 사이드 (사이드 안주)', imageUrl: 'https://picsum.photos/seed/hbw_menu6/400/300' },
  { id: 7, name: '꿀토마토', price: 9900, category: 'BEAT 사이드 (사이드 안주)', imageUrl: 'https://picsum.photos/seed/hbw_menu7/400/300' },
  // 기타
  { id: 8, name: '국물라면 (봉지)', price: 5000, category: '기타 (라면 및 음료)', imageUrl: 'https://picsum.photos/seed/hbw_menu8/400/300' },
  { id: 9, name: '불닭 (큰컵)', price: 4000, category: '기타 (라면 및 음료)', imageUrl: 'https://picsum.photos/seed/hbw_menu9/400/300' },
  { id: 10, name: '콜라/사이다 뚱캔', price: 2500, category: '기타 (라면 및 음료)', imageUrl: 'https://picsum.photos/seed/hbw_menu10/400/300' },
  { id: 11, name: '물', price: 1000, category: '기타 (라면 및 음료)', imageUrl: 'https://picsum.photos/seed/hbw_menu11/400/300' },
];

export const KAKAO_QR_CODE_BASE64 = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';