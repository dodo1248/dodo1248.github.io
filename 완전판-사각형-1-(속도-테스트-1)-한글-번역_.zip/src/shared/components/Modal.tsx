import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title: string;
  footer?: React.ReactNode;
}

const modalRoot = typeof document !== 'undefined' ? document.body : null;

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, title, footer }) => {
  useEffect(() => {
    const originalOverflow = window.getComputedStyle(document.body).overflow;
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen]);

  if (!isOpen || !modalRoot) {
    return null;
  }

  const modalContent = (
    <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-lg z-50 flex items-center justify-center p-4"
        style={{ animation: 'modal-fade-in 0.2s ease-out' }}
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
    >
      <div 
        className="relative bg-white/95 dark:bg-gray-900/90 backdrop-blur-2xl rounded-3xl shadow-2xl w-full max-w-md m-auto border border-white/20 dark:border-pink-500/20 flex flex-col max-h-[90vh]" 
        onClick={e => e.stopPropagation()}
      >
        <div className="p-4 border-b border-pink-100 dark:border-pink-900/50 flex justify-between items-center flex-shrink-0">
          <h3 id="modal-title" className="text-xl font-bold text-gray-800 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-800 dark:hover:text-white text-3xl w-8 h-8 flex items-center justify-center rounded-full transition-colors" aria-label="닫기">&times;</button>
        </div>
        <div className="flex-1 p-4 md:p-6 overflow-y-auto min-h-0">
            {children}
        </div>
        {footer && (
            <div className="p-4 md:p-6 border-t border-pink-100 dark:border-pink-900/50 flex-shrink-0">
                {footer}
            </div>
        )}
      </div>
    </div>
  );
  
  return createPortal(modalContent, modalRoot);
};