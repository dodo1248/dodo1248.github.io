import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
    children: React.ReactNode;
    className?: string;
    padding?: string;
}
export const Card: React.FC<CardProps> = ({ children, className = '', padding = 'p-6', ...props }) => {
    return (
        <div className={`bg-gray-950/70 backdrop-blur-2xl rounded-3xl shadow-lg shadow-black/40 ${padding} ${className} transition-all duration-300 border border-pink-500/30`} {...props}>
            {children}
        </div>
    );
}