import React from 'react';

interface ToastProps {
  message: string;
  show: boolean;
  type?: 'success' | 'error';
}

export const Toast: React.FC<ToastProps> = ({ message, show, type = 'success' }) => {
  const bgColor = type === 'success' 
    ? 'bg-rose-500 dark:bg-rose-600' 
    : 'bg-red-500 dark:bg-red-600';
    
  const shadowColor = type === 'success' 
    ? 'shadow-rose-400/50'
    : 'shadow-red-400/50';

  return (
    <div className={`fixed bottom-24 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full text-white font-bold shadow-lg dark:shadow-lg ${shadowColor} transition-all duration-300 z-50 ${bgColor} ${show ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5 pointer-events-none'}`}>
      {message}
    </div>
  )
}