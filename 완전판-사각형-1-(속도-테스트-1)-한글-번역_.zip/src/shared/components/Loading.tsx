import React, { useState, useEffect } from 'react';

const funLoadingMessages = [
    "주방의 불을 켜고 있어요... 🔥",
    "오늘의 추천 메뉴를 고르는 중... 🤔",
    "맛있는 냄새가 솔솔~ 잠시만 기다려주세요!",
    "사장님 몰래 서비스를 준비하고 있어요! 😉",
    "HEART Beat WATT 입장 중..."
];

export const Loading: React.FC<{ message?: string }> = ({ message = '불러오는 중...' }) => {
    const [dynamicMessage, setDynamicMessage] = useState(message);

    useEffect(() => {
        // Only show fun messages for the generic initial load.
        if (message === '영업 정보를 불러오는 중...' || message === '불러오는 중...') {
            setDynamicMessage(funLoadingMessages[0]);
            let i = 1;
            const interval = setInterval(() => {
                setDynamicMessage(funLoadingMessages[i % funLoadingMessages.length]);
                i++;
            }, 2000); // Change message every 2 seconds

            return () => clearInterval(interval);
        } else {
            // If a specific message is provided, just show that.
            setDynamicMessage(message);
        }
    }, [message]);

    return (
        <div className="flex flex-col items-center justify-center p-8 text-gray-600 dark:text-gray-300 min-h-[200px]">
            <svg className="animate-spin h-10 w-10 text-[#ef7490] mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="text-lg font-medium text-center">{dynamicMessage}</p>
        </div>
    );
};