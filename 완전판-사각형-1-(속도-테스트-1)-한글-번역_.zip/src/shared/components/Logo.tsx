import React from 'react';

interface LogoProps {
  size?: 'large' | 'medium';
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'medium', className = '' }) => {
  const isLarge = size === 'large';

  const containerSize = isLarge ? 'w-[360px]' : 'w-[280px]';
  const heartTextSize = isLarge ? 'text-7xl' : 'text-5xl';
  const scriptTextSize = isLarge ? 'text-5xl' : 'text-3xl';
  const scriptMargin = isLarge ? '-my-2' : '-my-1';

  // Enhanced neon effect for the dark theme
  const textShadow = '0 0 25px rgba(239, 116, 144, 0.7), 0 0 10px rgba(255, 255, 255, 0.8), 0 0 4px rgba(255, 59, 129, 0.9)';
  
  const textColor = 'text-white';

  return (
    <div className={`relative flex items-center justify-center ${containerSize} ${className}`}>
      {/* New Neon Frame SVG */}
      <svg className="w-full h-auto absolute" viewBox="0 0 160 160">
        <defs>
          <filter id="neon-yellow-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor="#fef08a" />
          </filter>
          <filter id="neon-pink-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor="#ff3b81" />
          </filter>
        </defs>
        
        {/* Outer pink frame */}
        <rect 
            x="15" y="15" width="130" height="130" rx="20" 
            fill="none" stroke="#ff3b81" strokeWidth="2" 
            style={{ filter: 'url(#neon-pink-glow)' }} 
        />
        
        {/* Inner yellow frame */}
        <rect 
            x="22" y="22" width="116" height="116" rx="15" 
            fill="none" stroke="#facc15" strokeWidth="2" 
            style={{ filter: 'url(#neon-yellow-glow)' }}
        />
      </svg>
      
      {/* Text inside (UNCHANGED) */}
      <div
        className={`relative ${textColor} flex flex-col items-center justify-center leading-tight`}
        style={{ textShadow }}
      >
        <span className={`font-display tracking-widest ${heartTextSize}`}>HEART</span>
        <span className={`font-script ${scriptTextSize} ${scriptMargin}`}>Beat</span>
        <span className={`font-display tracking-widest ${heartTextSize}`}>WATT</span>
      </div>
    </div>
  );
};