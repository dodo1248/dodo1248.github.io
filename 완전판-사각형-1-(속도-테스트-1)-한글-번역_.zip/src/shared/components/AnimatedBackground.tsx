import React from 'react';

const ghostDataUrl = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 120'%3E%3Cpath d='M95,115 C95,95 90,80 80,70 C70,60 60,50 50,20 C40,50 30,60 20,70 C10,80 5,95 5,115 Z' fill='rgba(255,255,255,0.8)'/%3E%3Ccircle cx='35' cy='65' r='6' fill='black'/%3E%3Ccircle cx='65' cy='65' r='6' fill='black'/%3E%3C/svg%3E";

const Silhouette = () => (
    <div className="absolute bottom-0 left-0 w-full h-1/3 opacity-80" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%2304010d' fill-opacity='1' d='M0,224L48,229.3C96,235,192,245,288,218.7C384,192,480,128,576,128C672,128,768,192,864,218.7C960,245,1056,235,1152,208C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z'%3E%3C/path%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'bottom' }}>
        <svg viewBox="0 0 800 200" className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-auto max-w-4xl" preserveAspectRatio="xMidYMax meet">
            {/* Trees */}
            <path d="M 50 180 C 50 160, 40 140, 60 120 L 65 115 L 70 120 C 90 140, 80 160, 80 180 Z" fill="#04010d" />
            <path d="M 700 180 C 700 150, 680 120, 710 90 L 715 85 L 720 90 C 750 120, 730 150, 730 180 Z" fill="#04010d" />
            <path d="M 120 180 C 120 160, 110 150, 130 140 L 135 138 L 140 140 C 160 150, 150 160, 150 180 Z" fill="#04010d" />
            {/* House */}
            <path d="M 350 180 L 350 80 L 400 50 L 450 80 L 450 180 Z M 380 180 L 380 130 L 420 130 L 420 180 Z M 460 180 L 460 110 L 490 110 L 490 180 Z M 340 180 L 340 120 L 310 120 L 310 180 Z" fill="#04010d" />
        </svg>
    </div>
);


const Fireworks: React.FC = () => {
    return <>
        {[...Array(5)].map((_, i) => {
            const size = 50 + Math.random() * 50;
            const top = `${10 + Math.random() * 40}%`;
            const left = `${10 + Math.random() * 80}%`;
            const duration = `${1.5 + Math.random() * 1.5}s`;
            const delay = `${Math.random() * 5}s`;

            return <div key={i} className="absolute opacity-0" style={{ top, left, width: `${size}px`, height: `${size}px`, animation: `fireworks-1 ${duration} ${delay} ease-out infinite` }}>
                <div className="absolute inset-0 rounded-full" style={{ boxShadow: `0 0 10px 2px #FFD700, inset 0 0 5px 1px #FFD700` }} />
            </div>
        })}
        {[...Array(5)].map((_, i) => {
            const size = 60 + Math.random() * 60;
            const top = `${5 + Math.random() * 30}%`;
            const left = `${10 + Math.random() * 80}%`;
            const duration = `${2 + Math.random() * 2}s`;
            const delay = `${1 + Math.random() * 6}s`;

            return <div key={i+5} className="absolute opacity-0" style={{ top, left, width: `${size}px`, height: `${size}px`, animation: `fireworks-1 ${duration} ${delay} ease-out infinite` }}>
                <div className="absolute inset-0 rounded-full" style={{ boxShadow: `0 0 10px 2px #F43F5E, inset 0 0 5px 1px #F43F5E` }} />
            </div>
        })}
    </>;
};

const Ghosts: React.FC = () => {
    const ghostStyles: React.CSSProperties[] = [
        { top: '30%', left: '-10%', width: '80px', height: '100px', animation: `ghost-float 8s ease-in-out infinite, linear 25s 0s infinite forwards`},
        { top: '50%', left: '-10%', width: '60px', height: '75px', animation: `ghost-float 7s ease-in-out infinite, linear 20s 5s infinite forwards`},
        { top: '20%', left: '-10%', width: '70px', height: '88px', animation: `ghost-float 9s ease-in-out infinite, linear 30s 10s infinite forwards` },
    ];
    
    return <>
        <style>{`
            @keyframes linear { 
                from { transform: translateX(0vw); } 
                to { transform: translateX(110vw); } 
            }
        `}</style>
        {ghostStyles.map((style, i) => (
            <div key={i} className="absolute" style={{
                backgroundImage: `url('${ghostDataUrl}')`,
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                ...style
            }}/>
        ))}
    </>;
};

// --- New Components for Night Sky Theme ---

const createStars = (selector: string, size: string) => {
    const starCount = 200;
    let styles = '';
    for (let i = 0; i < starCount; i++) {
        styles += `${Math.random() * 2000}px ${Math.random() * 2000}px ${size} ${size} rgba(255,255,255,${Math.random() * 0.5 + 0.5}),`;
    }
    return `${selector} { box-shadow: ${styles.slice(0, -1)}; }`;
};

const TwinklingStars: React.FC = () => (
    <>
        <style>{`
            .stars {
                position: absolute;
                top: 0; left: 0;
                border-radius: 50%;
                animation: twinkle-anim linear infinite;
                will-change: transform;
            }
            ${createStars('.stars1', '1px')}
            ${createStars('.stars2', '2px')}
            ${createStars('.stars3', '3px')}
        `}</style>
        <div className="stars stars1" style={{ width: '1px', height: '1px', animationDuration: '50s' }}></div>
        <div className="stars stars2" style={{ width: '2px', height: '2px', animationDuration: '100s' }}></div>
        <div className="stars stars3" style={{ width: '3px', height: '3px', animationDuration: '150s' }}></div>
    </>
);

const Nebula: React.FC = () => (
    <div className="absolute inset-[-50vmin] opacity-30 dark:opacity-40" style={{ animation: 'nebula-spin 120s linear infinite' }}>
        <div 
            className="absolute inset-[50vmin]"
            style={{
                backgroundImage: 'radial-gradient(ellipse at 70% 30%, rgba(236, 72, 153, 0.3), transparent 50%), radial-gradient(ellipse at 30% 70%, rgba(124, 58, 237, 0.2), transparent 50%)'
            }}
        />
    </div>
);


export const AnimatedBackground: React.FC = () => {
  // Always use the dark, Halloween-themed background.
  const backgroundColor = '#0A051A';

  return (
    <div style={{ backgroundColor }} className="fixed inset-0 overflow-hidden -z-10">
        <Nebula />
        <TwinklingStars />
        <Fireworks />
        <Ghosts />
        <Silhouette />
        <div className="absolute top-1/2 left-1/2 w-[80vmin] h-[80vmin] bg-[radial-gradient(ellipse_at_center,rgba(239,116,144,0.15)_0%,transparent_70%)] animate-pulse"></div>
    </div>
  );
};