// A tiny (239B) utility for constructing className strings conditionally.
// This is a common utility in modern frontend development for cleaner code.
export const clsx = (...args: (string | boolean | null | undefined | Record<string, boolean | null | undefined>)[]) => {
  let str = '';
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (!arg) continue;

    if (typeof arg === 'string') {
      str && (str += ' ');
      str += arg;
    } else if (typeof arg === 'object') {
      for (const key in arg) {
        if (arg[key]) {
          str && (str += ' ');
          str += key;
        }
      }
    }
  }
  return str;
};
