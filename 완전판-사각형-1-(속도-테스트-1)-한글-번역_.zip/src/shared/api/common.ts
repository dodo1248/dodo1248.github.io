// This file is deprecated and its contents have been removed.
// The application now uses the Supabase client for all API requests.
// See src/shared/api/supabaseClient.ts
