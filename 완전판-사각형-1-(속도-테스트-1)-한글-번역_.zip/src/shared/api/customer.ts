import { MenuItem, Order, CartItem, PaymentInfo, OrderStatus, TableStatus } from '../types';
import { supabase } from './supabaseClient';
import { formatMenuItem, formatPaymentInfo, formatOrder } from './formatters';

interface CheckTableStatusResponse {
  status: TableStatus;
  pinIsSet: boolean;
  mainTableNumber?: number;
}

const handleError = (error: any, context: string) => {
    // Log the raw error for developer debugging.
    console.error(`[Supabase API Error] ${context}:`, error);

    let message = '알 수 없는 오류가 발생했습니다.';

    if (supabase.supabaseUrl.includes('placeholder.supabase.co')) {
        message = 'Supabase URL/Key 환경 변수가 설정되지 않았습니다. 앱이 데이터베이스에 연결할 수 없습니다.';
        throw new Error(`[${context}] ${message}`);
    }

    // Try to extract a meaningful message from various error formats
    if (error && typeof error === 'object') {
        // Standard Supabase PostgrestError or similar object with a `message` property.
        if (typeof error.message === 'string' && error.message.trim() !== '') {
            message = error.message;
            if (typeof error.details === 'string' && error.details) message += `\n\n세부 정보: ${error.details}`;
            if (typeof error.hint === 'string' && error.hint) message += `\n힌트: ${error.hint}`;
        }
        // Network errors often don't have a structured message
        else if (String(error).toLowerCase().includes('failed to fetch') || String(error).toLowerCase().includes('networkerror')) {
            message = '네트워크 요청에 실패했습니다. 인터넷 연결을 확인해주세요.';
        }
        // Fallback for other objects: try to stringify to get more details
        else {
             try {
                const errorString = JSON.stringify(error);
                if (errorString !== '{}' && errorString !== 'null') {
                    // Provide a more structured message for object-based errors
                    message = `서버에서 오류 응답을 받았습니다. 세부 정보: ${errorString}`;
                } else {
                    message = '빈 오류 객체가 수신되었습니다. 개발자 콘솔을 확인해주세요.';
                }
            } catch {
                message = '오류 객체를 문자열로 변환할 수 없습니다 (순환 참조 가능). 개발자 콘솔을 확인해주세요.';
            }
        }
    } 
    // Handle generic JS Error objects
    else if (error instanceof Error) {
        message = error.message;
    } 
    // Handle plain strings
    else if (typeof error === 'string' && error.trim() !== '') {
        message = error;
    }
    
    // Final check to prevent '[object Object]' if all else fails.
    if (message === '[object Object]') {
        message = '오류 객체를 분석할 수 없습니다. 개발자 콘솔을 확인해주세요.';
    }

    throw new Error(`[${context}] ${message}`);
};

export const customerApi = {
  fetchInitialData: async (): Promise<{ menu: MenuItem[]; operatingDay: 1 | 2; paymentInfo: PaymentInfo }> => {
    const [menuRes, dayRes, paymentRes] = await Promise.all([
        supabase.from('menu_items').select('*').order('id'),
        supabase.from('settings').select('value').eq('key', 'operating_day').single(),
        supabase.from('settings').select('value').eq('key', 'payment_info').single()
    ]);

    if (menuRes.error) handleError(menuRes.error, '메뉴 정보 조회');
    if (dayRes.error) handleError(dayRes.error, '운영일 정보 조회');
    if (paymentRes.error) handleError(paymentRes.error, '결제 정보 조회');

    const rawMenuData = menuRes.data || [];
    // Deduplicate menu items by name to prevent display issues from duplicate data entries.
    // The last item with a given name will be used.
    const uniqueMenuItems = Array.from(new Map(rawMenuData.map(item => [item.name, item])).values());

    return {
      menu: uniqueMenuItems.map(formatMenuItem).sort((a, b) => a.id - b.id), // Also sort by ID for consistent order
      operatingDay: (dayRes.data?.value as any)?.day || 1,
      paymentInfo: formatPaymentInfo((paymentRes.data?.value as any) || {}),
    };
  },
  placeOrder: async (day: 1 | 2, tableNumber: number, items: CartItem[], request?: string): Promise<Order> => {
    const cartForRpc = items.map(item => ({
        menu_item_id: item.id,
        quantity: item.quantity
    }));

    const { data: orderId, error } = await supabase.rpc('create_order', {
        p_table_number: tableNumber,
        p_cart: cartForRpc,
        p_request: request
    });

    if (error) handleError(error, '주문 생성');
    if (!orderId) throw new Error("주문 생성 후 ID를 받지 못했습니다.");

    // The function already created the order, now we just need to construct the object to return to the UI
    const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const newOrder: Order = {
        id: orderId,
        tableNumber,
        items: items.map(item => ({ ...item, status: OrderStatus.PENDING_PAYMENT, uniqueId: `${orderId}-${item.id}` })),
        totalPrice,
        status: OrderStatus.PENDING_PAYMENT,
        timestamp: Date.now(),
        isActive: true,
        request
    };
    return newOrder;
  },
  submitPayment: async (orderId: string): Promise<void> => {
    const { error } = await supabase.rpc('submit_payment_for_order', { p_order_id: orderId });
    if (error) handleError(error, '결제 제출');
  },
  callStaff: async (day: 1 | 2, tableNumber: number, reason: string): Promise<void> => {
    const { error } = await supabase.rpc('customer_call_staff', {
        p_table_number: tableNumber,
        p_reason: reason
    });
    if (error) handleError(error, '스태프 호출');
  },
  cancelOrder: async (day: 1 | 2, orderId: string): Promise<void> => {
    const { error } = await supabase
        .from('orders')
        .update({ status: OrderStatus.CANCELLED, is_active: false })
        .eq('id', orderId);
     if (error) handleError(error, '주문 취소');
  },
  pollCustomerData: async (tableNumber: number): Promise<{ orders: Order[]; operatingDay: 1 | 2, mergedTables: number[] }> => {
    // 1. Fetch operating day in parallel
    const dayResPromise = supabase.from('settings').select('value').eq('key', 'operating_day').single();

    // 2. Find the group of tables the current table belongs to.
    const { data: currentTableInfo, error: tableInfoError } = await supabase
        .from('tables')
        .select('merged_with, is_main_table')
        .eq('table_number', tableNumber)
        .single();
    
    if (tableInfoError) handleError(tableInfoError, '테이블 그룹 정보 조회');

    const mainTableNumber = currentTableInfo?.merged_with || (currentTableInfo?.is_main_table ? tableNumber : tableNumber);
    
    const { data: subTables, error: subTablesError } = await supabase
        .from('tables')
        .select('table_number')
        .eq('merged_with', mainTableNumber);
        
    if (subTablesError) handleError(subTablesError, '합석 서브 테이블 조회');

    const subTableNumbers = subTables?.map(t => t.table_number) || [];
    const tableNumbersInGroup = [...new Set([mainTableNumber, ...subTableNumbers])];
    
    // 3. Fetch all active orders for that group of tables (without items yet).
    const ordersResPromise = supabase
        .from('orders')
        .select('*')
        .in('table_number', tableNumbersInGroup)
        .eq('is_active', true);
    
    // 4. Await parallel promises
    const [dayRes, ordersRes] = await Promise.all([dayResPromise, ordersResPromise]);
    
    if (dayRes.error) handleError(dayRes.error, '운영일 폴링');
    if (ordersRes.error) handleError(ordersRes.error, '주문 폴링');
    
    const ordersData = ordersRes.data || [];
    let ordersWithItems: any[] = [];

    if (ordersData.length > 0) {
        // Fetch all related order_items for the retrieved orders.
        const orderIds = ordersData.map(o => o.id);
        const { data: orderItemsData, error: orderItemsError } = await supabase
            .from('order_items')
            .select('*')
            .in('order_id', orderIds);
        
        if (orderItemsError) handleError(orderItemsError, '주문 항목 폴링');

        // Manually join them in the application code.
        ordersWithItems = ordersData.map(order => ({
            ...order,
            order_items: orderItemsData ? orderItemsData.filter(item => item.order_id === order.id) : [],
        }));
    }

    return {
      operatingDay: (dayRes.data?.value as any)?.day || 1,
      orders: ordersWithItems.map(formatOrder).filter((o): o is Order => o !== null),
      mergedTables: tableNumbersInGroup.sort((a,b) => a-b),
    };
  },
  checkTableStatus: async (tableNumber: number): Promise<CheckTableStatusResponse> => {
    const { data, error } = await supabase.from('tables').select('status, pin_hash, merged_with').eq('table_number', tableNumber).single();
    if (error) handleError(error, '테이블 상태 확인');
    return {
        status: data.status as TableStatus,
        pinIsSet: !!data.pin_hash,
        mainTableNumber: data.merged_with || undefined,
    };
  },
  setTablePin: async (tableNumber: number, pin: string): Promise<void> => {
    const { error } = await supabase.rpc('tables_set_pin', {
        p_table_number: tableNumber,
        p_pin: pin
    });
    if (error) handleError(error, '테이블 PIN 설정');
  },
  verifyTablePin: async (tableNumber: number, pin: string): Promise<{ isValid: boolean }> => {
    const { data, error } = await supabase.rpc('tables_verify_pin', {
        p_table_number: tableNumber,
        p_pin: pin
    });
    if (error) handleError(error, '테이블 PIN 확인');
    return { isValid: !!data };
  },
};