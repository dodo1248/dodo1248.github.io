import { MenuItem, Order, CartItem, Table, PaymentInfo, MenuCategory, TableStatus, OrderStatus } from '../types';

// Data Formatting Helpers for robustly converting Supabase data to frontend types.

export const formatMenuItem = (item: any): MenuItem => {
    return {
        id: Number(item.id) || 0,
        name: item.name,
        price: Number(item.price) || 0,
        category: item.category as MenuCategory,
        isSoldOut: item.is_sold_out || false,
        imageUrl: item.image_url,
    };
};

export const formatPaymentInfo = (info: any): PaymentInfo => ({
    qrCodeUrl: info.qr_code_url || '',
    accountNumber: info.account_number || '',
});

export const formatOrder = (order: any): Order | null => {
    const tableNumber = Number(order.table_number);
    if (isNaN(tableNumber) || tableNumber <= 0) {
        console.warn(`[Data Integrity] Received order with invalid table_number. Ignoring order.`, order);
        return null;
    }

    const items: CartItem[] = Array.isArray(order.order_items) ? order.order_items.map((item: any) => ({
        id: Number(item.menu_item_id) || 0,
        name: item.name,
        price: Number(item.price) || 0,
        quantity: Number(item.quantity) || 0,
        category: item.category as MenuCategory,
        status: item.status as OrderStatus,
        uniqueId: item.unique_id,
    })) : [];
    
    const timestampValue = order.timestamp || order.created_at;
    const time = timestampValue ? new Date(timestampValue).getTime() : 0;

    return {
        id: order.id, 
        tableNumber: tableNumber,
        items: items,
        totalPrice: Number(order.total_price) || 0,
        status: order.status as OrderStatus,
        timestamp: !isNaN(time) ? time : 0, 
        isActive: order.is_active,
        memo: order.memo,
        request: order.request,
        cancellationReason: order.cancellation_reason,
    };
};

export const formatTable = (table: any): Table | null => {
    const tableNumber = Number(table.table_number);
    if (isNaN(tableNumber) || tableNumber <= 0) {
        console.warn(`[Data Integrity] Received table update with invalid table_number. Ignoring.`, table);
        return null;
    }
    const updatedAtTime = table.updated_at ? new Date(table.updated_at).getTime() : 0;
    return {
        tableNumber: tableNumber,
        status: table.status as TableStatus,
        reason: table.reason,
        pinHash: table.pin_hash,
        mergedWith: table.merged_with ? Number(table.merged_with) : undefined,
        isMainTable: table.is_main_table || false,
        updatedAt: !isNaN(updatedAtTime) ? updatedAtTime : undefined,
    };
};