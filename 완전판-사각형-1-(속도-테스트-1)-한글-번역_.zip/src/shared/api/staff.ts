import { MenuItem, Order, Table, TableStatus, OrderStatus } from '../types';
import { supabase } from './supabaseClient';
import { formatMenuItem, formatOrder, formatTable } from './formatters';

const handleError = (error: any, context: string) => {
    // Log the raw error for developer debugging.
    console.error(`[Supabase API Error] ${context}:`, error);

    let message = '알 수 없는 오류가 발생했습니다.';

    if (supabase.supabaseUrl.includes('placeholder.supabase.co')) {
        message = 'Supabase URL/Key 환경 변수가 설정되지 않았습니다. 앱이 데이터베이스에 연결할 수 없습니다.';
        throw new Error(`[${context}] ${message}`);
    }

    // Try to extract a meaningful message from various error formats
    if (error && typeof error === 'object') {
        // Standard Supabase PostgrestError or similar object with a `message` property.
        if (typeof error.message === 'string' && error.message.trim() !== '') {
            message = error.message;
            if (typeof error.details === 'string' && error.details) message += `\n\n세부 정보: ${error.details}`;
            if (typeof error.hint === 'string' && error.hint) message += `\n힌트: ${error.hint}`;
        }
        // Network errors often don't have a structured message
        else if (String(error).toLowerCase().includes('failed to fetch') || String(error).toLowerCase().includes('networkerror')) {
            message = '네트워크 요청에 실패했습니다. 인터넷 연결을 확인해주세요.';
        }
        // Fallback for other objects: try to stringify to get more details
        else {
             try {
                const errorString = JSON.stringify(error);
                if (errorString !== '{}' && errorString !== 'null') {
                    // Provide a more structured message for object-based errors
                    message = `서버에서 오류 응답을 받았습니다. 세부 정보: ${errorString}`;
                } else {
                    message = '빈 오류 객체가 수신되었습니다. 개발자 콘솔을 확인해주세요.';
                }
            } catch {
                message = '오류 객체를 문자열로 변환할 수 없습니다 (순환 참조 가능). 개발자 콘솔을 확인해주세요.';
            }
        }
    } 
    // Handle generic JS Error objects
    else if (error instanceof Error) {
        message = error.message;
    } 
    // Handle plain strings
    else if (typeof error === 'string' && error.trim() !== '') {
        message = error;
    }
    
    // Final check to prevent '[object Object]' if all else fails.
    if (message === '[object Object]') {
        message = '오류 객체를 분석할 수 없습니다. 개발자 콘솔을 확인해주세요.';
    }

    throw new Error(`[${context}] ${message}`);
};

// All write operations are now wrapped in RPC calls to functions
// that should be defined in the database with SECURITY DEFINER
// to bypass RLS policies for authenticated staff roles.

export const staffApi = {
  fetchStaffData: async (day: 1 | 2): Promise<{ menu: MenuItem[]; orders: Order[]; operatingDay: 1 | 2; tables: Table[]; currentTimestamp: number }> => {
    // Step 1: Fetch main tables without joins
    const [menuRes, ordersResWithoutItems, tablesRes, dayRes] = await Promise.all([
        supabase.from('menu_items').select('*').order('id'),
        supabase.from('orders').select('*').eq('operating_day', day),
        supabase.from('tables').select('*').order('table_number'),
        supabase.from('settings').select('value').eq('key', 'operating_day').single()
    ]);

    if (menuRes.error) handleError(menuRes.error, '메뉴 정보 조회');
    if (ordersResWithoutItems.error) handleError(ordersResWithoutItems.error, '주문 정보 조회');
    if (tablesRes.error) handleError(tablesRes.error, '테이블 정보 조회');
    if (dayRes.error) handleError(dayRes.error, '운영일 정보 조회');

    const ordersData = ordersResWithoutItems.data || [];
    let ordersWithItems: any[] = [];

    if (ordersData.length > 0) {
        // Step 2: Fetch all related order_items for all orders of the day, in batches to prevent URL length issues.
        const orderIds = ordersData.map(o => o.id);
        let allOrderItems: any[] = [];
        const batchSize = 200; // A safe batch size for the .in() filter

        for (let i = 0; i < orderIds.length; i += batchSize) {
            const batchIds = orderIds.slice(i, i + batchSize);
            const { data: orderItemsData, error: orderItemsError } = await supabase
                .from('order_items')
                .select('*')
                .in('order_id', batchIds);
            
            if (orderItemsError) handleError(orderItemsError, '주문 항목 조회 (배치)');
            if (orderItemsData) {
                allOrderItems.push(...orderItemsData);
            }
        }
        
        // Step 3: Manually join them
        ordersWithItems = ordersData.map(order => ({
            ...order,
            order_items: allOrderItems.filter(item => item.order_id === order.id),
        }));
    }

    // Deduplicate menu items by name, similar to the customer API, for consistency.
    const rawMenuData = menuRes.data || [];
    const uniqueMenuItems = Array.from(new Map(rawMenuData.map(item => [item.name, item])).values());

    return {
      menu: uniqueMenuItems.map(formatMenuItem).sort((a, b) => a.id - b.id),
      orders: ordersWithItems.map(formatOrder).filter((o): o is Order => o !== null),
      tables: (tablesRes.data || []).map(formatTable).filter((t): t is Table => t !== null),
      operatingDay: (dayRes.data?.value as any)?.day || 1,
      currentTimestamp: Date.now(),
    }
  },
  resolveCall: async (tableNumber: number): Promise<void> => {
    const { error } = await supabase.rpc('staff_resolve_call', { p_table_number: tableNumber });
    if (error) handleError(error, '호출 해결');
  },
  updateMenuSoldOut: async (itemId: number, isSoldOut: boolean): Promise<void> => {
    const { error } = await supabase.rpc('staff_update_menu_sold_out', { p_item_id: itemId, p_is_sold_out: isSoldOut });
    if (error) handleError(error, '메뉴 품절 상태 변경');
  },
  updateOrderStatus: async (orderId: string, status: OrderStatus): Promise<void> => {
    const { error } = await supabase.rpc('staff_update_order_status', { p_order_id: orderId, p_status: status });
    if (error) handleError(error, '주문 상태 변경');
  },
  updateOrderItemStatus: async (itemUniqueId: string, status: OrderStatus): Promise<void> => {
    const { error } = await supabase.rpc('staff_update_order_item_status', { p_item_unique_id: itemUniqueId, p_status: status });
    if (error) handleError(error, '주문 항목 상태 변경');
  },
  addOrderMemo: async (orderId: string, memo: string): Promise<void> => {
    const { error } = await supabase.rpc('staff_add_order_memo', { p_order_id: orderId, p_memo: memo });
    if (error) handleError(error, '주문 메모 추가');
  },
  setOperatingDay: async (day: 1 | 2): Promise<{ operatingDay: 1 | 2 }> => {
    // settings table should be writable by manager role.
    const { error } = await supabase.from('settings').upsert({ key: 'operating_day', value: { day } });
    if (error) handleError(error, '운영일 변경');
    return { operatingDay: day };
  },
  cancelOrder: async (orderId: string, reason?: string): Promise<void> => {
    const { error } = await supabase.rpc('staff_cancel_order', { p_order_id: orderId, p_reason: reason });
    if (error) handleError(error, '주문 취소');
  },
  clearTable: async (tableNumber: number): Promise<void> => {
    const { error } = await supabase.rpc('staff_clear_table', { p_table_number: tableNumber });
    if (error) handleError(error, '테이블 정리');
  },
  mergeTables: async (mainTableNumber: number, subTableNumbers: number[], pin: string): Promise<void> => {
    const { error } = await supabase.rpc('staff_merge_tables', {
      p_main_table_number: mainTableNumber,
      p_sub_table_numbers: subTableNumbers,
      p_pin: pin,
    });
    if (error) handleError(error, '테이블 합석');
  },
  unmergeTables: async (tableNumber: number): Promise<void> => {
    const { error } = await supabase.rpc('staff_unmerge_tables', { p_table_number: tableNumber });
    if (error) handleError(error, '테이블 합석 해제');
  },
  resetCustomerPin: async (tableNumber: number): Promise<{ newPin: string }> => {
    const { data, error } = await supabase.rpc('staff_reset_customer_pin', { p_table_number: tableNumber });
    if (error) handleError(error, '고객 PIN 재설정');
    return { newPin: data };
  },
  verifyPin: async (pin: string): Promise<{ isValid: boolean }> => {
    const { data, error } = await supabase.from('settings').select('value').eq('key', 'pins').single();
    if (error) handleError(error, 'PIN 확인');
    return { isValid: (data?.value as any)?.staff === pin };
  },
  changePin: async (currentPin: string, newPin: string): Promise<{ success: boolean }> => {
    const { data, error } = await supabase.from('settings').select('value').eq('key', 'pins').single();
    if (error) handleError(error, 'PIN 변경 - 조회');
    if ((data?.value as any)?.staff !== currentPin) throw new Error("현재 PIN이 일치하지 않습니다.");

    const newPins = { ...(data.value as object), staff: newPin };
    const { error: updateError } = await supabase.from('settings').upsert({ key: 'pins', value: newPins });
    if (updateError) handleError(updateError, 'PIN 변경 - 업데이트');
    return { success: true };
  },
  verifyManagerPin: async (pin: string): Promise<{ isValid: boolean }> => {
    const { data, error } = await supabase.from('settings').select('value').eq('key', 'pins').single();
    if (error) handleError(error, '매니저 PIN 확인');
    return { isValid: (data?.value as any)?.manager === pin };
  },
  changeManagerPin: async (currentPin: string, newPin: string): Promise<{ success: boolean }> => {
    const { data, error } = await supabase.from('settings').select('value').eq('key', 'pins').single();
    if (error) handleError(error, '매니저 PIN 변경 - 조회');
    if ((data?.value as any)?.manager !== currentPin) throw new Error("현재 PIN이 일치하지 않습니다.");

    const newPins = { ...(data.value as object), manager: newPin };
    const { error: updateError } = await supabase.from('settings').upsert({ key: 'pins', value: newPins });
    if (updateError) handleError(updateError, '매니저 PIN 변경 - 업데이트');
    return { success: true };
  },
};