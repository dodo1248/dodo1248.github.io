import { createClient } from '@supabase/supabase-js';

// Your NEW Supabase Project URL and Public Anon Key
const supabaseUrl = 'https://aehgcsgxezxnsywnccry.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFlaGdjc2d4ZXp4bnN5d25jY3J5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjEyMTk4MTYsImV4cCI6MjA3Njc5NTgxNn0.txLWfbOTpvJtTl4UKjENTWZxSoaWSz6k0sxPXf0DgLY';


// Initialize the Supabase client with the provided credentials.
// Do not make any other changes to this file.
export const supabase = createClient(
  supabaseUrl,
  supabaseAnonKey
);