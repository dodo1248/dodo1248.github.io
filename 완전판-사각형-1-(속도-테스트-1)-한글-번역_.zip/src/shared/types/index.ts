// FIX: Reordered type definitions to ensure `MenuCategory` is declared before its use in `MenuItem`.
// This prevents potential module loading errors in certain environments by ensuring a clear dependency order.
export type MenuCategory = 'HEART 메인 (메인 안주 1)' | 'WATT 메인 (메인 안주 2)' | 'BEAT 사이드 (사이드 안주)' | '기타 (라면 및 음료)';

export interface MenuItem {
  id: number;
  name: string;
  price: number;
  category: MenuCategory;
  isSoldOut: boolean;
  imageUrl?: string;
}

export interface CartItem {
  id: number; // This corresponds to menu_item_id
  name: string;
  price: number;
  quantity: number;
  category: MenuCategory;
  status?: OrderStatus; // Status of this specific item
  uniqueId?: string; // Unique identifier for this item instance in the order
}

export interface Cart {
  [id: number]: CartItem;
}

export enum OrderStatus {
  PENDING_PAYMENT = 'pending_payment',
  PAYMENT_SUBMITTED = 'payment_submitted',
  PAYMENT_CONFIRMED = 'payment_confirmed',
  IN_KITCHEN = 'in_kitchen',
  READY_TO_SERVE = 'ready_to_serve',
  SERVED = 'served',
  CANCELLED = 'cancelled',
}

export interface Order {
  id: string;
  tableNumber: number;
  items: CartItem[];
  totalPrice: number;
  status: OrderStatus;
  timestamp: number;
  isActive: boolean;
  memo?: string;
  request?: string;
  depositorName?: string; 
  cancellationReason?: string;
}

export enum TableStatus {
  EMPTY = '비어있음',
  IDLE = '식사 중',
  CALLED = '호출',
}

export interface Table {
  tableNumber: number;
  status: TableStatus;
  reason?: string;
  pinHash?: string;
  mergedWith?: number;
  isMainTable?: boolean;
  updatedAt?: number;
}

export interface PaymentInfo {
  qrCodeUrl: string;
  accountNumber: string;
}