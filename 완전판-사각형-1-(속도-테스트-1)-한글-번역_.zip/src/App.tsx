import React, { useState, useEffect } from 'react';
import { CustomerView } from './features/customer/CustomerView';
import { StaffView } from './features/staff/StaffView';
import { LandingPage } from './features/landing/LandingPage';
import { AnimatedBackground } from './shared/components/AnimatedBackground';
import { STORAGE_KEYS } from './shared/constants';

type AppMode = 'LANDING' | 'CUSTOMER' | 'STAFF';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(() => {
    return (sessionStorage.getItem(STORAGE_KEYS.APP_MODE) as AppMode) || 'LANDING';
  });

  // The app is now always in dark mode.
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  useEffect(() => {
    if (mode === 'LANDING') {
      sessionStorage.removeItem(STORAGE_KEYS.APP_MODE);
    } else {
      sessionStorage.setItem(STORAGE_KEYS.APP_MODE, mode);
    }
  }, [mode]);

  const renderContent = () => {
    switch (mode) {
      case 'CUSTOMER':
        return <CustomerView 
                  onExitToLanding={() => {
                    // When exiting to landing, clear all session data to ensure a clean start next time.
                    sessionStorage.removeItem(STORAGE_KEYS.TABLE);
                    sessionStorage.removeItem(STORAGE_KEYS.LATEST_ORDER);
                    // Also remove any "has ordered" flags to prevent session bleed-over on the same device.
                    Object.keys(sessionStorage).forEach(key => {
                      if (key.startsWith(STORAGE_KEYS.HAS_ORDERED_PREFIX)) {
                        sessionStorage.removeItem(key);
                      }
                    });
                    setMode('LANDING');
                  }} 
                />;
      case 'STAFF':
        return <StaffView 
                  onBack={() => setMode('LANDING')}
                />;
      case 'LANDING':
      default:
        return <LandingPage 
                  onCustomer={() => setMode('CUSTOMER')} 
                  onStaff={() => setMode('STAFF')}
                />;
    }
  };

  return (
    <div className="dark h-screen overflow-hidden">
        <AnimatedBackground />
        <div className="relative z-10 animate-fade-in h-full overflow-y-auto" key={mode}>
            {renderContent()}
        </div>
    </div>
  );
};

export default App;