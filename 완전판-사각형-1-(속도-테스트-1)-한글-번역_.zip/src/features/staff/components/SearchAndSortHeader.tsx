import React from 'react';

type SortOrder = 'asc' | 'desc';

interface SearchAndSortHeaderProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  sortOrder: SortOrder;
  onSortOrderChange: (order: SortOrder) => void;
  searchPlaceholder?: string;
}

export const SearchAndSortHeader: React.FC<SearchAndSortHeaderProps> = ({
  searchTerm,
  onSearchChange,
  sortOrder,
  onSortOrderChange,
  searchPlaceholder = "테이블 번호로 검색",
}) => {
  const sortButtonClasses = (order: SortOrder) =>
    `px-4 py-2 text-sm font-bold rounded-full transition-colors ${
      sortOrder === order
        ? 'bg-rose-500 text-white shadow [text-shadow:0_1px_2px_rgba(0,0,0,0.4)]'
        : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300'
    }`;

  return (
    <div className="flex flex-col sm:flex-row gap-4 mb-4">
      <div className="relative flex-grow">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
          </svg>
        </div>
        <input
          type="number"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={searchPlaceholder}
          className="w-full pl-11 pr-4 py-3 bg-white/80 dark:bg-gray-800/80 border-2 border-gray-200 dark:border-gray-700 rounded-full focus:ring-2 focus:ring-rose-400 focus:border-transparent outline-none transition-all"
          aria-label="테이블 번호로 주문 검색"
        />
      </div>
      <div className="flex-shrink-0 flex items-center justify-center p-1 bg-gray-200 dark:bg-gray-800 rounded-full">
        <button onClick={() => onSortOrderChange('asc')} className={sortButtonClasses('asc')}>오래된 순</button>
        <button onClick={() => onSortOrderChange('desc')} className={sortButtonClasses('desc')}>최신 순</button>
      </div>
    </div>
  );
};
