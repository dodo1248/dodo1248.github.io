import React from 'react';
import { Button } from '../../../shared/components/Button';
import { clsx } from '../../../shared/utils/clsx';

interface MultiConfirmActionBarProps {
  isVisible: boolean;
  selectedCount: number;
  onConfirm: () => void;
  isLoading: boolean;
}

export const MultiConfirmActionBar: React.FC<MultiConfirmActionBarProps> = ({ isVisible, selectedCount, onConfirm, isLoading }) => {
  return (
    <div className={clsx(
      "fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-black/70 backdrop-blur-xl border-t border-rose-500/20 dark:border-rose-500/20 z-20 transition-transform duration-300",
      isVisible ? 'translate-y-0' : 'translate-y-full'
    )}>
      <div className="max-w-3xl mx-auto flex items-center justify-between gap-4">
        <p className="font-bold text-gray-800 dark:text-white">
          {selectedCount}개 주문 선택됨
        </p>
        <Button
          onClick={onConfirm}
          className="w-auto !py-3 !text-base bg-purple-500 hover:bg-purple-600 shadow-purple-400/50"
          isLoading={isLoading}
        >
          {isLoading ? '처리 중...' : '선택 주문 일괄 승인'}
        </Button>
      </div>
    </div>
  );
};
