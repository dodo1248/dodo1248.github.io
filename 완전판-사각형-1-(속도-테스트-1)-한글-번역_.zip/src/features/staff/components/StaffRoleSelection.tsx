import React from 'react';
import { Card } from '../../../shared/components/Card';
import { StaffRole } from '../staff.types';

interface RoleCardProps {
  role: StaffRole;
  name: string;
  icon: string;
  description: string;
  onSelect: (role: StaffRole) => void;
}

const RoleCard: React.FC<RoleCardProps> = ({ role, name, icon, description, onSelect }) => (
  <button
    onClick={() => onSelect(role)}
    className="w-full text-left p-6 bg-white/80 dark:bg-gray-800/70 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-rose-200/60 dark:border-gray-700 hover:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-500"
  >
    <div className="flex items-center space-x-4">
      <div className="text-4xl">{icon}</div>
      <div>
        <h3 className="text-xl font-bold text-gray-800 dark:text-white">{name}</h3>
        <p className="text-gray-500 dark:text-gray-400">{description}</p>
      </div>
    </div>
  </button>
);


export const StaffRoleSelection: React.FC<{ onSelectRole: (role: StaffRole) => void; onLogout: () => void; }> = ({ onSelectRole, onLogout }) => {
  return (
    <div className="w-full h-full p-4 flex items-center justify-center">
      <div className="max-w-md w-full">
        <div className="text-right mb-2">
          <button onClick={onLogout} className="text-gray-600 dark:text-gray-300 font-bold hover:text-rose-500">
            &lt; 로그아웃
          </button>
        </div>
        <Card className="w-full">
          <h1 className="text-2xl font-bold text-center text-gray-800 dark:text-white mb-2">역할 선택</h1>
          <p className="text-center text-gray-500 dark:text-gray-400 mb-8">수행할 역할을 선택해주세요.</p>
          <div className="space-y-4">
            <RoleCard
              role="manager"
              name="매니저"
              icon="👑"
              description="전체 기능 접근 및 관리"
              onSelect={onSelectRole}
            />
            <RoleCard
              role="hall"
              name="홀"
              icon="🙋‍♂️"
              description="결제 확인, 서빙, 테이블 관리"
              onSelect={onSelectRole}
            />
            <RoleCard
              role="kitchen"
              name="주방"
              icon="🍳"
              description="주문 접수 및 조리 관리"
              onSelect={onSelectRole}
            />
          </div>
        </Card>
      </div>
    </div>
  );
};