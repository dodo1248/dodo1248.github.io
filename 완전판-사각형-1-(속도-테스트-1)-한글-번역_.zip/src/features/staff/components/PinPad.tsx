import React, { useState, useEffect, useRef } from 'react';
import { clsx } from '../../../shared/utils/clsx';
import { STAFF_PIN_LENGTH } from '../../../shared/constants';

interface PinPadProps {
  pinLength?: number;
  onComplete: (pin: string) => void;
  title: string;
  error?: string;
  reset?: boolean;
}

const BackspaceIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.414 6.414a2 2 0 002.828 0L21 12M3 12l6.414-6.414a2 2 0 012.828 0L21 12" />
  </svg>
);


export const PinPad: React.FC<PinPadProps> = ({ pinLength = STAFF_PIN_LENGTH, onComplete, title, error, reset }) => {
  const [pin, setPin] = useState('');
  const [shake, setShake] = useState(false);
  const [animateDot, setAnimateDot] = useState<number | null>(null);
  const errorRef = useRef(error);

  useEffect(() => {
    if (reset) {
      setPin('');
    }
  }, [reset]);

  useEffect(() => {
    if (error && error !== errorRef.current) {
      setShake(true);
      const timer = setTimeout(() => {
        setShake(false);
        setPin(''); 
      }, 500);
      errorRef.current = error;
      return () => clearTimeout(timer);
    }
    if (!error) {
        errorRef.current = '';
    }
  }, [error]);

  const handleDigitClick = (digit: string) => {
    if (pin.length < pinLength) {
      const newPin = pin + digit;
      setPin(newPin);
      setAnimateDot(pin.length);
      setTimeout(() => setAnimateDot(null), 200);

      if (newPin.length === pinLength) {
        setTimeout(() => onComplete(newPin), 100);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const keypadButtons = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'delete'];

  return (
    <div className="flex flex-col items-center">
      <style>{`
        @keyframes shake {
          10%, 90% { transform: translate3d(-1px, 0, 0); }
          20%, 80% { transform: translate3d(2px, 0, 0); }
          30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
          40%, 60% { transform: translate3d(4px, 0, 0); }
        }
        .animate-shake { animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both; }
        .animate-pin-pop { animation: pin-pop 0.2s ease-out forwards; }
      `}</style>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{title}</h2>
      <div className={clsx("flex space-x-3 sm:space-x-4 mb-4", shake && 'animate-shake')}>
        {Array.from({ length: pinLength }).map((_, i) => (
            <div
                key={i}
                className={clsx(
                    'w-5 h-5 rounded-full border-2 transition-all duration-300',
                    {
                        'border-rose-500': i < pin.length,
                        'bg-rose-500': i < pin.length,
                        'border-gray-300 dark:border-gray-600': i >= pin.length,
                        'animate-pin-pop': animateDot === i,
                        '!border-red-500 !bg-transparent': shake
                    }
                )}
            />
        ))}
      </div>
      <p className="h-6 text-sm font-semibold text-red-500 mb-4">{error || ' '}</p>
      
      <div className="grid grid-cols-3 gap-4 w-full max-w-[280px] sm:max-w-xs">
        {keypadButtons.map((key) => {
          if (key === '') return <div key="empty" />;
          
          const isDelete = key === 'delete';
          
          return (
             <button
                key={key}
                onClick={isDelete ? handleDelete : () => handleDigitClick(key)}
                disabled={isDelete && pin.length === 0}
                className="h-16 w-16 sm:h-20 sm:w-20 rounded-full bg-rose-100/60 dark:bg-gray-800/60 flex items-center justify-center text-gray-800 dark:text-white transition-all duration-100 ease-in-out active:scale-95 active:bg-rose-200/80 dark:active:bg-gray-700 disabled:opacity-30"
                aria-label={isDelete ? 'Delete last digit' : `Enter digit ${key}`}
              >
              {isDelete ? (
                <BackspaceIcon />
              ) : (
                <span className="text-3xl sm:text-4xl font-bold">{key}</span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};