import React, { useState } from 'react';
import { Card } from '../../../shared/components/Card';
import { PinPad } from './PinPad';
import { Logo } from '../../../shared/components/Logo';

export const StaffLogin: React.FC<{ onLogin: (pin: string) => Promise<boolean>; onBack: () => void }> = ({ onLogin, onBack }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handlePinComplete = async (pin: string) => {
        setIsLoading(true);
        setError('');
        const success = await onLogin(pin);
        if (!success) {
            setError('PIN이 일치하지 않습니다.');
        }
        // If successful, the parent component will handle navigation.
        setIsLoading(false);
    };
    
    return (
        <div className="w-full h-full p-4 flex flex-col items-center justify-center">
             {isLoading && (
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center">
                    <svg className="animate-spin h-10 w-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </div>
            )}
            <div className="max-w-md w-full">
                <div className="w-full text-left mb-2">
                    <button onClick={onBack} className="text-gray-600 dark:text-gray-300 font-bold p-2 transition-colors hover:text-rose-500 dark:hover:text-rose-400">{'<'} 홈으로</button>
                </div>
                <div className="flex justify-center mb-4">
                    <Logo />
                </div>
                <Card className="w-full" padding="p-4 sm:p-6">
                    <PinPad
                      title="스태프 PIN 입력"
                      onComplete={handlePinComplete}
                      error={error}
                    />
                </Card>
            </div>
        </div>
    );
}