import React, { useEffect } from 'react';
import { Modal } from '../../../shared/components/Modal';
import { Table } from '../../../shared/types';
import { Button } from '../../../shared/components/Button';
import { useTables } from '../contexts/TablesContext';

interface CallListModalProps {
    isOpen: boolean;
    onClose: () => void;
    callingTables: Table[];
}

export const CallListModal: React.FC<CallListModalProps> = ({ isOpen, onClose, callingTables }) => {
    const { actions: tableActions, updatingIds } = useTables();

    // Automatically close the modal when the last call is resolved.
    useEffect(() => {
        if (isOpen && callingTables.length === 0) {
            onClose();
        }
    }, [isOpen, callingTables, onClose]);

    const handleResolve = (tableNumber: number) => {
        tableActions.resolveCall(tableNumber);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`🚨 호출 테이블 (${callingTables.length})`}>
            {callingTables.length === 0 && isOpen ? (
                <div className="text-center text-gray-400 py-8">
                    <svg className="animate-spin h-8 w-8 text-rose-500 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p className="mt-4">모든 호출을 해결했습니다.</p>
                </div>
            ) : (
                <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                    {callingTables.map(table => (
                        <div key={table.tableNumber} className="flex items-center justify-between p-4 bg-gray-800/60 rounded-lg">
                            <div>
                                <p className="text-xl font-bold text-white">테이블 {table.tableNumber}</p>
                                <p className="text-rose-300 font-semibold">{table.reason}</p>
                            </div>
                            <Button
                                onClick={() => handleResolve(table.tableNumber)}
                                isLoading={updatingIds.has(table.tableNumber)}
                                className="w-auto !py-2 !px-4 !text-base"
                            >
                                ✅ 해결
                            </Button>
                        </div>
                    ))}
                </div>
            )}
        </Modal>
    );
};
