import React, { useState, useEffect } from 'react';
import { Modal } from '../../../shared/components/Modal';
import { Button } from '../../../shared/components/Button';
import { PinPad } from './PinPad';
import { staffApi } from '../../../shared/api/staff';

export const RevenueModal: React.FC<{ isOpen: boolean; onClose: () => void; totalRevenue: number; }> = ({ isOpen, onClose, totalRevenue }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [resetPinPad, setResetPinPad] = useState(false);

    useEffect(() => {
        // Reset state when modal is opened or closed
        if (isOpen) {
            setIsAuthenticated(false);
            setError('');
            setResetPinPad(true);
            setTimeout(() => setResetPinPad(false), 50);
        }
    }, [isOpen]);

    const handlePinComplete = async (pin: string) => {
        setIsLoading(true);
        setError('');
        try {
            const { isValid } = await staffApi.verifyManagerPin(pin);
            if (isValid) {
                setIsAuthenticated(true);
            } else {
                setError('매니저 PIN이 일치하지 않습니다.');
            }
        } catch (e: any) {
            setError(e.message || 'PIN 확인 중 오류가 발생했습니다.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="총 매출액 확인">
            <div className="relative min-h-[300px] flex flex-col justify-center">
                {isLoading && (
                     <div className="absolute inset-0 bg-white/50 dark:bg-black/50 z-10 flex items-center justify-center rounded-3xl">
                        <svg className="animate-spin h-8 w-8 text-rose-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                     </div>
                )}
                {isAuthenticated ? (
                    <div className="text-center animate-fade-in">
                        <p className="text-gray-700 dark:text-gray-300 text-lg">총 매출액 (모든 주문 기준)</p>
                        <p className="text-5xl font-black text-[#ef7490] my-4">{totalRevenue.toLocaleString()}원</p>
                        <Button onClick={onClose} variant="secondary">닫기</Button>
                    </div>
                ) : (
                    <PinPad
                        title="매니저 PIN 입력"
                        onComplete={handlePinComplete}
                        error={error}
                        reset={resetPinPad}
                    />
                )}
            </div>
        </Modal>
    );
}