import React from 'react';

interface StaffHeaderProps {
    onToggleSidebar: () => void;
    isRefreshing: boolean;
    onRefresh: () => void;
}

export const StaffHeader: React.FC<StaffHeaderProps> = ({ onToggleSidebar, isRefreshing, onRefresh }) => {
    return (
        <header className="sticky top-0 z-30 bg-gray-950/70 backdrop-blur-xl p-4 border-b border-gray-800 flex justify-between items-center lg:justify-end">
             <button className="lg:hidden text-gray-300 p-2 -ml-2" onClick={onToggleSidebar} aria-label="메뉴 열기">
                <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>

            <div className="flex items-center space-x-2 sm:space-x-4">
                <button
                    onClick={onRefresh}
                    disabled={isRefreshing}
                    className="p-2.5 rounded-full bg-gray-800/50 text-gray-300"
                    aria-label="데이터 새로고침"
                >
                    <svg className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h5M20 20v-5h-5M20 4l-4 4M4 20l4-4M12 4v2m0 12v2M8.5 7.5l-2-2M17.5 15.5l-2-2M7.5 15.5l-2 2M15.5 7.5l2 2" />
                    </svg>
                </button>
            </div>
        </header>
    );
};