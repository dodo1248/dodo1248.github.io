import React from 'react';

interface StaffLayoutProps {
  sidebar: React.ReactNode;
  header: React.ReactNode;
  children: React.ReactNode;
  isSidebarOpen: boolean;
  onCloseSidebar: () => void;
}

export const StaffLayout: React.FC<StaffLayoutProps> = ({ sidebar, header, children, isSidebarOpen, onCloseSidebar }) => {
  return (
    <div className="flex h-full">
        {/* Sidebar for Desktop */}
        <aside className="hidden lg:block w-64 bg-white/70 dark:bg-gray-950/70 backdrop-blur-xl border-r border-rose-100 dark:border-gray-800 flex-shrink-0">
            {sidebar}
        </aside>

        {/* Mobile Sidebar */}
        <div 
            className={`fixed inset-0 z-40 lg:hidden transition-opacity duration-300 ${isSidebarOpen ? 'bg-black/60' : 'bg-transparent pointer-events-none'}`} 
            onClick={onCloseSidebar}
            aria-hidden="true"
        ></div>
        <aside className={`fixed top-0 left-0 h-full w-64 bg-white/80 dark:bg-gray-950/80 backdrop-blur-xl z-50 transform transition-transform duration-300 lg:hidden border-r border-rose-100 dark:border-gray-800 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            {sidebar}
        </aside>

        {/* Main Content */}
        <main className="flex-1">
            {header}
            {children}
        </main>
    </div>
  );
};