
import React, { useState, useCallback } from 'react';
import { OrderStatus, CartItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { ElapsedTime } from './ElapsedTime';
import { ORDER_CRITICAL_THRESHOLD_MINUTES, ORDER_OVERDUE_THRESHOLD_MINUTES } from '../../../shared/constants';
import { clsx } from '../../../shared/utils/clsx';

interface KitchenTableOrder {
  tableNumber: number;
  items: CartItem[];
  timestamp: number;
  status: OrderStatus;
}

interface KitchenOrderCardProps {
  table: KitchenTableOrder;
}

export const KitchenOrderCard: React.FC<KitchenOrderCardProps> = ({ table }) => {
  const [warningLevel, setWarningLevel] = useState(0);

  const handleTimeExceeded = useCallback((minutes: number) => {
    if (minutes >= ORDER_CRITICAL_THRESHOLD_MINUTES) setWarningLevel(2);
    else if (minutes >= ORDER_OVERDUE_THRESHOLD_MINUTES) setWarningLevel(1);
    else setWarningLevel(0);
  }, []);

  const cardClasses = clsx(
    'transition-all duration-500',
    {
      'ring-4 ring-red-500': warningLevel === 2,
      'ring-4 ring-yellow-400': warningLevel === 1,
    }
  );

  const statusInfo: Partial<Record<OrderStatus, { text: string, color: string }>> = {
    [OrderStatus.PAYMENT_CONFIRMED]: { text: '접수 완료', color: 'bg-rose-500 text-white' },
    [OrderStatus.IN_KITCHEN]: { text: '준비 중', color: 'bg-orange-500 text-white' },
  };

  const currentStatus = statusInfo[table.status] || { text: table.status, color: 'bg-gray-500 text-white'};

  return (
    <Card className={cardClasses}>
      <div className="flex justify-between items-center mb-3">
        <div>
            <p className="text-xl font-black text-gray-800 dark:text-white">테이블 {table.tableNumber}</p>
            <span className={`px-2 py-0.5 text-xs font-bold rounded-full ${currentStatus.color}`}>{currentStatus.text}</span>
        </div>
        <ElapsedTime timestamp={table.timestamp} onTimeExceeded={handleTimeExceeded} />
      </div>
      <ul className="space-y-2">
        {table.items.map((item, index) => (
          <li key={`${item.id}-${index}`} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800/60 rounded-lg">
            <span className="font-medium text-gray-700 dark:text-gray-300">{item.name}</span>
            <span className="font-bold text-lg text-gray-800 dark:text-gray-100">x{item.quantity}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
};
