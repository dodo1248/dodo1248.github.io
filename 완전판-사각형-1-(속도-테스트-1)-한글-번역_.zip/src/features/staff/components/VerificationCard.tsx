
import React from 'react';
import { Order, OrderStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { useOrders } from '../contexts/OrdersContext';
import { CancelOrderModal } from './CancelOrderModal';
import { clsx } from '../../../shared/utils/clsx';

interface VerificationCardProps {
  order: Order;
  isSelectionMode?: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

export const VerificationCard: React.FC<VerificationCardProps> = React.memo(({ order, isSelectionMode, isSelected, onClick }) => {
    const { actions, updatingIds } = useOrders();

    const isThisCardUpdating = updatingIds.has(order.id);
    const [isCancelModalOpen, setIsCancelModalOpen] = React.useState(false);

    const handleVerificationComplete = async () => {
        if (isThisCardUpdating) return;
        try {
            await actions.updateOrderStatus(order.id, OrderStatus.PAYMENT_CONFIRMED);
        } catch (error) {
            alert('주문 승인 처리에 실패했습니다. 네트워크 상태를 확인해주세요.');
        }
    };

    const handleCancelOrder = async (reason: string) => {
        try {
            await actions.cancelOrder(order.id, reason);
        } catch (e) {
            alert('주문 취소에 실패했습니다.');
        } finally {
            setIsCancelModalOpen(false);
        }
    }

    return (
        <div className="relative" onClick={onClick}>
            <Card className={clsx(
                "border-2 border-purple-400 dark:border-purple-500 shadow-lg shadow-purple-500/20 transition-all",
                { 'opacity-50 pointer-events-none': isThisCardUpdating },
                { 'cursor-pointer': isSelectionMode },
                { 'ring-4 ring-offset-2 ring-purple-500 dark:ring-offset-gray-950': isSelected }
            )}>
                <div className="flex justify-between items-start mb-3">
                    <p className="text-xl font-black text-gray-800 dark:text-white">테이블 {order.tableNumber}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(order.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
                
                <div className="bg-purple-50 dark:bg-gray-800/70 p-3 rounded-lg space-y-2 mb-3">
                    <p className="text-xs font-bold text-purple-800 dark:text-purple-300">주문 총액</p>
                    <p className="text-lg font-bold text-purple-600 dark:text-purple-200">{order.totalPrice.toLocaleString()}원</p>
                </div>

                <ul className="my-3 divide-y divide-purple-500/10 dark:divide-gray-700/50">
                    {order.items.map(item => (
                        <li key={`${item.id}-${item.name}`} className="flex justify-between py-1 text-sm">
                            <span className="text-gray-700 dark:text-gray-300">{item.name}</span>
                            <span className="font-medium text-gray-800 dark:text-gray-200">x{item.quantity}</span>
                        </li>
                    ))}
                </ul>
                {order.request && <p className="p-2 bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 rounded-lg text-sm mt-2">🗣️ 요청: {order.request}</p>}
                
                <div className="mt-4 space-y-2">
                    <Button 
                        onClick={handleVerificationComplete} 
                        isLoading={isThisCardUpdating} 
                        className="bg-purple-500 hover:bg-purple-600 shadow-purple-400/50 dark:shadow-purple-500/30"
                    >
                        🤝 현장 확인 완료
                    </Button>
                    <Button
                        variant="secondary"
                        onClick={() => setIsCancelModalOpen(true)}
                        disabled={isThisCardUpdating}
                        className="!text-red-500 !border-red-400 hover:!bg-red-50 dark:!border-red-500/50 dark:!text-red-400 dark:hover:!bg-red-500/10"
                    >
                        주문 취소
                    </Button>
                </div>
            </Card>
            {isSelected && (
                <div className="absolute top-2 right-2 bg-purple-500 text-white rounded-full h-6 w-6 flex items-center justify-center pointer-events-none ring-2 ring-white dark:ring-gray-900">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
            )}
            <CancelOrderModal
                isOpen={isCancelModalOpen}
                onClose={() => setIsCancelModalOpen(false)}
                onConfirm={handleCancelOrder}
                isLoading={isThisCardUpdating}
                tableNumber={order.tableNumber}
            />
        </div>
    );
});
