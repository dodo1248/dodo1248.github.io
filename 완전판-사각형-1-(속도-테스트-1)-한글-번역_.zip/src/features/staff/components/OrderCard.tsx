
import React, { useState, useCallback } from 'react';
import { Order, OrderStatus, CartItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { useOrders } from '../contexts/OrdersContext';
import { ElapsedTime } from './ElapsedTime';
import { ORDER_CRITICAL_THRESHOLD_MINUTES, ORDER_OVERDUE_THRESHOLD_MINUTES } from '../../../shared/constants';
import { clsx } from '../../../shared/utils/clsx';

const ItemRow: React.FC<{ item: CartItem }> = ({ item }) => {
    const { actions, updatingIds } = useOrders();
    const isUpdating = updatingIds.has(item.uniqueId!);

    const handleToggleItemStatus = () => {
        if (item.status === OrderStatus.IN_KITCHEN) {
            actions.updateOrderItemStatus(item.uniqueId!, OrderStatus.READY_TO_SERVE);
        } else if (item.status === OrderStatus.READY_TO_SERVE) {
            actions.updateOrderItemStatus(item.uniqueId!, OrderStatus.IN_KITCHEN);
        }
    };
    
    const canToggle = item.status === OrderStatus.IN_KITCHEN || item.status === OrderStatus.READY_TO_SERVE;

    return (
        <li className="flex justify-between items-center py-2 text-sm">
            <div className="flex items-center">
                {canToggle && (
                    <button 
                        onClick={handleToggleItemStatus} 
                        disabled={isUpdating}
                        className="mr-3 w-5 h-5 flex-shrink-0 rounded border-2 flex items-center justify-center transition-colors disabled:opacity-50
                            border-rose-300 dark:border-gray-500
                            data-[checked=true]:bg-rose-500 data-[checked=true]:border-rose-500"
                        data-checked={item.status === OrderStatus.READY_TO_SERVE}
                    >
                         {item.status === OrderStatus.READY_TO_SERVE && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                    </button>
                )}
                <span className={clsx("text-gray-700 dark:text-gray-300", { 'line-through': item.status === OrderStatus.READY_TO_SERVE })}>{item.name}</span>
            </div>
            <span className="font-medium text-gray-800 dark:text-gray-200">x{item.quantity}</span>
        </li>
    );
};

export const OrderCard: React.FC<{ order: Order; isNew: boolean }> = React.memo(({ order, isNew }) => {
    const { actions, updatingIds } = useOrders();
    const isUpdating = updatingIds.has(order.id);
    const [warningLevel, setWarningLevel] = useState(0);

    const handleTimeExceeded = useCallback((minutes: number) => {
        if (minutes >= ORDER_CRITICAL_THRESHOLD_MINUTES) setWarningLevel(2);
        else if (minutes >= ORDER_OVERDUE_THRESHOLD_MINUTES) setWarningLevel(1);
        else setWarningLevel(0);
    }, []);
    
    const handleUpdateStatus = (status: OrderStatus) => {
        actions.updateOrderStatus(order.id, status);
    };
    
    const cardClasses = clsx(
        'transition-all duration-500',
        {
            'ring-4 ring-red-500 animate-pulse-fast': warningLevel === 2,
            'ring-4 ring-yellow-400': warningLevel === 1,
            'animate-new-order-flash': isNew,
        }
    );

    return (
        <Card className={cardClasses}>
             <div className="flex justify-between items-start mb-3">
                <p className="text-xl font-black text-gray-800 dark:text-white">테이블 {order.tableNumber}</p>
                <ElapsedTime timestamp={order.timestamp} onTimeExceeded={handleTimeExceeded} />
            </div>
            
            <ul className="my-3 divide-y divide-pink-500/10 dark:divide-gray-700/50">
                {order.items.map(item => <ItemRow key={item.uniqueId} item={item} />)}
            </ul>
            {order.request && <p className="p-2 bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 rounded-lg text-sm mt-2">🗣️ 요청: {order.request}</p>}
            
            <div className="mt-4 grid grid-cols-2 gap-2">
                {order.status === OrderStatus.PAYMENT_CONFIRMED && (
                    <Button onClick={() => handleUpdateStatus(OrderStatus.IN_KITCHEN)} isLoading={isUpdating} className="col-span-2">
                        🍳 주방 전달 (조리 시작)
                    </Button>
                )}
                {order.status === OrderStatus.IN_KITCHEN && (
                    <Button onClick={() => handleUpdateStatus(OrderStatus.READY_TO_SERVE)} isLoading={isUpdating} className="col-span-2">
                        🎁 조리 완료 (서빙 대기)
                    </Button>
                )}
            </div>
        </Card>
    );
});
