import React from 'react';
import { StaffPage, StaffRole } from '../staff.types';

const pageIcons: Record<StaffPage, string> = {
    [StaffPage.DASHBOARD]: '📊',
    [StaffPage.VERIFICATION]: '🤝',
    [StaffPage.ORDERS]: '🔥',
    [StaffPage.KITCHEN]: '🍳',
    [StaffPage.SERVING]: '🍽️',
    [StaffPage.TABLES]: '🍻',
    [StaffPage.HALL_DUTY]: '⏳',
    [StaffPage.MENU]: '📝',
    [StaffPage.STATS]: '📈',
    [StaffPage.ANALYSIS]: '📄',
};

const roleIcons: Record<StaffRole, string> = {
  manager: '👑',
  hall: '🙋‍♂️',
  kitchen: '🍳'
};

const NavButton: React.FC<{
    page: StaffPage;
    activePage: StaffPage;
    setActivePage: (page: StaffPage) => void;
    count?: number;
}> = ({ page, activePage, setActivePage, count }) => {
    const isActive = activePage === page;
    return (
        <button
            onClick={() => setActivePage(page)}
            className={`w-full flex items-center justify-between text-left p-3 rounded-lg transition-colors text-base font-bold ${isActive
                    ? 'bg-rose-500 text-white shadow-md'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-rose-100 dark:hover:bg-gray-800'
                }`}
            aria-current={isActive ? 'page' : undefined}
        >
            <span className="flex items-center">
                <span className="mr-3 text-xl">{pageIcons[page]}</span>
                {page}
            </span>
            {typeof count !== 'undefined' && count > 0 && (
                <span className={`h-6 w-6 rounded-full text-sm flex items-center justify-center font-black ${isActive ? 'bg-white text-rose-500' : 'bg-rose-500 text-white animate-pulse'}`}>
                    {count}
                </span>
            )}
        </button>
    );
};

interface StaffSidebarProps {
    staffRole: StaffRole;
    onChangeRole: () => void;
    availablePages: StaffPage[];
    activePage: StaffPage;
    setActivePage: (page: StaffPage) => void;
    pageCounts: {
        verification: number;
        orders: number;
        serving: number;
        calls: number;
    };
    operatingDay: 1 | 2;
    onDayChange: (day: 1 | 2) => void;
    onLogout: () => void;
    onOpenPinModal: () => void;
    onOpenManagerPinModal: () => void;
}

export const StaffSidebar: React.FC<StaffSidebarProps> = ({
    staffRole,
    onChangeRole,
    availablePages,
    activePage,
    setActivePage,
    pageCounts,
    operatingDay,
    onDayChange,
    onLogout,
    onOpenPinModal,
    onOpenManagerPinModal,
}) => {
    const roleName = { manager: '매니저', hall: '홀', kitchen: '주방' };

    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-rose-100 dark:border-gray-700">
                <div className="flex justify-between items-center mb-2">
                  <h2 className="text-xl font-black text-slate-800 dark:text-slate-100">HEART Beat WATT</h2>
                  <p className="font-semibold text-rose-600 dark:text-rose-400">스태프</p>
                </div>
                <button
                  onClick={onChangeRole}
                  className="w-full flex items-center justify-between text-left p-3 rounded-xl bg-rose-50 dark:bg-gray-800 hover:bg-rose-100 dark:hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-rose-400"
                  aria-label={`현재 역할: ${roleName[staffRole]}. 역할을 변경하려면 클릭하세요.`}
                >
                  <div>
                    <p className="font-bold text-gray-800 dark:text-white">{roleName[staffRole]}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">여기를 눌러 역할 변경</p>
                  </div>
                  <span className="text-3xl">{roleIcons[staffRole]}</span>
                </button>
            </div>
            <nav className="flex-grow p-4 space-y-2 overflow-y-auto">
                {availablePages.map(page => (
                    <NavButton
                        key={page}
                        page={page}
                        activePage={activePage}
                        setActivePage={setActivePage}
                        count={
                            (page === StaffPage.VERIFICATION && pageCounts.verification > 0) ? pageCounts.verification :
                            (page === StaffPage.ORDERS && pageCounts.orders > 0) ? pageCounts.orders :
                            (page === StaffPage.SERVING && pageCounts.serving > 0) ? pageCounts.serving :
                            undefined
                        }
                    />
                ))}
            </nav>
            
            {staffRole === 'manager' && (
                <div className="p-4 border-t border-rose-100 dark:border-gray-700">
                    <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 mb-2">운영일 설정</h3>
                    <div className="flex items-center p-1 bg-gray-200 dark:bg-gray-800 rounded-full">
                        {[1, 2].map(day => (
                            <button
                                key={day}
                                onClick={() => onDayChange(day as 1 | 2)}
                                disabled={operatingDay === day}
                                className={`flex-1 px-3 py-1.5 text-sm font-bold rounded-full transition-colors ${operatingDay === day
                                        ? 'bg-rose-500 text-white shadow [text-shadow:0_1px_2px_rgba(0,0,0,0.4)]'
                                        : 'text-gray-600 dark:text-gray-300'
                                    }`}
                            >
                                {day}일차
                            </button>
                        ))}
                    </div>
                </div>
            )}

            <div className="p-4 border-t border-rose-100 dark:border-gray-700">
                {staffRole === 'manager' && (
                  <>
                    <button 
                        onClick={onOpenManagerPinModal} 
                        className="w-full text-left p-3 mb-2 rounded-lg transition-colors text-base font-bold text-gray-700 dark:text-gray-300 hover:bg-rose-100 dark:hover:bg-gray-800"
                    >
                        <span className="flex items-center">
                            <span className="mr-3 text-xl">🔑</span>
                            매출 PIN 변경
                        </span>
                    </button>
                    <button 
                        onClick={onOpenPinModal} 
                        className="w-full text-left p-3 mb-2 rounded-lg transition-colors text-base font-bold text-gray-700 dark:text-gray-300 hover:bg-rose-100 dark:hover:bg-gray-800"
                    >
                        <span className="flex items-center">
                            <span className="mr-3 text-xl">🔒</span>
                            로그인 PIN 변경
                        </span>
                    </button>
                  </>
                )}
                 <button onClick={onLogout} className="w-full p-2 text-red-500 dark:text-red-400 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors font-bold">
                    로그아웃
                </button>
            </div>
        </div>
    );
};