import React from 'react';
import { Button } from '../../../../shared/components/Button';
import { clsx } from '../../../../shared/utils/clsx';

interface MultiClearActionBarProps {
  isVisible: boolean;
  selectedCount: number;
  onClear: () => void;
  onMerge: () => void;
  isMergeEnabled: boolean;
}

export const MultiClearActionBar: React.FC<MultiClearActionBarProps> = ({ isVisible, selectedCount, onClear, onMerge, isMergeEnabled }) => {
  return (
    <div className={clsx(
      "fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-black/70 backdrop-blur-xl border-t border-rose-500/20 dark:border-rose-500/20 z-20 transition-transform duration-300",
      isVisible ? 'translate-y-0' : 'translate-y-full'
    )}>
      <div className="max-w-3xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        <p className="font-bold text-gray-800 dark:text-white text-sm sm:text-base">
          {selectedCount}개 선택됨
        </p>
        <div className="flex gap-2 sm:gap-4">
           {selectedCount > 1 && (
             <Button
                onClick={onMerge}
                disabled={!isMergeEnabled}
                className={clsx(
                    "w-auto !py-3 !text-base !bg-purple-500 hover:!bg-purple-600 !shadow-purple-400/50",
                    !isMergeEnabled && "!bg-gray-600 hover:!bg-gray-600 !shadow-none !translate-y-0 cursor-not-allowed"
                )}
                title={!isMergeEnabled ? "비어있는 테이블만 합석할 수 있습니다." : "선택한 테이블 합석"}
             >
                합석하기
             </Button>
           )}
           <Button
             onClick={onClear}
             className="w-auto !py-3 !text-base"
           >
             비우기
           </Button>
        </div>
      </div>
    </div>
  );
};