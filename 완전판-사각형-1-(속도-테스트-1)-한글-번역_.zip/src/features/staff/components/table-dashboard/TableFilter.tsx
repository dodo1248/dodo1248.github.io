
import React from 'react';
import { TableStatus } from '../../../../shared/types';
import { clsx } from '../../../../shared/utils/clsx';

export type TableFilterType = 'all' | TableStatus;

interface TableFilterProps {
  currentFilter: TableFilterType;
  onFilterChange: (filter: TableFilterType) => void;
  counts: {
    idle: number;
    empty: number;
  };
}

export const TableFilter: React.FC<TableFilterProps> = ({ currentFilter, onFilterChange, counts }) => {
  const filterButtonClasses = (f: TableFilterType) =>
    clsx(
      'px-4 py-2 text-sm font-bold rounded-full transition-colors whitespace-nowrap',
      currentFilter === f
        ? 'bg-rose-500 text-white shadow [text-shadow:0_1px_2px_rgba(0,0,0,0.4)]'
        : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300'
    );

  return (
    <div className="mb-6">
      <div className="flex flex-wrap items-center gap-2 p-1 bg-gray-200 dark:bg-gray-800 rounded-full">
        <button onClick={() => onFilterChange('all')} className={filterButtonClasses('all')}>전체</button>
        <button onClick={() => onFilterChange(TableStatus.IDLE)} className={filterButtonClasses(TableStatus.IDLE)}>식사중 ({counts.idle})</button>
        <button onClick={() => onFilterChange(TableStatus.EMPTY)} className={filterButtonClasses(TableStatus.EMPTY)}>빈자리 ({counts.empty})</button>
      </div>
    </div>
  );
};