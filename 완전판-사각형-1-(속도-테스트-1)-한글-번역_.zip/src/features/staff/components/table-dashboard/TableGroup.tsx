
import React from 'react';
import { Table, TableStatus } from '../../../../shared/types';
import { Card } from '../../../../shared/components/Card';
import { Button } from '../../../../shared/components/Button';
import { clsx } from '../../../../shared/utils/clsx';
import { StaffRole } from '../../staff.types';

interface MergedGroup {
  main: Table;
  subs: Table[];
}

interface TableGroupProps {
  title: string;
  titleColor?: string;
  tables: Table[];
  mergedGroups?: MergedGroup[];
  gridCols?: string;
  isSelectionMode: boolean;
  selectedTables: Set<number>;
  updatingIds: Set<string | number>;
  onTableClick: (table: Table) => void;
  onResolveCall?: (tableNumber: number) => void;
  onManagePinClick?: (table: Table) => void;
  staffRole?: StaffRole;
}

const TableCard: React.FC<{
  table: Table;
  isSelectionMode: boolean;
  isSelected: boolean;
  isUpdatingClear: boolean;
  staffRole?: StaffRole;
  onTableClick: (table: Table) => void;
  onManagePinClick?: (table: Table) => void;
}> = ({ table, isSelectionMode, isSelected, isUpdatingClear, staffRole, onTableClick, onManagePinClick }) => (
    <Card
      padding="p-2"
      className={clsx('text-center relative transition-all duration-200', {
        'cursor-pointer': isSelectionMode || staffRole === 'manager' || !table.mergedWith,
        'ring-2 ring-offset-2 ring-rose-500 dark:ring-offset-gray-950': isSelected,
        'opacity-50 pointer-events-none': isUpdatingClear,
      })}
      onClick={() => onTableClick(table)}
    >
      <div className="p-2">
        <p className="text-3xl font-bold text-gray-200">{table.tableNumber}</p>
        <p className="text-xs text-gray-400 mt-1 h-4">
          {table.isMainTable ? '대표' : table.mergedWith ? `${table.mergedWith}에 합석` : '식사 중'}
        </p>
      </div>

      {!isSelectionMode && staffRole === 'manager' && (
          <button
            onClick={(e) => { e.stopPropagation(); onManagePinClick?.(table); }}
            className="absolute top-1 left-1 p-2 rounded-full bg-gray-700 hover:bg-gray-600 transition-all transform hover:scale-110 active:scale-95"
            aria-label={`${table.tableNumber}번 테이블 PIN 관리`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-300" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l1-1 1-1 1.257-1.257A6 6 0 1118 8zm-6-4a4 4 0 100 8 4 4 0 000-8z" clipRule="evenodd" />
            </svg>
          </button>
      )}
      {!isSelectionMode && (
        <button
          onClick={(e) => { e.stopPropagation(); onTableClick(table); }}
          className="absolute bottom-1 right-1 p-2 rounded-full bg-gray-700 hover:bg-gray-600 transition-all transform hover:scale-110 active:scale-95"
          aria-label={`${table.tableNumber}번 테이블 비움/합석해제`}
          disabled={isUpdatingClear}
        >
          {isUpdatingClear ? (
              <svg className="animate-spin h-5 w-5 text-gray-300" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-300" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
          )}
        </button>
      )}
      {isSelected && (
        <div className="absolute inset-0 bg-rose-500/30 rounded-3xl flex items-center justify-center pointer-events-none">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        </div>
      )}
    </Card>
);

export const TableGroup: React.FC<TableGroupProps> = ({
  title,
  titleColor = 'text-gray-300',
  tables,
  mergedGroups = [],
  gridCols = 'grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8',
  isSelectionMode,
  selectedTables,
  updatingIds,
  onTableClick,
  onResolveCall,
  onManagePinClick,
  staffRole
}) => {
  if (tables.length === 0 && mergedGroups.length === 0) {
    return null;
  }

  // Per user request, "CALLED" tables are no longer displayed in this component.
  // This component now only shows IDLE, EMPTY, and MERGED tables.
  const tablesToDisplay = tables.filter(t => t.status !== TableStatus.CALLED);

  if (tablesToDisplay.length === 0 && mergedGroups.length === 0) {
    return null;
  }

  return (
    <div>
      <h3 className={`font-bold text-lg mb-3 ${titleColor}`}>{title} ({tablesToDisplay.length + mergedGroups.length})</h3>
      <div className={clsx("grid gap-3 items-start", gridCols)}>
        {mergedGroups.map(({ main, subs }) => (
            <div key={main.tableNumber} className="border-2 border-dashed border-pink-500/30 rounded-3xl p-3 col-span-2 md:col-span-3 lg:col-span-4">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {[main, ...subs].sort((a,b) => a.tableNumber - b.tableNumber).map(table => (
                       <TableCard 
                          key={table.tableNumber}
                          table={table}
                          isSelectionMode={isSelectionMode}
                          isSelected={selectedTables.has(table.tableNumber)}
                          isUpdatingClear={updatingIds.has(`table-clear-${table.tableNumber}`)}
                          staffRole={staffRole}
                          onTableClick={onTableClick}
                          onManagePinClick={onManagePinClick}
                       />
                    ))}
                </div>
            </div>
        ))}

        {tablesToDisplay.map(table => {
          const isSelected = selectedTables.has(table.tableNumber);
          const isUpdatingClear = updatingIds.has(`table-clear-${table.tableNumber}`);

          if (table.status === TableStatus.EMPTY) {
             return (
                <Card
                    key={table.tableNumber}
                    padding="p-4"
                    className={clsx(
                        'text-center bg-gray-800/80 opacity-70 relative transition-all duration-200',
                        isSelectionMode && 'cursor-pointer hover:opacity-100',
                        isSelected && 'ring-2 ring-offset-2 ring-rose-500 dark:ring-offset-gray-950 opacity-100'
                    )}
                    onClick={() => isSelectionMode && onTableClick(table)}
                >
                    <p className="text-2xl font-bold text-gray-500">{table.tableNumber}</p>
                    {isSelected && (
                        <div className="absolute inset-0 bg-rose-500/30 rounded-3xl flex items-center justify-center pointer-events-none">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                    )}
                </Card>
             );
          }

          return (
             <TableCard 
                key={table.tableNumber}
                table={table}
                isSelectionMode={isSelectionMode}
                isSelected={isSelected}
                isUpdatingClear={isUpdatingClear}
                staffRole={staffRole}
                onTableClick={onTableClick}
                onManagePinClick={onManagePinClick}
             />
          );
        })}
      </div>
    </div>
  );
};
      