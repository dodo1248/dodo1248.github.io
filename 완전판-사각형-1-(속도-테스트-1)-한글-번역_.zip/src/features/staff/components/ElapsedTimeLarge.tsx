import React, { useState, useEffect } from 'react';

const formatDuration = (ms: number): { text: string; isOvertime: boolean } => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    let parts = [];
    if (hours > 0) parts.push(`${hours}시간`);
    
    // Show minutes, e.g., "1시간 5분" or "5분"
    if (minutes > 0 || hours > 0) {
        parts.push(`${minutes}분`);
    }

    // Handle case for less than 1 minute
    if (hours === 0 && minutes === 0) {
      return { text: '방금', isOvertime: false };
    }

    // Set a threshold for "overtime", e.g., 2 hours
    const isOvertime = hours >= 2;

    const text = parts.join(' ') || '0분';
    return { text: `${text} 경과`, isOvertime };
};

export const ElapsedTimeLarge: React.FC<{ timestamp: number }> = ({ timestamp }) => {
    const [durationInfo, setDurationInfo] = useState({ text: '0분 경과', isOvertime: false });

    useEffect(() => {
        const calculateTime = () => {
            const elapsedMs = Date.now() - timestamp;
            setDurationInfo(formatDuration(elapsedMs));
        };

        calculateTime();
        const intervalId = setInterval(calculateTime, 30000); // Update every 30 seconds
        return () => clearInterval(intervalId);
    }, [timestamp]);
    
    const textColor = durationInfo.isOvertime 
        ? 'text-red-500 animate-pulse' 
        : 'text-rose-500 dark:text-rose-400';

    return <p className={`text-3xl font-black ${textColor}`}>{durationInfo.text}</p>;
};