import React, { useState, useEffect } from 'react';

export const ElapsedTime: React.FC<{ timestamp: number; onTimeExceeded: (minutes: number) => void }> = React.memo(({ timestamp, onTimeExceeded }) => {
    const [elapsedText, setElapsedText] = useState('');
    useEffect(() => {
        const calculateTime = () => {
            const diffSeconds = Math.floor((Date.now() - timestamp) / 1000);
            const minutes = Math.floor(diffSeconds / 60);
            onTimeExceeded(minutes);
            setElapsedText(minutes > 0 ? `${minutes}분 경과` : `${diffSeconds}초 경과`);
        };
        calculateTime();
        const intervalId = setInterval(calculateTime, 10000);
        return () => clearInterval(intervalId);
    }, [timestamp, onTimeExceeded]);
    return <span className="text-xs font-medium text-gray-500 dark:text-gray-400">{elapsedText}</span>;
});