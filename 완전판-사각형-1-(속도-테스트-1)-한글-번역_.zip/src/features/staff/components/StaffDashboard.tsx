
import React, { useState, useMemo, useEffect } from 'react';
import { StaffPage, StaffRole } from '../staff.types';
import { OrderStatus, TableStatus } from '../../../shared/types';
import {
  DashboardView,
  VerificationView,
  OrderManagement,
  KitchenView,
  ServingView,
  TableStatusDashboard,
  HallDutyView,
  MenuManagement,
  SalesStats,
  SalesAnalysisDashboard,
} from '../pages';
import { Loading } from '../../../shared/components/Loading';
import { Modal } from '../../../shared/components/Modal';
import { Button } from '../../../shared/components/Button';
import { STORAGE_KEYS } from '../../../shared/constants';
import { ChangePinModal } from './ChangePinModal';
import { ChangeManagerPinModal } from './ChangeManagerPinModal';
import { StaffLayout } from './StaffLayout';
import { StaffHeader } from './StaffHeader';
import { StaffSidebar } from './StaffSidebar';
import { useOrders } from '../contexts/OrdersContext';
import { useTables } from '../contexts/TablesContext';
import { staffApi } from '../../../shared/api/staff';

interface StaffDashboardProps {
  onLogout: () => void;
  staffRole: StaffRole;
  onChangeRole: () => void;
}

const MANAGER_PAGES: StaffPage[] = [ StaffPage.DASHBOARD, StaffPage.VERIFICATION, StaffPage.ORDERS, StaffPage.KITCHEN, StaffPage.SERVING, StaffPage.TABLES, StaffPage.HALL_DUTY, StaffPage.MENU, StaffPage.STATS, StaffPage.ANALYSIS ];
const HALL_PAGES: StaffPage[] = [ StaffPage.DASHBOARD, StaffPage.VERIFICATION, StaffPage.SERVING, StaffPage.TABLES, StaffPage.HALL_DUTY ];
const KITCHEN_PAGES: StaffPage[] = [ StaffPage.ORDERS, StaffPage.KITCHEN ];

export const StaffDashboard: React.FC<StaffDashboardProps> = ({ onLogout, staffRole, onChangeRole }) => {
  const { orders, isLoading, isRefreshing, actions: orderActions, operatingDay } = useOrders();
  const { tables } = useTables();

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [dayChangeTarget, setDayChangeTarget] = useState<1 | 2 | null>(null);
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [isManagerPinModalOpen, setIsManagerPinModalOpen] = useState(false);

  const availablePages = useMemo(() => {
    switch (staffRole) {
      case 'hall': return HALL_PAGES;
      case 'kitchen': return KITCHEN_PAGES;
      case 'manager':
      default: return MANAGER_PAGES;
    }
  }, [staffRole]);

  const [activePage, setActivePage] = useState<StaffPage>(() => {
    const savedPage = sessionStorage.getItem(STORAGE_KEYS.STAFF_ACTIVE_PAGE) as StaffPage;
    if (savedPage && availablePages.includes(savedPage)) {
        return savedPage;
    }
    if (staffRole === 'hall' && availablePages.includes(StaffPage.VERIFICATION)) {
      return StaffPage.VERIFICATION;
    }
    return availablePages[0];
  });
  
  useEffect(() => {
    if (!availablePages.includes(activePage)) {
      setActivePage(availablePages[0]);
    }
  }, [availablePages, activePage]);

  useEffect(() => {
    sessionStorage.setItem(STORAGE_KEYS.STAFF_ACTIVE_PAGE, activePage);
  }, [activePage]);

  const pageCounts = useMemo(() => ({
      verification: orders.filter(o => o.isActive && o.status === OrderStatus.PAYMENT_SUBMITTED).length,
      orders: orders.filter(o => o.isActive && (o.status === OrderStatus.PAYMENT_CONFIRMED || o.status === OrderStatus.IN_KITCHEN)).length,
      serving: orders.filter(o => o.isActive && o.status === OrderStatus.READY_TO_SERVE).length,
      calls: tables.filter(t => t.status === TableStatus.CALLED).length,
  }), [orders, tables]);

  const renderPage = () => {
    if (isLoading && !isRefreshing) {
      return <div className="flex items-center justify-center h-[calc(100vh-200px)]"><Loading message="스태프 데이터를 불러오는 중..." /></div>;
    }
    
    switch (activePage) {
      case StaffPage.DASHBOARD: return <DashboardView setActivePage={setActivePage} />;
      case StaffPage.VERIFICATION: return <VerificationView />;
      case StaffPage.ORDERS: return <OrderManagement />;
      case StaffPage.KITCHEN: return <KitchenView />;
      case StaffPage.SERVING: return <ServingView />;
      case StaffPage.TABLES: return <TableStatusDashboard staffRole={staffRole} />;
      case StaffPage.HALL_DUTY: return <HallDutyView />;
      case StaffPage.MENU: return <MenuManagement />;
      case StaffPage.STATS: return <SalesStats />;
      case StaffPage.ANALYSIS: return <SalesAnalysisDashboard />;
      default: return <div>페이지를 찾을 수 없습니다.</div>;
    }
  };

  const handleConfirmDayChange = async () => {
    if (dayChangeTarget) {
      try {
        await staffApi.setOperatingDay(dayChangeTarget);
        orderActions.setOperatingDay(dayChangeTarget);
      } catch (error) {
        alert('운영일 변경에 실패했습니다.');
      }
    }
    setDayChangeTarget(null);
  };

  const sidebar = (
    <StaffSidebar 
      staffRole={staffRole}
      onChangeRole={onChangeRole}
      availablePages={availablePages}
      activePage={activePage}
      setActivePage={(p) => {
          setActivePage(p);
          setIsSidebarOpen(false);
      }}
      pageCounts={pageCounts}
      operatingDay={operatingDay}
      onDayChange={setDayChangeTarget}
      onLogout={onLogout}
      onOpenManagerPinModal={() => setIsManagerPinModalOpen(true)}
      onOpenPinModal={() => setIsPinModalOpen(true)}
    />
  );

  const header = (
    <StaffHeader 
      isRefreshing={isRefreshing}
      onRefresh={orderActions.refreshOrders}
      onToggleSidebar={() => setIsSidebarOpen(true)}
    />
  );

  return (
    <>
      <StaffLayout
        sidebar={sidebar}
        header={header}
        isSidebarOpen={isSidebarOpen}
        onCloseSidebar={() => setIsSidebarOpen(false)}
      >
        <div className="p-4 md:p-6 animate-page-fade-in" key={activePage}>
            {renderPage()}
        </div>
      </StaffLayout>
      
      <Modal isOpen={!!dayChangeTarget} onClose={() => setDayChangeTarget(null)} title="운영일 변경 확인">
          <div>
              <p className="text-center text-lg dark:text-gray-200">
                  운영일을 <span className="font-bold text-rose-500">{dayChangeTarget}일차</span>로 변경하시겠습니까?
              </p>
              <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">
                  모든 스태프 화면이 선택된 운영일의 데이터로 전환됩니다.
              </p>
              <div className="flex justify-center space-x-4 mt-6">
                  <Button variant="secondary" onClick={() => setDayChangeTarget(null)} className="w-1/2">취소</Button>
                  <Button onClick={handleConfirmDayChange} className="w-1/2">변경</Button>
              </div>
          </div>
      </Modal>

      {staffRole === 'manager' && (
          <>
              <ChangePinModal isOpen={isPinModalOpen} onClose={() => setIsPinModalOpen(false)} />
              <ChangeManagerPinModal isOpen={isManagerPinModalOpen} onClose={() => setIsManagerPinModalOpen(false)} />
          </>
      )}
    </>
  );
};