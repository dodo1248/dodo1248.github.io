import React, { useState, useEffect } from 'react';
import { Modal } from '../../../shared/components/Modal';
import { Button } from '../../../shared/components/Button';

interface CancelOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
  isLoading: boolean;
  tableNumber: number;
}

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({ isOpen, onClose, onConfirm, isLoading, tableNumber }) => {
  const [reason, setReason] = useState('');

  // Reset reason when modal is closed
  useEffect(() => {
    if (!isOpen) {
      setReason('');
    }
  }, [isOpen]);

  const handleConfirm = () => {
    onConfirm(reason);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`테이블 ${tableNumber}번 주문 취소`}>
      <div>
        <p className="text-center text-lg text-gray-800 dark:text-gray-200">정말로 이 주문을 취소하시겠습니까?</p>
        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">이 작업은 되돌릴 수 없으며, 고객에게 환불 절차가 필요할 수 있습니다.</p>
        
        <div className="mt-4">
          <label htmlFor="cancel-reason" className="block text-sm font-bold text-gray-700 dark:text-gray-200 mb-2">취소 사유 (선택 사항)</label>
          <textarea
            id="cancel-reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full bg-white dark:bg-gray-800 dark:text-white p-2 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-500 outline-none transition-colors"
            placeholder="예: 고객 요청, 재료 소진"
            maxLength={100}
            rows={3}
          />
        </div>
        
        <div className="flex justify-center space-x-4 mt-6">
          <Button variant="secondary" onClick={onClose} className="w-1/2" disabled={isLoading}>닫기</Button>
          <Button 
            onClick={handleConfirm} 
            isLoading={isLoading} 
            className="w-1/2 !bg-red-500 hover:!bg-red-600 !shadow-red-400/50"
            >
            주문 취소 확정
          </Button>
        </div>
      </div>
    </Modal>
  );
}
