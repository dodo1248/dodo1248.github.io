import React, { useState, useEffect } from 'react';
import { Modal } from '../../../shared/components/Modal';
import { Button } from '../../../shared/components/Button';
import { PinPad } from './PinPad';
import { staffApi } from '../../../shared/api/staff';
import { Table } from '../../../shared/types';

interface ManageTablePinModalProps {
  isOpen: boolean;
  onClose: () => void;
  table: Table;
}

type ViewState = 'auth' | 'display' | 'resetting' | 'reset_success';

export const ManageTablePinModal: React.FC<ManageTablePinModalProps> = ({ isOpen, onClose, table }) => {
    const [view, setView] = useState<ViewState>('auth');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [newPin, setNewPin] = useState('');
    const [resetPinPadKey, setResetPinPadKey] = useState(0);

    useEffect(() => {
        if (isOpen) {
            setView('auth');
            setError('');
            setIsLoading(false);
            setNewPin('');
            setResetPinPadKey(prev => prev + 1);
        }
    }, [isOpen, table]);

    const handleManagerPinComplete = async (pin: string) => {
        setError('');
        setIsLoading(true);
        try {
            const { isValid } = await staffApi.verifyManagerPin(pin);
            if (isValid) {
                setView('display');
            } else {
                setError('매니저 PIN이 일치하지 않습니다.');
                setResetPinPadKey(prev => prev + 1);
            }
        } catch (e: any) {
            setError(e.message || "PIN 인증 중 오류 발생");
            setResetPinPadKey(prev => prev + 1);
        } finally {
            setIsLoading(false);
        }
    };

    const handleResetPin = async () => {
        setError('');
        setIsLoading(true);
        setView('resetting');
        try {
            const { newPin: generatedPin } = await staffApi.resetCustomerPin(table.tableNumber);
            setNewPin(generatedPin);
            setView('reset_success');
        } catch(e: any) {
            setError(e.message || 'PIN 재설정에 실패했습니다.');
            setView('display'); // Go back to display on error
        } finally {
            setIsLoading(false);
        }
    };

    const renderContent = () => {
        switch (view) {
            case 'auth':
                return (
                    <PinPad
                        key={resetPinPadKey}
                        title="매니저 PIN 입력"
                        onComplete={handleManagerPinComplete}
                        error={error}
                    />
                );
            case 'display':
                return (
                    <div className="text-center">
                        <p className="text-lg text-gray-300">
                          {table.pinHash ? '이 테이블에는 PIN이 설정되어 있습니다.' : '이 테이블에는 PIN이 설정되어 있지 않습니다.'}
                        </p>
                        <p className="text-sm text-gray-400 mt-2">보안상의 이유로 설정된 PIN은<br/>조회할 수 없으며 재설정만 가능합니다.</p>
                        {error && <p className="text-red-500 font-semibold my-4">{error}</p>}
                        <div className="space-y-3 mt-6">
                            <Button onClick={handleResetPin} isLoading={isLoading}>새로운 PIN으로 재설정</Button>
                            <Button variant="secondary" onClick={onClose}>닫기</Button>
                        </div>
                    </div>
                );
            case 'resetting':
                 return (
                    <div className="text-center min-h-[200px] flex flex-col justify-center items-center">
                        <svg className="animate-spin h-10 w-10 text-rose-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <p className="mt-4 font-bold text-gray-300">새로운 PIN 생성 중...</p>
                    </div>
                );
            case 'reset_success':
                return (
                    <div className="text-center">
                        <p className="text-lg text-green-400 font-bold">✅ 재설정 완료!</p>
                        <p className="text-lg text-gray-300 mt-2">고객에게 안내할 새로운 PIN</p>
                        <p className="text-6xl font-black my-4 text-white tracking-widest">{newPin}</p>
                        <Button variant="secondary" onClick={onClose}>닫기</Button>
                    </div>
                );
        }
    };
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`테이블 ${table.tableNumber}번 PIN 관리`}>
            {renderContent()}
        </Modal>
    )
};