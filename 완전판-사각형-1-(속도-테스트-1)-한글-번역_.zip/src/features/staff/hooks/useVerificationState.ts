
import { useState, useCallback } from 'react';
import { useOrders } from '../contexts/OrdersContext';
import { OrderStatus } from '../../../shared/types';

export const useVerificationState = () => {
    const { actions, updatingIds } = useOrders();
    const [isSelectionMode, setIsSelectionMode] = useState(false);
    const [selectedOrders, setSelectedOrders] = useState<Set<string>>(new Set());

    const toggleSelectionMode = useCallback(() => {
        setIsSelectionMode(prev => !prev);
        setSelectedOrders(new Set());
    }, []);

    const handleOrderClick = useCallback((orderId: string) => {
        if (!isSelectionMode) return;
        setSelectedOrders(prev => {
            const newSet = new Set(prev);
            if (newSet.has(orderId)) {
                newSet.delete(orderId);
            } else {
                newSet.add(orderId);
            }
            return newSet;
        });
    }, [isSelectionMode]);

    const handleConfirmMultiple = useCallback(async () => {
        if (selectedOrders.size === 0) return;
        
        try {
            await actions.updateMultipleOrderStatus(Array.from(selectedOrders), OrderStatus.PAYMENT_CONFIRMED);
        } catch (error) {
            // The context handles individual errors and alerts, but we can log here if needed.
            console.error("Batch confirmation failed for some orders:", error);
        } finally {
            toggleSelectionMode(); // Exit selection mode after action
        }
    }, [actions, selectedOrders, toggleSelectionMode]);

    return {
        isSelectionMode,
        selectedOrders,
        toggleSelectionMode,
        handleOrderClick,
        handleConfirmMultiple,
        updatingIds, // Pass through for loading states
    };
};
