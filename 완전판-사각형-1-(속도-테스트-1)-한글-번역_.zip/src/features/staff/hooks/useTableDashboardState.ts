
import { useState, useCallback } from 'react';
import { Table, TableStatus } from '../../../shared/types';
import { useTables } from '../contexts/TablesContext';
import { useOrders } from '../contexts/OrdersContext';
import { TABLE_CLEAR_WARNING_THRESHOLD_MINUTES } from '../../../shared/constants';

export const useTableDashboardState = () => {
    const { orders } = useOrders();
    const { tables, actions } = useTables();
    const [isClearModalOpen, setIsClearModalOpen] = useState(false);
    const [isMultiClearModalOpen, setIsMultiClearModalOpen] = useState(false);
    const [isManagePinModalOpen, setIsManagePinModalOpen] = useState(false);
    const [isMergeModalOpen, setIsMergeModalOpen] = useState(false);
    const [isMergePinModalOpen, setIsMergePinModalOpen] = useState(false);
    const [mergeConfig, setMergeConfig] = useState<{ main: number, subs: number[] } | null>(null);
    const [selectedTable, setSelectedTable] = useState<Table | null>(null);
    const [clearWarningMessage, setClearWarningMessage] = useState<string | null>(null);
    const [isSelectionMode, setIsSelectionMode] = useState(false);
    const [selectedTables, setSelectedTables] = useState<Set<number>>(new Set());

    const handleTableClick = useCallback((table: Table) => {
        if (isSelectionMode) {
            setSelectedTables(prev => {
                const newSet = new Set(prev);
                if (newSet.has(table.tableNumber)) newSet.delete(table.tableNumber);
                else newSet.add(table.tableNumber);
                return newSet;
            });
        } else {
            // Only 'IDLE' or merged tables should open the clear/unmerge modal
            if(table.status !== TableStatus.IDLE) return;
            
            const lastOrder = orders
                .filter(o => o.tableNumber === table.tableNumber)
                .sort((a, b) => b.timestamp - a.timestamp)[0];

            if (lastOrder) {
                const minutesSince = Math.floor((Date.now() - lastOrder.timestamp) / 60000);
                if (minutesSince < TABLE_CLEAR_WARNING_THRESHOLD_MINUTES) {
                    setClearWarningMessage(`⚠️ 주의: 이 테이블의 마지막 주문이 약 ${minutesSince}분 전에 있었습니다.`);
                } else {
                    setClearWarningMessage(null);
                }
            } else {
                 setClearWarningMessage(null);
            }
            if (table.isMainTable || table.mergedWith) {
                 setClearWarningMessage((prev) => (prev ? prev + '\n' : '') + '이 테이블은 합석 그룹에 포함되어 있습니다. 상태 변경 시 합석이 해제됩니다.');
            }
            setSelectedTable(table);
            setIsClearModalOpen(true);
        }
    }, [isSelectionMode, orders]);

    const handleOpenManagePinModal = useCallback((table: Table) => {
        setSelectedTable(table);
        setIsManagePinModalOpen(true);
    }, []);

    const handleCloseManagePinModal = useCallback(() => {
        setIsManagePinModalOpen(false);
        setSelectedTable(null);
    }, []);

    const handleCloseClearModal = useCallback(() => {
        setIsClearModalOpen(false);
        setSelectedTable(null);
        setClearWarningMessage(null);
    }, []);

    const handleConfirmClearTable = useCallback(() => {
        if (!selectedTable) return;
        // Close modal immediately for a responsive UI.
        handleCloseClearModal();
        // Perform the action in the background. The context's optimistic update handles the UI change.
        actions.clearTable(selectedTable.tableNumber).catch(error => {
            // The context's optimistic update logic already shows an alert on failure.
            // We can log here for debugging if needed.
            console.error('Background table clear failed:', error);
        });
    }, [selectedTable, actions, handleCloseClearModal]);

    const toggleSelectionMode = useCallback(() => {
        setIsSelectionMode(prev => !prev);
        setSelectedTables(new Set());
    }, []);

    const handleOpenMultiClearModal = useCallback(() => {
        const recentOrderTables = Array.from(selectedTables).filter(tableNum => {
            const lastOrder = orders.filter(o => o.tableNumber === tableNum).sort((a, b) => b.timestamp - a.timestamp)[0];
            if (!lastOrder) return false;
            const minutesSince = Math.floor((Date.now() - lastOrder.timestamp) / 60000);
            return minutesSince < TABLE_CLEAR_WARNING_THRESHOLD_MINUTES;
        });

        if (recentOrderTables.length > 0) {
            setClearWarningMessage(`⚠️ 주의: ${recentOrderTables.join(', ')}번 테이블에 최근 주문이 있습니다.`);
        } else {
            setClearWarningMessage(null);
        }
        setIsMultiClearModalOpen(true);
    }, [selectedTables, orders]);
    
    const handleConfirmMultiClear = useCallback(() => {
        // Perform action in the background
        actions.clearMultipleTables(Array.from(selectedTables)).catch(error => {
            console.error('Background multi-table clear failed:', error);
        });
    
        // Close modal and reset state immediately
        setIsMultiClearModalOpen(false);
        setClearWarningMessage(null);
        setIsSelectionMode(false);
        setSelectedTables(new Set());
    }, [actions, selectedTables]);
    
    const handleOpenMergeModal = useCallback(() => {
        const selectedTableObjects = tables.filter(t => selectedTables.has(t.tableNumber));
        const areAllEmpty = selectedTableObjects.length > 0 && selectedTableObjects.every(t => t.status === TableStatus.EMPTY);

        if (!areAllEmpty) {
            alert('비어있는 테이블만 합석할 수 있습니다.');
            return;
        }

        if (selectedTables.size > 1) {
            setIsMergeModalOpen(true);
        }
    }, [selectedTables, tables]);

    const handleCloseMergeModal = useCallback(() => {
        setIsMergeModalOpen(false);
    }, []);

    const handleSelectMainForMerge = useCallback((mainTableNumber: number) => {
        const subTableNumbers = Array.from(selectedTables).filter(t => t !== mainTableNumber);
        setMergeConfig({ main: mainTableNumber, subs: subTableNumbers });
        setIsMergeModalOpen(false);
        setIsMergePinModalOpen(true);
    }, [selectedTables]);

    const handleCloseMergePinModal = useCallback(() => {
        setIsMergePinModalOpen(false);
        setMergeConfig(null);
    }, []);
    
    const handleConfirmMergeWithPin = useCallback((pin: string) => {
        if (!mergeConfig) return;
    
        // Perform action in the background
        actions.mergeTables(mergeConfig.main, mergeConfig.subs, pin).catch(error => {
            console.error('Background table merge failed:', error);
        });
    
        // Close modal and reset state immediately
        setIsMergePinModalOpen(false);
        setMergeConfig(null);
        setIsSelectionMode(false);
        setSelectedTables(new Set());
    }, [actions, mergeConfig]);


    return {
        isClearModalOpen,
        isMultiClearModalOpen,
        isManagePinModalOpen,
        isMergeModalOpen,
        isMergePinModalOpen,
        selectedTable,
        clearWarningMessage,
        isSelectionMode,
        selectedTables,
        handleTableClick,
        handleCloseClearModal,
        handleConfirmClearTable,
        toggleSelectionMode,
        handleOpenMultiClearModal,
        handleConfirmMultiClear,
        setIsMultiClearModalOpen,
        handleOpenManagePinModal,
        handleCloseManagePinModal,
        handleOpenMergeModal,
        handleCloseMergeModal,
        handleSelectMainForMerge,
        handleCloseMergePinModal,
        handleConfirmMergeWithPin,
    };
};
