import { useState } from 'react';

type SortOrder = 'asc' | 'desc';

export const useSearchAndSort = (initialSortOrder: SortOrder = 'asc') => {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOrder, setSortOrder] = useState<SortOrder>(initialSortOrder);

    return {
        searchTerm,
        onSearchChange: setSearchTerm,
        sortOrder,
        onSortOrderChange: setSortOrder,
    };
};
