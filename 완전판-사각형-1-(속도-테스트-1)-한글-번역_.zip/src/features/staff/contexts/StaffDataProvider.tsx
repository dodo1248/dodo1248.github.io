import React, { useEffect, useCallback, useReducer, useRef } from 'react';
// FIX: Import `TableStatus` to resolve 'Cannot find name' error.
import { Order, MenuItem, Table, OrderStatus, TableStatus } from '../../../shared/types';
import { staffApi } from '../../../shared/api/staff';
import { MenuContext } from './MenuContext';
import { OrdersContext } from './OrdersContext';
import { TablesContext } from './TablesContext';
import { NEW_ORDER_FLASH_DURATION } from '../../../shared/constants';
import { supabase } from '../../../shared/api/supabaseClient';

// --- State Management for Data ---

interface DataState {
    orders: Order[];
    menu: MenuItem[];
    tables: Table[];
    operatingDay: 1 | 2;
    isLoading: boolean;
    isRefreshing: boolean;
    error: string | null;
    updatingIds: Set<string | number>;
    newOrderIds: Set<string>;
}

type DataAction =
    | { type: 'FETCH_START' }
    | { type: 'REFRESH_START' }
    | { type: 'FETCH_SUCCESS'; payload: { orders: Order[], menu: MenuItem[], tables: Table[], operatingDay: 1 | 2, newOrders: string[] } }
    | { type: 'FETCH_ERROR'; payload: string }
    | { type: 'SET_OPERATING_DAY'; payload: 1 | 2 }
    | { type: 'SET_UPDATING'; payload: { id: string | number, isUpdating: boolean } }
    | { type: 'OPTIMISTIC_UPDATE'; payload: Partial<DataState> }
    | { type: 'CLEAR_NEW_ORDERS' };

const initialState: DataState = {
    orders: [],
    menu: [],
    tables: [],
    operatingDay: 1,
    isLoading: true,
    isRefreshing: false,
    error: null,
    updatingIds: new Set(),
    newOrderIds: new Set(),
};

const dataReducer = (state: DataState, action: DataAction): DataState => {
    switch (action.type) {
        case 'FETCH_START': return { ...state, isLoading: true };
        case 'REFRESH_START': return { ...state, isRefreshing: true };
        case 'FETCH_SUCCESS':
            return {
                ...state,
                ...action.payload,
                isLoading: false,
                isRefreshing: false,
                error: null,
                newOrderIds: new Set(action.payload.newOrders),
            };
        case 'FETCH_ERROR': return { ...state, isLoading: false, isRefreshing: false, error: action.payload };
        case 'SET_OPERATING_DAY': return { ...state, operatingDay: action.payload };
        case 'SET_UPDATING': {
            const newUpdatingIds = new Set(state.updatingIds);
            if (action.payload.isUpdating) newUpdatingIds.add(action.payload.id);
            else newUpdatingIds.delete(action.payload.id);
            return { ...state, updatingIds: newUpdatingIds };
        }
        case 'OPTIMISTIC_UPDATE':
            return { ...state, ...action.payload };
        case 'CLEAR_NEW_ORDERS':
             return { ...state, newOrderIds: new Set() };
        default: return state;
    }
};

// --- The Provider Component ---

export const StaffDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [state, dispatch] = useReducer(dataReducer, initialState);
    const stateRef = useRef(state);
    
    useEffect(() => {
        stateRef.current = state;
    }, [state]);

    const fetchData = useCallback(async (day: 1 | 2, isRefresh = false) => {
        if (!isRefresh) {
            dispatch({ type: 'FETCH_START' });
        } else {
            dispatch({ type: 'REFRESH_START' });
        }
        try {
            const { orders, menu, tables, operatingDay } = await staffApi.fetchStaffData(day);
            const currentOrderIds = new Set(stateRef.current.orders.map(o => o.id));
            
            // Only flash for brand new orders that need payment verification.
            const newOrders = orders
                .filter(o => !currentOrderIds.has(o.id) && o.status === OrderStatus.PAYMENT_SUBMITTED)
                .map(o => o.id);
            
            dispatch({ type: 'FETCH_SUCCESS', payload: { orders, menu, tables, operatingDay, newOrders } });

             if (newOrders.length > 0) {
                setTimeout(() => dispatch({ type: 'CLEAR_NEW_ORDERS' }), NEW_ORDER_FLASH_DURATION);
            }

        } catch (e: any) {
            alert(`데이터를 불러오는 데 실패했습니다: ${e.message}`);
            dispatch({ type: 'FETCH_ERROR', payload: e.message });
        }
    }, []);

    // Initial data fetch
    useEffect(() => {
        fetchData(state.operatingDay);
    }, [fetchData, state.operatingDay]); 

    const handleRealtimeUpdate = useCallback((payload: any) => {
        const { table, new: newRecord } = payload;
        const currentState = stateRef.current;

        // Handle operating day change separately, as it dictates which data to fetch.
        if (table === 'settings' && newRecord?.key === 'operating_day') {
            const newDay = newRecord.value?.day;
            if (newDay && newDay !== currentState.operatingDay) {
                console.log(`[Realtime] Operating day changed from ${currentState.operatingDay} to ${newDay}. Triggering full state change.`);
                // This dispatch will trigger the useEffect to refetch data for the new day.
                dispatch({ type: 'SET_OPERATING_DAY', payload: newDay });
            }
            return; // Stop further processing for this specific event.
        }
        
        const relevantTables = ['orders', 'order_items', 'tables', 'menu_items'];
        if (relevantTables.includes(table)) {
            console.log(`[Realtime] Change detected on table '${table}'. Refreshing all staff data for consistency.`);
            fetchData(currentState.operatingDay, true);
        }
    }, [fetchData]);

    // Dual-Layer Sync: Real-time + Polling Fail-safe
    useEffect(() => {
        // Layer 1: Real-time subscription
        const channel = supabase
            .channel('hbw-staff-realtime-all')
            .on('postgres_changes', { event: '*', schema: 'public' }, handleRealtimeUpdate)
            .subscribe((status, err) => {
                if (status === 'SUBSCRIBED') {
                    console.log('✅ Staff real-time connection established.');
                }
                if (status === 'CHANNEL_ERROR') {
                    console.error('❌ Staff real-time connection error:', err);
                    alert('실시간 동기화 연결에 문제가 발생했습니다. 1초마다 자동 새로고침으로 데이터를 보정합니다.');
                }
            });
            
        // Layer 2: Aggressive polling as a fail-safe
        const intervalId = setInterval(() => {
            if (!document.hidden) {
                console.log('[Fail-safe] Performing periodic data sync to ensure consistency...');
                fetchData(stateRef.current.operatingDay, true);
            }
        }, 1000); // Sync every 1 second

        return () => {
            clearInterval(intervalId);
            supabase.removeChannel(channel);
        };
    }, [handleRealtimeUpdate, fetchData]);


    // --- Generic Optimistic Update Handler ---
    const withOptimisticUpdate = useCallback(async <T extends any[]>(
        ids: (string | number)[],
        action: (...args: T) => Promise<any>,
        optimisticUpdate: (state: DataState) => Partial<DataState>,
        ...args: T
    ) => {
        const originalState = { orders: stateRef.current.orders, menu: stateRef.current.menu, tables: stateRef.current.tables };
        ids.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: true } }));
        
        dispatch({ type: 'OPTIMISTIC_UPDATE', payload: optimisticUpdate(stateRef.current) });

        try {
            await action(...args);
            // On success, the real-time subscription will trigger a refetch, ensuring data consistency.
        } catch (e: any) {
            alert(`작업 실패: ${e.message}`);
            dispatch({ type: 'OPTIMISTIC_UPDATE', payload: originalState }); // Revert on failure
        } finally {
            ids.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: false } }));
        }
    }, []);


    // --- Context Values ---

    const ordersContextValue = {
        orders: state.orders,
        newOrderIds: state.newOrderIds,
        updatingIds: state.updatingIds,
        isLoading: state.isLoading,
        isRefreshing: state.isRefreshing,
        operatingDay: state.operatingDay,
        actions: {
            setOperatingDay: (day: 1 | 2) => dispatch({ type: 'SET_OPERATING_DAY', payload: day }),
            refreshOrders: () => fetchData(state.operatingDay, true),
            updateOrderStatus: (orderId: string, status: OrderStatus) => withOptimisticUpdate(
                [orderId],
                staffApi.updateOrderStatus,
                (s) => ({ orders: s.orders.map(o => o.id === orderId ? { ...o, status, items: o.items.map(i => ({...i, status: status as unknown as OrderStatus})) } : o) }),
                orderId, status
            ),
            updateMultipleOrderStatus: async (orderIds: string[], status: OrderStatus) => {
                const ids = orderIds;
                ids.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: true } }));
                const originalOrders = state.orders;
                dispatch({ type: 'OPTIMISTIC_UPDATE', payload: { orders: state.orders.map(o => ids.includes(o.id) ? { ...o, status, items: o.items.map(i => ({...i, status: status as unknown as OrderStatus})) } : o) }});

                try {
                    await Promise.all(ids.map(id => staffApi.updateOrderStatus(id, status)));
                } catch(e: any) {
                    alert(`일부 주문 상태 변경 실패: ${e.message}`);
                    dispatch({ type: 'OPTIMISTIC_UPDATE', payload: { orders: originalOrders }});
                } finally {
                     ids.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: false } }));
                }
            },
            updateOrderItemStatus: (itemUniqueId: string, status: OrderStatus) => withOptimisticUpdate(
                [itemUniqueId],
                staffApi.updateOrderItemStatus,
                (s) => ({
                    orders: s.orders.map(o => ({
                        ...o,
                        items: o.items.map(i => i.uniqueId === itemUniqueId ? { ...i, status } : i)
                    }))
                }),
                itemUniqueId, status
            ),
            addOrderMemo: (orderId: string, memo: string) => withOptimisticUpdate(
                [orderId], staffApi.addOrderMemo, s => ({ orders: s.orders.map(o => o.id === orderId ? { ...o, memo } : o) }), orderId, memo
            ),
            cancelOrder: (orderId: string, reason: string) => withOptimisticUpdate(
                [orderId], staffApi.cancelOrder, s => ({ orders: s.orders.filter(o => o.id !== orderId) }), orderId, reason
            ),
        }
    };
    
    const menuContextValue = {
        menu: state.menu,
        updatingIds: state.updatingIds,
        actions: {
            updateMenuSoldOut: (itemId: number, isSoldOut: boolean) => withOptimisticUpdate(
                [itemId], staffApi.updateMenuSoldOut, s => ({ menu: s.menu.map(m => m.id === itemId ? { ...m, isSoldOut } : m) }), itemId, isSoldOut
            ),
        }
    };

    const tablesContextValue = {
        tables: state.tables,
        updatingIds: state.updatingIds,
        actions: {
            resolveCall: (tableNumber: number) => withOptimisticUpdate(
                [tableNumber], staffApi.resolveCall, s => ({ tables: s.tables.map(t => t.tableNumber === tableNumber ? { ...t, status: '식사 중', reason: undefined } : t) }), tableNumber
            ),
            clearTable: (tableNumber: number) => withOptimisticUpdate(
                [`table-clear-${tableNumber}`], staffApi.clearTable, 
                (s) => {
                    const clickedTable = s.tables.find(t => t.tableNumber === tableNumber);
                    if (!clickedTable) return { tables: s.tables };

                    const mainTableNum = clickedTable.mergedWith || (clickedTable.isMainTable ? clickedTable.tableNumber : tableNumber);
                    
                    const groupTableNumbers = new Set<number>();
                    groupTableNumbers.add(mainTableNum);
                    s.tables.forEach(t => {
                        if (t.mergedWith === mainTableNum) {
                            groupTableNumbers.add(t.tableNumber);
                        }
                    });

                    const updatedTables = s.tables.map(t => {
                        if (groupTableNumbers.has(t.tableNumber)) {
                            return {
                                ...t,
                                status: TableStatus.EMPTY,
                                pinHash: undefined,
                                isMainTable: false,
                                mergedWith: undefined,
                                reason: undefined,
                            };
                        }
                        return t;
                    });
                    return { tables: updatedTables };
                },
                tableNumber
            ),
             clearMultipleTables: async (tableNumbers: number[]) => {
                const idsToUpdate = tableNumbers.map(n => `table-clear-${n}`);
                idsToUpdate.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: true } }));
                
                const originalTables = state.tables;

                const mainTablesToClear = new Set<number>();
                tableNumbers.forEach(num => {
                    const table = originalTables.find(t => t.tableNumber === num);
                    if (table) {
                        const mainTableNum = table.mergedWith || (table.isMainTable ? table.tableNumber : table.tableNumber);
                        mainTablesToClear.add(mainTableNum);
                    }
                });
                
                const allTablesInGroupsToClear = new Set<number>();
                originalTables.forEach(t => {
                    if (mainTablesToClear.has(t.tableNumber) || (t.mergedWith && mainTablesToClear.has(t.mergedWith))) {
                        allTablesInGroupsToClear.add(t.tableNumber);
                    }
                });

                const updatedTables = originalTables.map(t => {
                    if (allTablesInGroupsToClear.has(t.tableNumber)) {
                        return {
                            ...t,
                            // FIX: Use `TableStatus.EMPTY` instead of an `OrderStatus` value for clearing tables.
                            status: TableStatus.EMPTY,
                            pinHash: undefined,
                            isMainTable: false,
                            mergedWith: undefined,
                            reason: undefined,
                        };
                    }
                    return t;
                });

                dispatch({ type: 'OPTIMISTIC_UPDATE', payload: { tables: updatedTables } });

                try {
                    await Promise.all(tableNumbers.map(n => staffApi.clearTable(n)));
                } catch (e: any) {
                    alert(`일부 테이블 정리 실패: ${e.message}`);
                    dispatch({ type: 'OPTIMISTIC_UPDATE', payload: { tables: originalTables }});
                } finally {
                    idsToUpdate.forEach(id => dispatch({ type: 'SET_UPDATING', payload: { id, isUpdating: false } }));
                }
            },
            mergeTables: (mainTableNumber: number, subTableNumbers: number[], pin: string) => withOptimisticUpdate(
                [mainTableNumber, ...subTableNumbers], staffApi.mergeTables, s => ({
                    tables: s.tables.map(t => {
                        if (t.tableNumber === mainTableNumber) return { ...t, isMainTable: true, status: '식사 중', pinHash: 'merged' }; // Set dummy pinHash
                        if (subTableNumbers.includes(t.tableNumber)) return { ...t, mergedWith: mainTableNumber, status: '식사 중' };
                        return t;
                    })
                }),
                mainTableNumber, subTableNumbers, pin
            ),
            unmergeTables: (tableNumber: number) => withOptimisticUpdate(
                [tableNumber], staffApi.unmergeTables, s => ({ tables: s.tables /* API will refetch */ }), tableNumber
            ),
        },
    };

    return (
        <OrdersContext.Provider value={ordersContextValue}>
            <MenuContext.Provider value={menuContextValue}>
                <TablesContext.Provider value={tablesContextValue}>
                    {children}
                </TablesContext.Provider>
            </MenuContext.Provider>
        </OrdersContext.Provider>
    );
};