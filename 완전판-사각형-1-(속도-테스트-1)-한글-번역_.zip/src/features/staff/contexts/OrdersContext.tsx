
import React, { createContext, useContext } from 'react';
import { Order, OrderStatus } from '../../../shared/types';

type UpdatingId = string | number;

interface OrdersContextType {
    orders: Order[];
    newOrderIds: Set<string>;
    updatingIds: Set<UpdatingId>;
    isLoading: boolean;
    isRefreshing: boolean;
    operatingDay: 1 | 2;
    actions: {
        setOperatingDay: (day: 1 | 2) => void;
        refreshOrders: () => Promise<void>;
        updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
        updateMultipleOrderStatus: (orderIds: string[], status: OrderStatus) => Promise<void>;
        updateOrderItemStatus: (itemUniqueId: string, status: OrderStatus) => Promise<void>;
        addOrderMemo: (orderId: string, memo: string) => Promise<void>;
        cancelOrder: (orderId: string, reason: string) => Promise<void>;
    };
}

// 1. Create the context with a null default value.
export const OrdersContext = createContext<OrdersContextType | null>(null);

// 2. Create a custom hook for easy consumption of the context.
export const useOrders = () => {
    const context = useContext(OrdersContext);
    if (!context) {
        throw new Error('useOrders must be used within a StaffDataProvider');
    }
    return context;
};
