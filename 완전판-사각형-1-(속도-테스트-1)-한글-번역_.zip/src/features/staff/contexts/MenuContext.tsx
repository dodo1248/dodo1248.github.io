import React, { createContext, useContext } from 'react';
import { MenuItem } from '../../../shared/types';

type UpdatingId = string | number;

interface MenuContextType {
    menu: MenuItem[];
    updatingIds: Set<UpdatingId>;
    actions: {
        updateMenuSoldOut: (itemId: number, isSoldOut: boolean) => Promise<void>;
    };
}

// 1. Create the context with a null default value.
export const MenuContext = createContext<MenuContextType | null>(null);

// 2. Create a custom hook for easy consumption of the context.
export const useMenu = () => {
    const context = useContext(MenuContext);
    if (!context) {
        throw new Error('useMenu must be used within a StaffDataProvider');
    }
    return context;
};
