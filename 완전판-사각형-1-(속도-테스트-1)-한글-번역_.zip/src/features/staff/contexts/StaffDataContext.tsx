// This file is deprecated and replaced by the modular context structure.
// It can be safely deleted from the project.
// The new structure consists of:
// - features/staff/contexts/OrdersContext.tsx
// - features/staff/contexts/MenuContext.tsx
// - features/staff/contexts/TablesContext.tsx
// - features/staff/contexts/StaffDataProvider.tsx (which composes the above)
export {};
