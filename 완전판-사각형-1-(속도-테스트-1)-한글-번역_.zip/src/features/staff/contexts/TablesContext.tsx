import React, { createContext, useContext } from 'react';
import { Table } from '../../../shared/types';

type UpdatingId = string | number;

interface TablesContextType {
    tables: Table[];
    updatingIds: Set<UpdatingId>;
    actions: {
        resolveCall: (tableNumber: number) => Promise<void>;
        clearTable: (tableNumber: number) => Promise<void>;
        clearMultipleTables: (tableNumbers: number[]) => Promise<void>;
        mergeTables: (mainTableNumber: number, subTableNumbers: number[], pin: string) => Promise<void>;
        unmergeTables: (tableNumber: number) => Promise<void>;
    };
}

// 1. Create the context with a null default value.
export const TablesContext = createContext<TablesContextType | null>(null);

// 2. Create a custom hook for easy consumption of the context.
export const useTables = () => {
    const context = useContext(TablesContext);
    if (!context) {
        throw new Error('useTables must be used within a StaffDataProvider');
    }
    return context;
};
