
import React, { useMemo } from 'react';
import { Order, OrderStatus, CartItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { useOrders } from '../contexts/OrdersContext';
import { KitchenOrderCard } from '../components/KitchenOrderCard';
import { useMenu } from '../contexts/MenuContext';

interface KitchenTableOrder {
  tableNumber: number;
  items: CartItem[];
  timestamp: number;
  status: OrderStatus;
}

export const KitchenView: React.FC = () => {
    const { orders } = useOrders();
    const { menu } = useMenu();

    const { itemsToCook } = useMemo(() => {
        const activeOrders = orders.filter(o => o.isActive && (o.status === OrderStatus.PAYMENT_CONFIRMED || o.status === OrderStatus.IN_KITCHEN));
        const NON_COOKING_ITEMS = ['콜라/사이다 뚱캔', '물'];
        const itemsToCookMap: { [name: string]: number } = {};
        
        activeOrders.forEach(order => {
            order.items.forEach(item => {
                if (NON_COOKING_ITEMS.includes(item.name)) return;
                itemsToCookMap[item.name] = (itemsToCookMap[item.name] || 0) + item.quantity;
            });
        });

        // Create a map from menu item name to its ID to preserve menu order
        const menuOrderMap = new Map<string, number>();
        menu.forEach(menuItem => {
            menuOrderMap.set(menuItem.name, menuItem.id);
        });

        // Sort items based on their original menu order (by ID)
        const sortedItems = Object.entries(itemsToCookMap).sort((a, b) => {
            const orderA = menuOrderMap.get(a[0]) ?? Infinity;
            const orderB = menuOrderMap.get(b[0]) ?? Infinity;
            return orderA - orderB;
        });
        
        return { itemsToCook: sortedItems };
    }, [orders, menu]);
    
    const tablesToCook = useMemo(() => {
        const activeOrders = orders.filter(o => o.isActive && (o.status === OrderStatus.PAYMENT_CONFIRMED || o.status === OrderStatus.IN_KITCHEN));
        const NON_COOKING_ITEMS = ['콜라/사이다 뚱캔', '물'];

        const tableOrderMap = new Map<number, KitchenTableOrder>();

        activeOrders.forEach(order => {
            const cookingItems = order.items.filter(item => !NON_COOKING_ITEMS.includes(item.name));
            if (cookingItems.length === 0) return;

            if (!tableOrderMap.has(order.tableNumber)) {
                tableOrderMap.set(order.tableNumber, {
                    tableNumber: order.tableNumber,
                    items: [],
                    timestamp: order.timestamp,
                    status: order.status,
                });
            }
            
            const tableOrder = tableOrderMap.get(order.tableNumber)!;
            tableOrder.items.push(...cookingItems);
            if (order.timestamp < tableOrder.timestamp) {
                tableOrder.timestamp = order.timestamp;
            }
            if (order.status === OrderStatus.PAYMENT_CONFIRMED) {
                tableOrder.status = OrderStatus.PAYMENT_CONFIRMED;
            }
        });

        return Array.from(tableOrderMap.values()).sort((a, b) => a.timestamp - b.timestamp);
    }, [orders]);
    
    if (itemsToCook.length === 0) {
        return (
            <Card className="text-center py-16">
                <p className="text-2xl text-gray-400 mb-2">🍳</p>
                <p className="font-bold text-lg text-gray-600 dark:text-gray-300">대기 중인 요리가 없습니다.</p>
            </Card>
        );
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
                <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">🔥 총 조리 필요 메뉴</h2>
                <ul className="space-y-3">
                    {itemsToCook.map(([name, quantity]) => (
                        <li key={name} className="flex justify-between items-center p-3 bg-rose-50 dark:bg-gray-800/70 rounded-lg">
                            <span className="text-lg font-bold text-gray-800 dark:text-gray-200">{name}</span>
                            <span className="text-2xl font-black text-rose-500 dark:text-rose-400">{quantity}개</span>
                        </li>
                    ))}
                </ul>
            </Card>
            
            <div>
                <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">📋 테이블별 조리 현황 ({tablesToCook.length})</h2>
                {tablesToCook.length > 0 ? (
                    <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-2">
                        {tablesToCook.map((tableOrder) => (
                            <KitchenOrderCard key={tableOrder.tableNumber} table={tableOrder} />
                        ))}
                    </div>
                ) : (
                    <Card className="text-center py-12">
                        <p className="font-bold text-lg text-gray-600 dark:text-gray-300">조리 대기 중인 테이블이 없습니다.</p>
                    </Card>
                )}
            </div>
        </div>
    );
};
