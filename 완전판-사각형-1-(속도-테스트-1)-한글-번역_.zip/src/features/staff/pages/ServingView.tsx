
import React, { useMemo, useState, useCallback } from 'react';
import { Order, OrderStatus, CartItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { useOrders } from '../contexts/OrdersContext';
import { SearchAndSortHeader } from '../components/SearchAndSortHeader';
import { useSearchAndSort } from '../hooks/useSearchAndSort';
import { ElapsedTime } from '../components/ElapsedTime';
import { clsx } from '../../../shared/utils/clsx';
import { Modal } from '../../../shared/components/Modal';

const ItemRow: React.FC<{ item: CartItem }> = ({ item }) => {
    const { actions, updatingIds } = useOrders();
    const isUpdating = updatingIds.has(item.uniqueId!);

    const handleToggleItemStatus = () => {
        if (item.status === OrderStatus.SERVED) {
            actions.updateOrderItemStatus(item.uniqueId!, OrderStatus.READY_TO_SERVE);
        } else if (item.status === OrderStatus.READY_TO_SERVE) {
            actions.updateOrderItemStatus(item.uniqueId!, OrderStatus.SERVED);
        }
    };
    
    // Only items that are ready or have just been served are toggleable
    const canToggle = item.status === OrderStatus.READY_TO_SERVE || item.status === OrderStatus.SERVED;

    return (
        <li className="flex justify-between items-center py-2 text-sm">
            <div className="flex items-center">
                {canToggle && (
                    <button 
                        onClick={handleToggleItemStatus} 
                        disabled={isUpdating}
                        className="mr-3 w-5 h-5 flex-shrink-0 rounded border-2 flex items-center justify-center transition-colors disabled:opacity-50
                            border-rose-300 dark:border-gray-500
                            data-[checked=true]:bg-rose-500 data-[checked=true]:border-rose-500"
                        data-checked={item.status === OrderStatus.SERVED}
                        aria-label={`${item.name} 서빙 상태 토글`}
                    >
                         {item.status === OrderStatus.SERVED && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                    </button>
                )}
                <span className={clsx("text-gray-700 dark:text-gray-300", { 'line-through': item.status === OrderStatus.SERVED })}>{item.name}</span>
            </div>
            <span className="font-medium text-gray-800 dark:text-gray-200">x{item.quantity}</span>
        </li>
    );
};

const ServingOrderCard: React.FC<{ order: Order }> = ({ order }) => {
    const { actions, updatingIds } = useOrders();
    const isUpdating = updatingIds.has(order.id);
    const [warningLevel, setWarningLevel] = useState(0);
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

    const handleServeComplete = () => {
        actions.updateOrderStatus(order.id, OrderStatus.SERVED);
    };

    const handleTimeExceeded = useCallback((minutes: number) => {
        if (minutes >= 5) setWarningLevel(2);
        else if (minutes >= 3) setWarningLevel(1);
        else setWarningLevel(0);
    }, []);

    const itemsToServe = order.items.filter(i => i.status === OrderStatus.READY_TO_SERVE || i.status === OrderStatus.SERVED);
    const allItemsChecked = itemsToServe.length > 0 && itemsToServe.every(i => i.status === OrderStatus.SERVED);

    const handleClickServeButton = () => {
        if (allItemsChecked) {
            handleServeComplete();
        } else {
            setIsConfirmModalOpen(true);
        }
    };
    
    const handleConfirmAndComplete = () => {
        handleServeComplete();
        setIsConfirmModalOpen(false);
    };

    const warningClasses: { [key: number]: string } = {
        0: '',
        1: 'border-2 border-yellow-400',
        2: 'border-2 border-red-500 animate-pulse',
    };

    return (
        <>
            <Card className={warningClasses[warningLevel]}>
                <div className="flex justify-between items-start mb-3">
                    <div>
                        <p className="text-xl font-black text-gray-800 dark:text-white">테이블 {order.tableNumber}</p>
                        <ElapsedTime timestamp={order.timestamp} onTimeExceeded={handleTimeExceeded} />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(order.timestamp).toLocaleTimeString('ko-KR')}</p>
                </div>
                <ul className="my-3 divide-y divide-pink-500/10 dark:divide-gray-700/50">
                    {itemsToServe.map(item => (
                       <ItemRow key={item.uniqueId} item={item} />
                    ))}
                </ul>
                {order.request && <p className="p-2 bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 rounded-lg text-sm mt-2">🗣️ 요청: {order.request}</p>}
                <div className="mt-4">
                    <Button 
                        onClick={handleClickServeButton} 
                        isLoading={isUpdating}
                        className={clsx(allItemsChecked && "!bg-green-500 hover:!bg-green-600 !shadow-green-400/50")}
                    >
                        {allItemsChecked ? "✅ 모두 서빙 완료" : "🍽️ 서빙 완료"}
                    </Button>
                </div>
            </Card>
            <Modal
                isOpen={isConfirmModalOpen}
                onClose={() => setIsConfirmModalOpen(false)}
                title="서빙 완료 확인"
            >
                <div>
                    <p className="text-center text-lg text-gray-200">
                      아직 일부 메뉴가 체크되지 않았습니다.<br />
                      정말로 서빙을 완료하시겠습니까?
                    </p>
                    <div className="flex justify-center space-x-4 mt-6">
                        <Button variant="secondary" onClick={() => setIsConfirmModalOpen(false)} className="w-1/2">취소</Button>
                        <Button onClick={handleConfirmAndComplete} isLoading={isUpdating} className="w-1/2">네, 완료합니다</Button>
                    </div>
                </div>
            </Modal>
        </>
    );
};

export const ServingView: React.FC = () => {
    const { orders } = useOrders();
    const { searchTerm, onSearchChange, sortOrder, onSortOrderChange } = useSearchAndSort('asc');

    const servingOrders = useMemo(() => {
        const sorted = orders
            .filter(o => o.isActive && o.status === OrderStatus.READY_TO_SERVE)
            .filter(o => !searchTerm.trim() || o.tableNumber.toString().includes(searchTerm.trim()));
        
        if (sortOrder === 'asc') {
            sorted.sort((a, b) => a.timestamp - b.timestamp);
        } else {
            sorted.sort((a, b) => b.timestamp - a.timestamp);
        }
        return sorted;
    }, [orders, searchTerm, sortOrder]);

    return (
        <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">🍽️ 서빙 대기 목록 ({servingOrders.length})</h2>
            
            <SearchAndSortHeader
                searchTerm={searchTerm}
                onSearchChange={onSearchChange}
                sortOrder={sortOrder}
                onSortOrderChange={onSortOrderChange}
            />
            
            {servingOrders.length === 0 ? (
                <Card className="text-center py-16">
                    <p className="text-2xl text-gray-400 mb-2">✅</p>
                    <p className="font-bold text-lg text-gray-600 dark:text-gray-300">서빙 대기 중인 주문이 없습니다.</p>
                </Card>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {servingOrders.map(order => (
                        <ServingOrderCard key={order.id} order={order} />
                    ))}
                </div>
            )}
        </div>
    );
};
