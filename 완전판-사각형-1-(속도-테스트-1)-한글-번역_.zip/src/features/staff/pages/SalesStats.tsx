import React, { useState, useMemo } from 'react';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { useOrders } from '../contexts/OrdersContext';
import { RevenueModal } from '../components/RevenueModal';
import { OrderStatus } from '../../../shared/types';

type SortByType = 'quantity' | 'revenue' | 'name';

export const SalesStats: React.FC = () => {
    const { orders } = useOrders();
    const [isRevenueModalOpen, setIsRevenueModalOpen] = useState(false);
    const [sortBy, setSortBy] = useState<SortByType>('quantity');

    const { totalRevenue, sortedItemSales, maxValue } = useMemo(() => {
        const validOrders = orders.filter(o => o.status !== OrderStatus.CANCELLED);
        const revenue = validOrders.reduce((sum, order) => sum + order.totalPrice, 0);
        const sales: { [name: string]: { quantity: number; revenue: number } } = {};
        validOrders.forEach(order => order.items.forEach(item => {
            if (!sales[item.name]) sales[item.name] = { quantity: 0, revenue: 0 };
            sales[item.name].quantity += item.quantity;
            sales[item.name].revenue += item.price * item.quantity;
        }));
        
        const salesArray = Object.entries(sales);

        switch (sortBy) {
            case 'revenue':
                salesArray.sort((a, b) => b[1].revenue - a[1].revenue);
                break;
            case 'name':
                salesArray.sort((a, b) => a[0].localeCompare(b[0]));
                break;
            case 'quantity':
            default:
                salesArray.sort((a, b) => b[1].quantity - a[1].quantity);
                break;
        }

        const max = sortBy === 'revenue' 
            ? Math.max(...salesArray.map(item => item[1].revenue), 1)
            : Math.max(...salesArray.map(item => item[1].quantity), 1);

        return { totalRevenue: revenue, sortedItemSales: salesArray, maxValue: max };
    }, [orders, sortBy]);

    const sortButtonClasses = (sort: SortByType) => 
        `px-3 py-1.5 text-sm font-bold rounded-full transition-colors ${
            sortBy === sort 
            ? 'bg-rose-500 text-white shadow [text-shadow:0_1px_2px_rgba(0,0,0,0.4)]' 
            : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300'
        }`;

    return (
        <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-6">매출 통계</h2>
            <Card>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white">메뉴별 판매 현황</h3>
                    <div className="p-1 bg-gray-200 dark:bg-gray-800 rounded-full flex items-center">
                        <button onClick={() => setSortBy('quantity')} className={sortButtonClasses('quantity')}>판매량순</button>
                        <button onClick={() => setSortBy('revenue')} className={sortButtonClasses('revenue')}>매출액순</button>
                        <button onClick={() => setSortBy('name')} className={sortButtonClasses('name')}>이름순</button>
                    </div>
                </div>

                {sortedItemSales.length === 0 ? <p className="text-center text-gray-500 py-8">아직 판매된 메뉴가 없습니다.</p> : <ul className="space-y-4">{sortedItemSales.map(([name, data]) => {
                    const barValue = sortBy === 'revenue' ? data.revenue : data.quantity;
                    const barLabel = sortBy === 'revenue' ? `${data.revenue.toLocaleString()}원` : `${data.quantity}개`;

                    return (
                        <li key={name}>
                            <div className="flex justify-between items-center mb-1 text-sm">
                                <p className="font-bold text-gray-800 dark:text-gray-200">{name}</p>
                                <p className="font-medium text-gray-500 dark:text-gray-400">{barLabel}</p>
                            </div>
                            <div className="w-full bg-rose-100 dark:bg-gray-700 rounded-full h-5">
                                <div className="bg-gradient-to-r from-pink-400 to-rose-500 h-5 rounded-full" style={{ width: `${(barValue / maxValue) * 100}%` }}/>
                            </div>
                        </li>
                    )
                })}</ul>}
            </Card>
            <div className="mt-6"><Button variant="secondary" onClick={() => setIsRevenueModalOpen(true)}>🔒 총 매출액 보기</Button></div>
            <RevenueModal isOpen={isRevenueModalOpen} onClose={() => setIsRevenueModalOpen(false)} totalRevenue={totalRevenue}/>
        </div>
    );
};
