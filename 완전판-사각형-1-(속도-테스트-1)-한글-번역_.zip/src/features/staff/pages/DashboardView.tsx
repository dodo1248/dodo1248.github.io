import React, { useState } from 'react';
import { useOrders } from '../contexts/OrdersContext';
import { useTables } from '../contexts/TablesContext';
import { OrderStatus, TableStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { StaffPage } from '../staff.types';
import { CallListModal } from '../components/CallListModal';

const MetricCard: React.FC<{ icon: string; title: string; count: number; description: string; onClick?: () => void; }> = ({ icon, title, count, description, onClick }) => {
    const isClickable = !!onClick;
    return (
        <button 
            onClick={onClick}
            disabled={!isClickable || count === 0}
            className={`w-full text-left transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed ${isClickable && count > 0 ? 'hover:-translate-y-1' : ''}`}
        >
            <Card className={`text-center p-6 h-full ${count > 0 ? 'border-rose-400' : ''} ${isClickable && count > 0 ? 'hover:shadow-rose-400/20' : ''}`}>
                <div className="text-5xl mb-3">{icon}</div>
                <h3 className="text-lg font-bold text-gray-400">{title}</h3>
                <p className={`text-5xl font-black my-2 ${count > 0 ? 'text-white animate-pulse' : 'text-gray-600'}`}>
                    {count}
                </p>
                <p className="text-sm text-gray-500">{description}</p>
            </Card>
        </button>
    );
};


export const DashboardView: React.FC<{ setActivePage: (page: StaffPage) => void; }> = ({ setActivePage }) => {
    const { orders } = useOrders();
    const { tables } = useTables();
    const [isCallModalOpen, setIsCallModalOpen] = useState(false);

    const verificationCount = orders.filter(o => o.isActive && o.status === OrderStatus.PAYMENT_SUBMITTED).length;
    const cookingCount = orders.filter(o => o.isActive && (o.status === OrderStatus.PAYMENT_CONFIRMED || o.status === OrderStatus.IN_KITCHEN)).length;
    const servingCount = orders.filter(o => o.isActive && o.status === OrderStatus.READY_TO_SERVE).length;
    const callingTables = tables.filter(t => t.status === TableStatus.CALLED);

    return (
        <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-6">주요 현황 요약</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard 
                    icon="🤝"
                    title="결제 확인"
                    count={verificationCount}
                    description="확인이 필요한 주문"
                    onClick={() => setActivePage(StaffPage.VERIFICATION)}
                />
                 <MetricCard 
                    icon="🔥"
                    title="조리"
                    count={cookingCount}
                    description="주방에서 조리 중인 주문"
                    onClick={() => setActivePage(StaffPage.ORDERS)}
                />
                 <MetricCard 
                    icon="🍽️"
                    title="서빙"
                    count={servingCount}
                    description="서빙 대기 중인 주문"
                    onClick={() => setActivePage(StaffPage.SERVING)}
                />
                <MetricCard 
                    icon="🙋‍♂️"
                    title="호출"
                    count={callingTables.length}
                    description="호출 중인 테이블"
                    onClick={() => setIsCallModalOpen(true)}
                />
            </div>

            <CallListModal
                isOpen={isCallModalOpen}
                onClose={() => setIsCallModalOpen(false)}
                callingTables={callingTables}
            />
            
            <div className="mt-8">
                <Card>
                    <h3 className="text-lg font-bold text-white mb-4">💡 스태프 가이드</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-300">
                        <li><strong>결제 확인:</strong> 고객이 입금 완료 버튼을 누르면 이 곳에 표시됩니다. 현장에서 입금 내역을 확인하고 '확인 완료'를 눌러주세요.</li>
                        <li><strong>조리 현황:</strong> 결제가 확인된 주문들이 표시됩니다. 주방에서는 이 목록을 보고 조리를 시작합니다.</li>
                        <li><strong>서빙:</strong> 주방에서 조리가 완료된 주문입니다. 즉시 고객에게 전달해주세요.</li>
                        <li><strong>테이블 현황:</strong> 식사가 끝난 테이블을 정리(비어있음) 처리할 수 있습니다.</li>
                    </ul>
                </Card>
            </div>
        </div>
    );
};