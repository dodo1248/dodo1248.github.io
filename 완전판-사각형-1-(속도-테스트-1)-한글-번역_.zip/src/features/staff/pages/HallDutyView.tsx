import React, { useMemo, useState } from 'react';
import { useOrders } from '../contexts/OrdersContext';
import { useTables } from '../contexts/TablesContext';
import { TableStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { ElapsedTimeLarge } from '../components/ElapsedTimeLarge';
import { Modal } from '../../../shared/components/Modal';

export const HallDutyView: React.FC = () => {
    const { orders } = useOrders();
    const { tables } = useTables();
    const [selectedTableNumber, setSelectedTableNumber] = useState<number | null>(null);

    const tablesWithDuration = useMemo(() => {
        const activeOrders = orders.filter(o => o.isActive);
        if (activeOrders.length === 0) {
            return [];
        }

        const tableSessionInfo: { [key: number]: { startTime: number; itemCount: number } } = {};

        activeOrders.forEach(order => {
            if (!tableSessionInfo[order.tableNumber]) {
                tableSessionInfo[order.tableNumber] = {
                    startTime: order.timestamp,
                    itemCount: order.items.reduce((acc, item) => acc + item.quantity, 0),
                };
            } else {
                if (order.timestamp < tableSessionInfo[order.tableNumber].startTime) {
                    tableSessionInfo[order.tableNumber].startTime = order.timestamp;
                }
                tableSessionInfo[order.tableNumber].itemCount += order.items.reduce((acc, item) => acc + item.quantity, 0);
            }
        });

        const result = tables
            .filter(table => table.status !== TableStatus.EMPTY && tableSessionInfo[table.tableNumber])
            .map(table => ({
                tableNumber: table.tableNumber,
                sessionStartTime: tableSessionInfo[table.tableNumber].startTime,
                itemCount: tableSessionInfo[table.tableNumber].itemCount,
            }));

        result.sort((a, b) => a.sessionStartTime - b.sessionStartTime);

        return result;
    }, [orders, tables]);

    const selectedTableHistory = useMemo(() => {
        if (!selectedTableNumber) return null;

        const tableOrders = orders.filter(o => o.tableNumber === selectedTableNumber && o.isActive);
        if (tableOrders.length === 0) return null;

        const firstOrderTime = Math.min(...tableOrders.map(o => o.timestamp));
        
        const allItems = tableOrders.flatMap(order => order.items);
        const itemMap = new Map<number, { name: string; quantity: number; price: number }>();

        allItems.forEach(item => {
            const existing = itemMap.get(item.id);
            if (existing) {
                existing.quantity += item.quantity;
            } else {
                itemMap.set(item.id, {
                    name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                });
            }
        });
        
        const aggregatedItems = Array.from(itemMap.values()).sort((a, b) => a.name.localeCompare(b.name));
        const totalAmount = tableOrders.reduce((sum, order) => sum + order.totalPrice, 0);

        return { firstOrderTime, aggregatedItems, totalAmount };

    }, [selectedTableNumber, orders]);


    if (tablesWithDuration.length === 0) {
        return (
            <Card className="text-center py-16">
                <p className="text-2xl text-gray-400 mb-2">⏳</p>
                <p className="font-bold text-lg text-gray-300">현재 식사 중인 테이블이 없습니다.</p>
            </Card>
        );
    }
    
    const textShadowStyle = {
        textShadow: '0 0 25px rgba(239, 116, 144, 0.6), 0 0 8px rgba(255, 255, 255, 0.9)'
    };

    return (
        <div>
            <h2 className="text-xl font-bold text-white mb-4">테이블 이용 시간 현황 ({tablesWithDuration.length})</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {tablesWithDuration.map(table => (
                    <Card 
                        key={table.tableNumber} 
                        className="text-center flex flex-col justify-between cursor-pointer hover:shadow-xl hover:-translate-y-1 hover:border-rose-400"
                        onClick={() => setSelectedTableNumber(table.tableNumber)}
                        role="button"
                        aria-label={`${table.tableNumber}번 테이블 상세 내역 보기`}
                    >
                        <div>
                            <p className="text-lg font-bold text-gray-400">테이블</p>
                            <p className="text-6xl font-black text-white my-1" style={textShadowStyle}>{table.tableNumber}</p>
                        </div>
                        <div className="mt-2">
                            <ElapsedTimeLarge timestamp={table.sessionStartTime} />
                            <p className="text-sm text-gray-400 mt-2">{table.itemCount}개 주문</p>
                        </div>
                    </Card>
                ))}
            </div>
            
            <Modal
                isOpen={!!selectedTableNumber}
                onClose={() => setSelectedTableNumber(null)}
                title={`테이블 ${selectedTableNumber}번 주문 내역`}
            >
                {selectedTableHistory ? (
                    <div className="space-y-4">
                        <div>
                            <p className="text-sm font-bold text-gray-400">첫 주문 시간</p>
                            <p className="text-lg font-bold text-white">
                                {new Date(selectedTableHistory.firstOrderTime).toLocaleString('ko-KR')}
                            </p>
                        </div>
                        <div className="border-t border-gray-700 pt-4">
                            <p className="text-sm font-bold text-gray-400 mb-2">주문 목록</p>
                            <ul className="space-y-2 max-h-64 overflow-y-auto pr-2">
                                {selectedTableHistory.aggregatedItems.map(item => (
                                    <li key={item.name} className="flex justify-between items-center text-sm">
                                        <p className="text-gray-300">{item.name}</p>
                                        <p className="font-semibold text-gray-100">
                                            <span className="font-mono text-gray-400 mr-2">x{item.quantity}</span>
                                            {(item.price * item.quantity).toLocaleString()}원
                                        </p>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className="border-t border-gray-700 pt-4 mt-4">
                            <div className="flex justify-between items-baseline">
                                <span className="text-lg font-bold text-gray-200">현재까지 총액</span>
                                <span className="text-2xl font-black text-rose-400">
                                    {selectedTableHistory.totalAmount.toLocaleString()}원
                                </span>
                            </div>
                        </div>
                    </div>
                ) : (
                    <p className="text-center text-gray-400 py-8">주문 내역을 불러올 수 없습니다.</p>
                )}
            </Modal>
        </div>
    );
};