
import React, { useMemo } from 'react';
import { OrderStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { useOrders } from '../contexts/OrdersContext';
import { OrderCard } from '../components/OrderCard';
import { SearchAndSortHeader } from '../components/SearchAndSortHeader';
import { useSearchAndSort } from '../hooks/useSearchAndSort';

export const OrderManagement: React.FC = () => {
    const { orders, newOrderIds } = useOrders();
    const { searchTerm, onSearchChange, sortOrder, onSortOrderChange } = useSearchAndSort('asc');

    const activeOrders = useMemo(() => {
        const sorted = orders
            .filter(o => o.isActive && (o.status === OrderStatus.PAYMENT_CONFIRMED || o.status === OrderStatus.IN_KITCHEN))
            .filter(o => !searchTerm.trim() || o.tableNumber.toString().includes(searchTerm.trim()));

        if (sortOrder === 'asc') {
            sorted.sort((a, b) => a.timestamp - b.timestamp);
        } else {
            sorted.sort((a, b) => b.timestamp - a.timestamp);
        }
        return sorted;
    }, [orders, searchTerm, sortOrder]);

    return (
        <div>
             <div className="flex justify-between items-center mb-4">
                 <h2 className="text-xl font-bold text-gray-800 dark:text-white">🔥 실시간 조리 현황 ({activeOrders.length})</h2>
                 <span className="flex items-center text-sm font-medium text-green-600 dark:text-green-400"><span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-ping"></span>실시간</span>
            </div>
            
            <SearchAndSortHeader
                searchTerm={searchTerm}
                onSearchChange={onSearchChange}
                sortOrder={sortOrder}
                onSortOrderChange={onSortOrderChange}
            />

            {activeOrders.length === 0 ? (
                <Card className="text-center py-16">
                    {searchTerm ? (
                        <>
                            <p className="text-2xl text-gray-400 mb-2">🤔</p>
                            <p className="font-bold text-lg text-gray-600 dark:text-gray-300">'{searchTerm}'번 테이블의 주문을 찾을 수 없습니다.</p>
                        </>
                    ) : (
                        <>
                            <p className="text-2xl text-gray-400 mb-2">🕒</p>
                            <p className="font-bold text-lg text-gray-600 dark:text-gray-300">새 주문을 기다리는 중...</p>
                        </>
                    )}
                </Card>
            ) : (
                <div className="space-y-4">{activeOrders.map(order => <OrderCard key={order.id} order={order} isNew={newOrderIds.has(order.id)} />)}</div>
            )}
        </div>
    );
};
