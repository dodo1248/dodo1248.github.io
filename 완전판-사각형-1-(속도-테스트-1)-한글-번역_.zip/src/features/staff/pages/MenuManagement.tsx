import React from 'react';
import { MenuItem, MenuCategory } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { useMenu } from '../contexts/MenuContext';
import { clsx } from '../../../shared/utils/clsx';

const MenuItemControlCard: React.FC<{
    item: MenuItem;
    isUpdating: boolean;
    onToggle: (itemId: number, isSoldOut: boolean) => void;
}> = React.memo(({ item, isUpdating, onToggle }) => {
    return (
        <Card padding="p-4" className={clsx({ 'opacity-50 pointer-events-none': isUpdating })}>
            <div className="flex items-center justify-between">
                <div>
                    <p className="font-bold text-lg text-gray-800 dark:text-gray-200">{item.name}</p>
                    <p className="text-gray-600 dark:text-gray-400 font-medium">{item.price.toLocaleString()}원</p>
                </div>
                <div className="flex items-center space-x-3">
                    <span className={`font-bold text-sm transition-colors w-16 text-right ${item.isSoldOut ? 'text-red-500' : 'text-green-600'}`}>
                        {isUpdating ? '변경중...' : item.isSoldOut ? '품절' : '판매중'}
                    </span>
                    <label htmlFor={`toggle-${item.id}`} className="relative inline-flex items-center cursor-pointer">
                    <input
                        type="checkbox"
                        id={`toggle-${item.id}`}
                        className="sr-only peer"
                        checked={!item.isSoldOut}
                        onChange={() => onToggle(item.id, !item.isSoldOut)}
                        disabled={isUpdating}
                    />
                    <div className="w-11 h-6 bg-gray-300 rounded-full peer peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-offset-2 peer-focus:ring-pink-400 dark:peer-focus:ring-offset-gray-900 dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-rose-500 peer-disabled:cursor-not-allowed peer-disabled:opacity-50"></div>
                    </label>
                </div>
            </div>
        </Card>
    );
});


export const MenuManagement: React.FC = () => {
    const { menu, actions, updatingIds } = useMenu();

    const groupedMenu = React.useMemo(() => {
        const categories: MenuCategory[] = ['HEART 메인 (메인 안주 1)', 'WATT 메인 (메인 안주 2)', 'BEAT 사이드 (사이드 안주)', '기타 (라면 및 음료)'];
        return categories.map(cat => ({ category: cat, items: menu.filter(item => item.category === cat) })).filter(g => g.items.length > 0);
    }, [menu]);

    return (
         <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-2">메뉴 품절 관리</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">토글 스위치로 메뉴의 판매/품절 상태를 실시간으로 변경할 수 있습니다.</p>
            <div className="space-y-6">{groupedMenu.map(({category, items}) => (<div key={category}><h3 className="text-lg font-bold text-gray-700 dark:text-gray-300 border-b border-pink-500/10 dark:border-gray-700/50 pb-2 mb-3">{category}</h3><div className="space-y-3">{items.map(item => (
                <MenuItemControlCard
                    key={item.id}
                    item={item}
                    isUpdating={updatingIds.has(item.id)}
                    onToggle={actions.updateMenuSoldOut}
                />
            ))}</div></div>))}</div>
         </div>
    );
};
