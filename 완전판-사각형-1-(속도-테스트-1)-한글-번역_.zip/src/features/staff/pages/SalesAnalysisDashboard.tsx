import React, { useMemo } from 'react';
import { Card } from '../../../shared/components/Card';
import { useOrders } from '../contexts/OrdersContext';
import { OrderStatus } from '../../../shared/types';

// Helper to format milliseconds into a readable value and unit
const formatDuration = (ms: number): { value: string; unit: string } => {
    if (ms < 1000) return { value: '0', unit: '초' };
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    if (minutes === 0) {
      return { value: String(seconds), unit: '초' };
    }
    return { value: String(minutes), unit: `분 ${seconds}초` };
};


// A reusable component for displaying a metric, optimized for grid layouts
const MetricCard: React.FC<{ icon: string; title: string; value: string | number; unit: string; }> = ({ icon, title, value, unit }) => {
    return (
        <Card className="text-center p-6 h-full">
            <div className="flex flex-col items-center justify-center h-full min-h-[160px]">
                <div className="text-5xl mb-3" style={{ textShadow: '0 0 15px rgba(255, 255, 255, 0.5)' }}>{icon}</div>
                <h3 className="text-base text-gray-400 font-bold">{title}</h3>
                <p className="text-4xl font-black text-white mt-2">
                    {value} 
                    {unit && <span className="text-2xl font-bold text-gray-300 ml-1">{unit}</span>}
                </p>
            </div>
        </Card>
    );
};

export const SalesAnalysisDashboard: React.FC = () => {
    const { orders } = useOrders();

    const performanceData = useMemo(() => {
        const validOrders = orders.filter(o => o.status !== OrderStatus.CANCELLED);
        const now = Date.now();
        const oneHourAgo = now - 3600000;

        const ordersLastHour = validOrders.filter(o => o.timestamp >= oneHourAgo);
        
        const totalRevenue = validOrders.reduce((sum, order) => sum + order.totalPrice, 0);
        
        const tablesWithOrders = new Set(validOrders.map(o => o.tableNumber));
        const numberOfTables = tablesWithOrders.size;
        const averagePricePerTable = numberOfTables > 0 ? Math.round(totalRevenue / numberOfTables) : 0;

        let longestWaitMs = 0;
        const processingOrders = validOrders.filter(o => o.isActive && o.status !== OrderStatus.SERVED);
        if (processingOrders.length > 0) {
            const oldestTimestamp = Math.min(...processingOrders.map(o => o.timestamp));
            longestWaitMs = now - oldestTimestamp;
        }
        
        const { value: waitValue, unit: waitUnit } = formatDuration(longestWaitMs);

        return {
            ordersPerHour: ordersLastHour.length,
            averagePricePerTable,
            longestWaitValue: waitValue,
            longestWaitUnit: waitUnit,
            totalOrders: validOrders.length,
        };
    }, [orders]);
    
    if (orders.filter(o => o.status !== OrderStatus.CANCELLED).length === 0) {
        return (
            <div>
                <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-6">매장 리포트</h2>
                <Card className="text-center py-12 px-6">
                    <p className="text-4xl mb-4">📊</p>
                    <h3 className="text-xl font-bold text-gray-700 dark:text-gray-200 mb-2">데이터가 없습니다.</h3>
                    <p className="text-gray-500 dark:text-gray-400">
                        주문이 발생하면 이 곳에서 실시간 리포트를 확인할 수 있습니다.
                    </p>
                </Card>
            </div>
        );
    }
    
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">매장 리포트</h2>
            </div>

            <div className="grid grid-cols-2 gap-6">
                <MetricCard 
                    icon="📈"
                    title="시간당 주문량"
                    value={performanceData.ordersPerHour}
                    unit="건"
                />
                 <MetricCard 
                    icon="💰"
                    title="테이블당 평균 금액"
                    value={performanceData.averagePricePerTable.toLocaleString()}
                    unit="원"
                />
                 <MetricCard 
                    icon="⏳"
                    title="최고 대기 시간"
                    value={performanceData.longestWaitValue}
                    unit={performanceData.longestWaitUnit}
                />
                <MetricCard 
                    icon="🧾"
                    title="총 주문량"
                    value={performanceData.totalOrders}
                    unit="건"
                />
            </div>
             <div className="mt-8">
                <Card className="p-4 text-sm text-gray-400 space-y-2">
                    <p><strong className="text-gray-300">시간당 주문량:</strong> 최근 1시간 동안 접수된 주문 건수입니다.</p>
                    <p><strong className="text-gray-300">테이블당 평균 금액:</strong> 현재까지 발생한 총매출을 주문이 있는 테이블 수로 나눈 값입니다.</p>
                    <p><strong className="text-gray-300">최고 대기 시간:</strong> 현재 처리 중인(서빙 완료 전) 주문 중 가장 오래된 주문의 경과 시간입니다.</p>
                    <p><strong className="text-gray-300">총 주문량:</strong> 현재까지 접수된 모든 주문의 누적 건수입니다.</p>
                </Card>
            </div>
        </div>
    );
};