
import React, { useMemo } from 'react';
import { Table, TableStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { Modal } from '../../../shared/components/Modal';
import { useTables } from '../contexts/TablesContext';
import { useOrders } from '../contexts/OrdersContext';
import { TableFilter, TableFilterType } from '../components/table-dashboard/TableFilter';
import { TableGroup } from '../components/table-dashboard/TableGroup';
import { MultiClearActionBar } from '../components/table-dashboard/MultiClearActionBar';
import { useTableDashboardState } from '../hooks/useTableDashboardState';
import { ManageTablePinModal } from '../components/ManageTablePinModal';
import { StaffRole } from '../staff.types';
import { PinPad } from '../components/PinPad';
import { CUSTOMER_PIN_LENGTH } from '../../../shared/constants';

interface TableStatusDashboardProps {
  staffRole: StaffRole;
}

export const TableStatusDashboard: React.FC<TableStatusDashboardProps> = ({ staffRole }) => {
    const { tables, updatingIds, actions: tableActions } = useTables();
    const { operatingDay } = useOrders();
    const [filter, setFilter] = React.useState<TableFilterType>('all');
    const [mainTableSelection, setMainTableSelection] = React.useState<number | null>(null);
    
    const {
        isClearModalOpen,
        isMultiClearModalOpen,
        isManagePinModalOpen,
        isMergeModalOpen,
        isMergePinModalOpen,
        selectedTable,
        clearWarningMessage,
        isSelectionMode,
        selectedTables,
        handleTableClick,
        handleCloseClearModal,
        handleConfirmClearTable,
        toggleSelectionMode,
        handleOpenMultiClearModal,
        handleConfirmMultiClear,
        setIsMultiClearModalOpen,
        handleOpenManagePinModal,
        handleCloseManagePinModal,
        handleOpenMergeModal,
        handleCloseMergeModal,
        handleSelectMainForMerge,
        handleCloseMergePinModal,
        handleConfirmMergeWithPin,
    } = useTableDashboardState();

    React.useEffect(() => {
        if (isMergeModalOpen && selectedTables.size > 0) {
            setMainTableSelection(Array.from(selectedTables)[0]);
        } else {
            setMainTableSelection(null);
        }
    }, [isMergeModalOpen, selectedTables]);
    
    const isClearingTable = selectedTable ? updatingIds.has(`table-clear-${selectedTable.tableNumber}`) : false;
    
    const { idleTables, emptyTables, filteredTables, mergedTableGroups } = React.useMemo(() => {
        const mainTables = tables.filter(t => t.isMainTable);
        const subTables = tables.filter(t => t.mergedWith);
        const singleIdleTables = tables.filter(t => t.status === TableStatus.IDLE && !t.isMainTable && !t.mergedWith);
        
        const groups = mainTables.map(main => {
            const subs = subTables.filter(sub => sub.mergedWith === main.tableNumber);
            return { main, subs };
        });

        const empty = tables.filter(t => t.status === TableStatus.EMPTY).sort((a,b) => a.tableNumber - b.tableNumber);
        
        let filtered: Table[] = [];
        if (filter === 'all') filtered = [...tables.filter(t => t.status === TableStatus.IDLE), ...empty];
        else if (filter === TableStatus.IDLE) filtered = tables.filter(t => t.status === TableStatus.IDLE);
        else if (filter === TableStatus.EMPTY) filtered = empty;
        // For safety, if filter is somehow CALLED, return empty array.
        else if (filter === TableStatus.CALLED) filtered = [];
        
        return { idleTables: singleIdleTables.sort((a,b) => a.tableNumber - b.tableNumber), emptyTables: empty, filteredTables: filtered, mergedTableGroups: groups };
    }, [tables, filter]);
    
    const isMergeEnabled = useMemo(() => {
        if (selectedTables.size < 2) return false;
        const selectedTableObjects = tables.filter(t => selectedTables.has(t.tableNumber));
        return selectedTableObjects.length > 0 && selectedTableObjects.every(t => t.status === TableStatus.EMPTY);
    }, [selectedTables, tables]);

    const renderContent = () => {
        if (tables.length === 0) {
            return <Card className="text-center py-16"><p className="text-2xl text-gray-400 mb-2">🍽️</p><p className="font-bold text-lg text-gray-300">아직 활성화된 테이블이 없습니다.</p></Card>;
        }
        if (filter !== 'all' && filteredTables.length === 0 && (filter !== TableStatus.IDLE || (idleTables.length === 0 && mergedTableGroups.length === 0))) {
             return <Card className="text-center py-16"><p className="font-bold text-lg text-gray-300">해당 상태의 테이블이 없습니다.</p></Card>;
        }

        const shouldShow = (status: TableStatus) => filter === 'all' || filter === status;

        return (
            <div className="space-y-8">
                {shouldShow(TableStatus.IDLE) && (
                    <>
                        <TableGroup title="식사 중 (그룹)" tables={[]} mergedGroups={mergedTableGroups} isSelectionMode={isSelectionMode} selectedTables={selectedTables} updatingIds={updatingIds} onTableClick={handleTableClick} onManagePinClick={handleOpenManagePinModal} staffRole={staffRole} />
                        <TableGroup title="식사 중 (개별)" tables={idleTables} isSelectionMode={isSelectionMode} selectedTables={selectedTables} updatingIds={updatingIds} onTableClick={handleTableClick} onManagePinClick={handleOpenManagePinModal} staffRole={staffRole} />
                    </>
                )}
                {shouldShow(TableStatus.EMPTY) && <TableGroup title="비어있음" titleColor="text-gray-400 dark:text-gray-500" tables={emptyTables} isSelectionMode={isSelectionMode} selectedTables={selectedTables} updatingIds={updatingIds} onTableClick={handleTableClick} />}
            </div>
        );
    }

    return (
        <div className="pb-24">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-white">테이블 현황 ({operatingDay}일차)</h2>
                <button
                    onClick={toggleSelectionMode}
                    className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${isSelectionMode ? 'bg-gray-600 text-white' : 'bg-rose-100 dark:bg-gray-700 text-rose-300'}`}
                >
                    {isSelectionMode ? '취소' : '편집'}
                </button>
            </div>

            <TableFilter 
                currentFilter={filter}
                onFilterChange={setFilter}
                counts={{ idle: mergedTableGroups.reduce((acc, g) => acc + 1 + g.subs.length, idleTables.length) , empty: emptyTables.length }}
            />
            
            {renderContent()}

            <Modal isOpen={isClearModalOpen} onClose={handleCloseClearModal} title="테이블 상태 변경">
                <div>
                    <p className="text-center text-lg text-gray-200"><span className="font-bold text-rose-500">{selectedTable?.tableNumber}번 테이블</span>을 <span className="font-bold">'비어있음'</span>으로 변경하시겠습니까?</p>
                    {clearWarningMessage && (
                        <div className="mt-4 p-3 bg-yellow-900/40 rounded-lg whitespace-pre-line">
                            <p className="text-center text-sm text-yellow-300 font-semibold">{clearWarningMessage}</p>
                        </div>
                    )}
                    <p className="text-center text-sm text-gray-400 mt-4">이 작업은 해당 테이블의 모든 주문 내역을 보관 처리하며, 다음 손님은 깨끗한 상태에서 주문을 시작하게 됩니다.</p>
                    <div className="flex justify-center space-x-4 mt-6">
                        <Button variant="secondary" onClick={handleCloseClearModal} className="w-1/2">취소</Button>
                        <Button onClick={handleConfirmClearTable} isLoading={isClearingTable} className="w-1/2">확인</Button>
                    </div>
                </div>
            </Modal>
            
            <Modal isOpen={isMultiClearModalOpen} onClose={() => setIsMultiClearModalOpen(false)} title="여러 테이블 비우기">
                 <div>
                    <p className="text-center text-lg text-gray-200"><span className="font-bold text-rose-500">{selectedTables.size}개 테이블</span>을 <span className="font-bold">'비어있음'</span>으로 변경하시겠습니까?</p>
                    <p className="text-center text-sm text-gray-400 mt-2 break-words">대상: {Array.from(selectedTables).sort((a: number, b: number) => a - b).join(', ')}</p>
                    {clearWarningMessage && (
                        <div className="mt-4 p-3 bg-yellow-900/40 rounded-lg">
                            <p className="text-center text-sm text-yellow-300 font-semibold">{clearWarningMessage}</p>
                        </div>
                    )}
                    <div className="flex justify-center space-x-4 mt-6">
                        <Button variant="secondary" onClick={() => setIsMultiClearModalOpen(false)} className="w-1/2">취소</Button>
                        <Button onClick={handleConfirmMultiClear} className="w-1/2">확인</Button>
                    </div>
                </div>
            </Modal>
            
            {selectedTable && (
                <ManageTablePinModal 
                    isOpen={isManagePinModalOpen}
                    onClose={handleCloseManagePinModal}
                    table={selectedTable}
                />
            )}
            
            <Modal isOpen={isMergeModalOpen} onClose={handleCloseMergeModal} title="테이블 합석">
                <div>
                    <p className="text-center text-lg text-gray-200">
                        어떤 테이블을 <span className="font-bold text-rose-500">대표 테이블</span>로 지정하시겠습니까?
                    </p>
                    <p className="text-center text-sm text-gray-400 mt-2">
                        선택된 테이블 그룹 전체가 하나의 PIN으로 관리됩니다.
                    </p>
                    <div className="my-4 space-y-2 max-h-60 overflow-y-auto">
                        {Array.from(selectedTables).sort((a: number, b: number) => a - b).map(tableNum => (
                            <button
                                key={tableNum}
                                onClick={() => setMainTableSelection(tableNum)}
                                className={`w-full text-left p-4 rounded-lg transition-all border-2 ${mainTableSelection === tableNum ? 'bg-rose-100 dark:bg-rose-900/50 border-rose-500' : 'bg-gray-100 dark:bg-gray-800 border-transparent'}`}
                            >
                                <span className="font-bold text-lg text-gray-200">{tableNum}번 테이블</span>
                                {mainTableSelection === tableNum && <span className="ml-2 font-bold text-rose-500"> (대표)</span>}
                            </button>
                        ))}
                    </div>
                    <div className="flex justify-center space-x-4 mt-6">
                        <Button variant="secondary" onClick={handleCloseMergeModal} className="w-1/2">취소</Button>
                        <Button onClick={() => mainTableSelection && handleSelectMainForMerge(mainTableSelection)} disabled={!mainTableSelection} className="w-1/2">다음</Button>
                    </div>
                </div>
            </Modal>

             <Modal isOpen={isMergePinModalOpen} onClose={handleCloseMergePinModal} title="그룹 PIN 설정">
                <PinPad
                    pinLength={CUSTOMER_PIN_LENGTH}
                    title="그룹 전체에서 사용할 4자리 PIN 설정"
                    onComplete={handleConfirmMergeWithPin}
                />
            </Modal>

            <MultiClearActionBar 
                isVisible={isSelectionMode && selectedTables.size > 0}
                selectedCount={selectedTables.size}
                onClear={handleOpenMultiClearModal}
                onMerge={handleOpenMergeModal}
                isMergeEnabled={isMergeEnabled}
            />
        </div>
    );
};