
import React from 'react';
import { OrderStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { useOrders } from '../contexts/OrdersContext';
import { VerificationCard } from '../components/VerificationCard';
import { SearchAndSortHeader } from '../components/SearchAndSortHeader';
import { useVerificationState } from '../hooks/useVerificationState';
import { MultiConfirmActionBar } from '../components/MultiConfirmActionBar';
import { useSearchAndSort } from '../hooks/useSearchAndSort';

export const VerificationView: React.FC = () => {
    const { orders } = useOrders();
    const { searchTerm, onSearchChange, sortOrder, onSortOrderChange } = useSearchAndSort('asc');
    
    const { 
        isSelectionMode,
        selectedOrders,
        toggleSelectionMode,
        handleOrderClick,
        handleConfirmMultiple,
        updatingIds,
    } = useVerificationState();

    const verificationPendingOrders = React.useMemo(() => {
        const sorted = orders
            .filter(o => o.isActive && o.status === OrderStatus.PAYMENT_SUBMITTED)
            .filter(o => !searchTerm.trim() || o.tableNumber.toString().includes(searchTerm.trim()));
        
        if (sortOrder === 'asc') {
            sorted.sort((a, b) => a.timestamp - b.timestamp);
        } else {
            sorted.sort((a, b) => b.timestamp - a.timestamp);
        }
        return sorted;
    }, [orders, searchTerm, sortOrder]);

    return (
        <div className="pb-24">
            <div className="flex flex-wrap justify-between items-center gap-y-2 mb-4">
                <div className="flex-grow">
                  <h2 className="text-xl font-bold text-gray-800 dark:text-white">🤝 결제 확인 필요한 주문 ({verificationPendingOrders.length})</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 hidden sm:block">고객의 입금 내역을 현장에서 확인 후, '확인 완료'를 눌러주세요.</p>
                </div>
                 <button
                    onClick={toggleSelectionMode}
                    className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${isSelectionMode ? 'bg-gray-600 text-white' : 'bg-rose-100 dark:bg-gray-700 text-rose-600 dark:text-rose-300'}`}
                >
                    {isSelectionMode ? '취소' : '편집'}
                </button>
            </div>
            
            <SearchAndSortHeader
                searchTerm={searchTerm}
                onSearchChange={onSearchChange}
                sortOrder={sortOrder}
                onSortOrderChange={onSortOrderChange}
            />

            {verificationPendingOrders.length === 0 ? (
                <Card className="text-center py-16">
                    {searchTerm ? (
                        <>
                            <p className="text-2xl text-gray-400 mb-2">🤔</p>
                            <p className="font-bold text-lg text-gray-600 dark:text-gray-300">'{searchTerm}'번 테이블의 주문을 찾을 수 없습니다.</p>
                        </>
                    ) : (
                        <>
                            <p className="text-2xl text-gray-400 mb-2">👍</p>
                            <p className="font-bold text-lg text-gray-600 dark:text-gray-300">확인이 필요한 주문이 없습니다.</p>
                        </>
                    )}
                </Card>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {verificationPendingOrders.map(order => 
                        <VerificationCard 
                            key={order.id} 
                            order={order} 
                            isSelectionMode={isSelectionMode}
                            isSelected={selectedOrders.has(order.id)}
                            onClick={() => handleOrderClick(order.id)}
                        />
                    )}
                </div>
            )}
             <MultiConfirmActionBar
                isVisible={isSelectionMode && selectedOrders.size > 0}
                selectedCount={selectedOrders.size}
                onConfirm={handleConfirmMultiple}
                isLoading={updatingIds.size > 0}
            />
        </div>
    );
};
