export enum StaffPage {
  DASHBOARD = '주문 대시보드',
  VERIFICATION = '결제 확인',
  ORDERS = '조리 현황',
  KITCHEN = '주방 현황',
  SERVING = '서빙',
  TABLES = '테이블 현황',
  HALL_DUTY = '홀 시간 관리',
  MENU = '메뉴 관리',
  STATS = '매출 통계',
  ANALYSIS = '매장 리포트',
}

export type StaffRole = 'manager' | 'hall' | 'kitchen';