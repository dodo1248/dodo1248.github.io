import React, { useState, useEffect } from 'react';
import { StaffDataProvider } from './contexts/StaffDataProvider';
import { StaffDashboard } from './components/StaffDashboard';
import { StaffLogin } from './components/StaffLogin';
import { StaffRoleSelection } from './components/StaffRoleSelection';
import { StaffRole } from './staff.types';
import { STORAGE_KEYS } from '../../shared/constants';
import { staffApi } from '../../shared/api/staff';

export const StaffView: React.FC<{ onBack: () => void; }> = ({ onBack }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [staffRole, setStaffRole] = useState<StaffRole | null>(null);
  
  useEffect(() => { 
    const loggedIn = sessionStorage.getItem(STORAGE_KEYS.STAFF_LOGGED_IN) === 'true';
    const role = sessionStorage.getItem(STORAGE_KEYS.STAFF_ROLE) as StaffRole;
    if (loggedIn) {
      setIsLoggedIn(true);
      if (role) {
        setStaffRole(role);
      }
    }
  }, []);

  const handleLogin = async (pin: string): Promise<boolean> => { 
    try {
      const { isValid } = await staffApi.verifyPin(pin);
      if (isValid) {
        sessionStorage.setItem(STORAGE_KEYS.STAFF_LOGGED_IN, 'true'); 
        setIsLoggedIn(true);
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error("Login failed:", error);
      alert("로그인 중 오류가 발생했습니다. 네트워크 연결을 확인해주세요.");
      return false;
    }
  };
  
  const handleSelectRole = (role: StaffRole) => {
    sessionStorage.setItem(STORAGE_KEYS.STAFF_ROLE, role);
    setStaffRole(role);
  };

  const handleLogout = () => { 
    sessionStorage.removeItem(STORAGE_KEYS.STAFF_LOGGED_IN); 
    sessionStorage.removeItem(STORAGE_KEYS.STAFF_ROLE);
    sessionStorage.removeItem(STORAGE_KEYS.STAFF_ACTIVE_PAGE);
    setIsLoggedIn(false); 
    setStaffRole(null);
    onBack(); 
  }
  
  const handleChangeRole = () => {
    sessionStorage.removeItem(STORAGE_KEYS.STAFF_ROLE);
    sessionStorage.removeItem(STORAGE_KEYS.STAFF_ACTIVE_PAGE);
    setStaffRole(null);
  }

  if (!isLoggedIn) {
    return <StaffLogin onLogin={handleLogin} onBack={onBack} />;
  }

  if (!staffRole) {
    return <StaffRoleSelection onSelectRole={handleSelectRole} onLogout={handleLogout} />;
  }
  
  return (
    <StaffDataProvider>
        <StaffDashboard 
          onLogout={handleLogout} 
          staffRole={staffRole}
          onChangeRole={handleChangeRole}
        />
    </StaffDataProvider>
  );
};