import React from 'react';
import { Button } from '../../shared/components/Button';
import { Card } from '../../shared/components/Card';
import { Logo } from '../../shared/components/Logo';

export const LandingPage: React.FC<{ onCustomer: () => void; onStaff: () => void; }> = ({ onCustomer, onStaff }) => {
  
  return (
    <div className="w-full h-full flex flex-col p-4">
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center z-10">
          <Logo size="large" />
        </div>
      </div>
      
      <div className="flex-shrink-0 pb-16">
        <Card className="w-full max-w-xs mx-auto" padding="p-6">
           <div className="space-y-6">
            <Button onClick={onCustomer}>
              주문하러 왔어요
            </Button>
            <Button variant="secondary" onClick={onStaff}>
              🔑 스태프로 로그인
            </Button>
           </div>
        </Card>
      </div>
    </div>
  );
};