import React, { createContext, useContext } from 'react';
import { useCustomerSession, CustomerState } from '../hooks/useCustomerSession';

// Infer the return type of the hook to use for the context value
type CustomerSessionContextValue = ReturnType<typeof useCustomerSession>;

const CustomerSessionContext = createContext<CustomerSessionContextValue | null>(null);

export const useCustomerContext = () => {
    const context = useContext(CustomerSessionContext);
    if (!context) {
        throw new Error('useCustomerContext must be used within a CustomerSessionProvider');
    }
    return context;
};

interface CustomerSessionProviderProps {
    children: React.ReactNode;
    onExitToLanding: () => void;
}

export const CustomerSessionProvider: React.FC<CustomerSessionProviderProps> = ({ children, onExitToLanding }) => {
    const session = useCustomerSession({ onExitToLanding });

    return (
        <CustomerSessionContext.Provider value={session}>
            {children}
        </CustomerSessionContext.Provider>
    );
};

export type { CustomerState };