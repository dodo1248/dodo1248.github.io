
import React from 'react';
import { Card } from '../../../shared/components/Card';
import { Logo } from '../../../shared/components/Logo';
import { PinPad } from '../../staff/components/PinPad';
import { CUSTOMER_PIN_LENGTH } from '../../../shared/constants';
import { useCustomerContext } from '../contexts/CustomerSessionContext';

export const PinInputPage: React.FC = () => {
  const { state, handlePinComplete, handleBackToTableInput, isSubmitting, pinError } = useCustomerContext();

  const titles = {
    setup: '사용할 4자리 PIN 설정',
    confirm: 'PIN 재확인',
    verify: '테이블 PIN 입력'
  };
  
  const [resetKey, setResetKey] = React.useState(0);

  React.useEffect(() => {
    // Force PinPad to reset when mode changes or an error occurs
    setResetKey(prev => prev + 1);
  }, [state.pinMode, pinError]);

  return (
    <div className="w-full flex-grow flex flex-col items-center justify-center">
        {isSubmitting && (
          <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center">
              <svg className="animate-spin h-10 w-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          </div>
        )}
        <div className="max-w-md w-full">
            <div className="w-full text-left mb-2">
                <button onClick={handleBackToTableInput} className="text-gray-300 font-bold p-2 transition-colors hover:text-rose-400">
                    {'<'} 테이블 선택
                </button>
            </div>
            <div className="flex justify-center mb-4">
                <Logo />
            </div>
            <p className="text-center font-bold text-lg text-rose-400 mb-2">테이블 {state.tableNumber}</p>
            <Card className="w-full" padding="p-4 sm:p-6">
                <PinPad
                  key={resetKey}
                  title={titles[state.pinMode]}
                  onComplete={handlePinComplete}
                  error={pinError}
                  pinLength={CUSTOMER_PIN_LENGTH}
                />
            </Card>
        </div>
    </div>
  );
};