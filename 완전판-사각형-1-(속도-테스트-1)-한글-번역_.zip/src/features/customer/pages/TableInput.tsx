
import React, { useState } from 'react';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { MAX_TABLE_NUMBER } from '../../../shared/constants';
import { Logo } from '../../../shared/components/Logo';
import { useCustomerContext } from '../contexts/CustomerSessionContext';

export const TableInput: React.FC = () => {
    const { handleSubmitTable, onExitToLanding, isSubmitting: isLoading } = useCustomerContext();
    const [input, setInput] = useState('');
    const [error, setError] = useState<string | null>(null);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading) return;
        setError(null); // Reset error on new submission
        const num = parseInt(input, 10);
        if (isNaN(num) || num <= 0) {
            setError('유효한 테이블 번호를 입력해주세요.');
            return;
        }
        if (num > MAX_TABLE_NUMBER) { 
            setError(`테이블 번호는 1번부터 ${MAX_TABLE_NUMBER}번까지입니다.`);
            return;
        }
        handleSubmitTable(num);
    };

    return (
        <div className="flex flex-col items-center justify-center flex-grow">
             <div className="w-full max-w-sm">
                <div className="w-full text-left mb-2">
                    <button onClick={onExitToLanding} className="text-gray-300 font-bold p-2 transition-colors hover:text-rose-400">{'<'} 홈으로</button>
                </div>
                <div className="flex justify-center mb-4">
                    <Logo />
                </div>
                <Card className="w-full">
                    <form onSubmit={handleSubmit}>
                        <label htmlFor="table-number" className="block text-center text-lg font-bold text-gray-200 mb-4">
                            테이블 번호를 입력해주세요
                        </label>
                        <input
                            id="table-number"
                            type="number"
                            value={input}
                            onChange={(e) => {
                                setInput(e.target.value);
                                if (error) setError(null); // Clear error while typing
                            }}
                            className="w-full bg-gray-700 text-white text-center text-2xl p-4 border-2 border-gray-600 rounded-2xl focus:ring-0 focus:border-rose-400 focus:shadow-[0_0_15px_rgba(239,116,144,0.4)] outline-none transition-all duration-300 disabled:opacity-70"
                            placeholder="예: 5"
                            autoFocus
                            disabled={isLoading}
                        />
                        {error && <p className="text-red-500 text-center mt-3 text-sm font-semibold">{error}</p>}
                        <Button type="submit" className="mt-6" isLoading={isLoading}>{isLoading ? '확인 중...' : '주문 시작'}</Button>
                    </form>
                </Card>
            </div>
        </div>
    );
};