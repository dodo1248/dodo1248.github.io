import React, { useMemo } from 'react';
import { OrderStatus } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { Toast } from '../../../shared/components/Toast';
import { Modal } from '../../../shared/components/Modal';
import { CallStaffModal } from '../components/CallStaffModal';
import { CustomerOrderCard } from '../components/CustomerOrderCard';
import { useOrderStatusLogic } from '../hooks/useOrderStatusLogic';
import { useCustomerContext } from '../contexts/CustomerSessionContext';

export const OrderStatusPage: React.FC = () => {
  const { state, handleGotoMenu, handleBackToTableInput } = useCustomerContext();
  const { tableNumber, operatingDay, existingOrders, mergedTables } = state;
  
  const {
    activeOrders,
    servedOrders,
    totalSpent,
    aggregatedItems,
    isCallModalOpen,
    openCallModal,
    closeCallModal,
    toastState,
    isCalling,
    cancelTargetOrder,
    openCancelModal,
    closeCancelModal,
    isCancelling,
    handleCallStaff,
    handleCancelOrder,
    handleReorder,
  } = useOrderStatusLogic({
    tableNumber: tableNumber!,
    operatingDay: operatingDay,
    onAddOrder: handleGotoMenu,
    initialOrders: existingOrders,
  });

  const mergedTableText = useMemo(() => {
    if (!mergedTables || mergedTables.length <= 1) return '';
    const otherTables = mergedTables.filter(t => t !== tableNumber).join(', ');
    return ` (합석: ${otherTables})`;
  }, [mergedTables, tableNumber]);


  return (
    <div className="pb-48 max-w-md mx-auto">
        <div className="sticky top-0 bg-black/70 backdrop-blur-xl z-10 py-4 -mx-4 px-4 transition-colors duration-300 border-b border-pink-500/20 shadow-sm shadow-black/20">
            <div className="flex justify-between items-center max-w-md mx-auto">
              <button onClick={handleBackToTableInput} className="text-gray-300 font-bold text-lg hover:text-rose-400">{'<'} 테이블 선택</button>
              <h1 className="text-center text-xl sm:text-2xl font-black text-white truncate px-2">테이블 {tableNumber}번{mergedTableText}</h1>
            </div>
        </div>

        {totalSpent > 0 && (
            <Card className="my-4" padding="p-0">
                <div className="p-4">
                    <h2 className="text-xl font-bold text-white">이번 방문 총 주문 내역 🧾</h2>
                </div>
                <div className="bg-gray-800/40 px-4 py-3 max-h-48 overflow-y-auto border-y border-gray-700/50">
                    <div className="space-y-3">
                        {aggregatedItems.map(item => (
                            <div key={item.name} className="flex justify-between items-center text-sm">
                                <p className="text-gray-300">{item.name} <span className="font-mono text-gray-400">x{item.quantity}</span></p>
                                <p className="font-semibold text-gray-100">{(item.price * item.quantity).toLocaleString()}원</p>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="p-4">
                    <div className="flex justify-between items-baseline">
                        <span className="text-xl font-bold text-gray-200">총 결제 금액</span>
                        <span className="text-3xl font-black text-rose-400">{totalSpent.toLocaleString()}원</span>
                    </div>
                </div>
            </Card>
        )}
        
        {activeOrders.length === 0 && servedOrders.length === 0 && existingOrders.filter(o => o.status === OrderStatus.CANCELLED).length === 0 ? (
            <Card className="mt-8 text-center py-10">
                <p className="text-gray-300 text-lg">아직 주문 내역이 없어요.</p>
                <p className="text-gray-400 mt-2">새로운 주문을 추가해보세요!</p>
            </Card>
        ) : (
            <div className="space-y-8 mt-6">
                <div>
                    <h2 className="text-xl font-bold text-white mb-4">진행 중인 주문</h2>
                    {activeOrders.length === 0 ? (
                        <Card padding="p-4"><p className="text-center text-gray-400">현재 진행 중인 주문이 없습니다.</p></Card>
                    ) : (
                        <div className="space-y-6">
                            {activeOrders.map(order => (
                                <CustomerOrderCard key={order.id} order={order} onReorder={handleReorder} />
                            ))}
                        </div>
                    )}
                </div>

                {servedOrders.length > 0 && (
                  <div>
                    <h2 className="text-xl font-bold text-white mb-4">완료된 주문</h2>
                    <div className="space-y-4">
                        {servedOrders.map(order => (
                            <CustomerOrderCard key={order.id} order={order} onReorder={handleReorder} />
                        ))}
                    </div>
                  </div>
                )}
            </div>
        )}

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-black/70 backdrop-blur-xl border-t border-rose-500/20">
            <div className="max-w-md mx-auto space-y-4">
                <Button onClick={handleGotoMenu}>추가 주문하기</Button>
                <Button variant="secondary" onClick={openCallModal} disabled={isCalling}>
                    {isCalling ? "호출 중..." : "🙋‍♂️ 스태프 호출"}
                </Button>
            </div>
        </div>
        <CallStaffModal 
            isOpen={isCallModalOpen}
            onClose={closeCallModal}
            onCall={handleCallStaff}
            isLoading={isCalling}
        />
        <Modal isOpen={!!cancelTargetOrder} onClose={closeCancelModal} title="주문 취소 확인">
          <div>
            <p className="text-center text-lg text-gray-200">정말로 주문을 취소하시겠습니까?</p>
            <div className="mt-4 p-3 bg-yellow-900/40 rounded-lg text-center">
              <p className="text-sm font-bold text-yellow-200">
                주문이 취소되면 입금하신 금액은<br/>스태프를 통해 직접 환불받으셔야 합니다.
              </p>
            </div>
            <div className="flex justify-center space-x-4 mt-6">
              <Button variant="secondary" onClick={closeCancelModal} className="w-1/2">닫기</Button>
              <Button 
                onClick={handleCancelOrder} 
                isLoading={isCancelling} 
                className="w-1/2 !bg-red-500 hover:!bg-red-600 !shadow-red-400/50"
              >
                취소 확정
              </Button>
            </div>
          </div>
        </Modal>
        <Toast message={toastState.message} show={toastState.show} type={toastState.type} />
    </div>
  )
};