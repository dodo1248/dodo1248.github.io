
import React from 'react';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { useCustomerContext } from '../contexts/CustomerSessionContext';

interface InfoItemProps {
    icon: string;
    title: string;
    children: React.ReactNode;
}

const InfoItem: React.FC<InfoItemProps> = ({ icon, title, children }) => (
    <div className="flex items-start space-x-3">
        <div className="text-2xl mt-1">{icon}</div>
        <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-white">{title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">{children}</p>
        </div>
    </div>
);

export const InfoPage: React.FC = () => {
    const { handleProceedToMenu } = useCustomerContext();

    return (
        <div className="flex flex-col items-center justify-center flex-grow animate-fade-in">
            <div className="w-full max-w-md">
                <Card padding="p-4 sm:p-6">
                    <div className="text-center mb-6">
                        <h2 className="text-xl sm:text-2xl font-black text-gray-800 dark:text-white">🍻 HEART Beat WATT 이용 안내 🍻</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">주문 전 잠시만 확인해주세요!</p>
                    </div>

                    <div className="space-y-5">
                        <InfoItem icon="📱" title="주문 방법">
                            메뉴를 보고 장바구니에 담아 '주문하기' 버튼을 눌러주세요.
                        </InfoItem>
                        <InfoItem icon="💳" title="결제 안내">
                            주문 후 QR코드 또는 계좌번호로 <strong>선불 결제</strong> 방식입니다. 입금 후 <strong>'입금 완료' 버튼을 꼭!</strong> 눌러주셔야 주문이 접수됩니다.
                        </InfoItem>
                        <InfoItem icon="💡" title="첫 주문 규칙">
                            첫 주문 시에는 <strong>메인 안주(HEART 또는 WATT)가 1개 이상</strong> 반드시 포함되어야 합니다.
                        </InfoItem>
                        <InfoItem icon="🙋‍♂️" title="스태프 호출">
                             추가 물, 기본 안주 등이 필요하시면 주문 현황 화면의 '스태프 호출' 기능을 이용해주세요.
                        </InfoItem>
                    </div>

                    <div className="text-center mt-6">
                         <p className="font-bold text-rose-500 dark:text-rose-400">즐거운 시간 보내세요!</p>
                    </div>

                    <Button onClick={handleProceedToMenu} className="mt-6">
                        네, 확인했습니다! 주문 시작하기
                    </Button>
                </Card>
            </div>
        </div>
    );
};