
import React from 'react';
import { Loading } from '../../shared/components/Loading';
import { CustomerSessionProvider, useCustomerContext } from './contexts/CustomerSessionContext';
import { CustomerRouter } from './components/CustomerRouter';

// This new inner component consumes the context provided by CustomerSessionProvider.
const CustomerViewContent: React.FC = () => {
  const { state } = useCustomerContext();

  if (state.pageState === 'LOADING') {
    return <div className="h-full flex items-center justify-center"><Loading message="영업 정보를 불러오는 중..." /></div>;
  }
  
  if (state.pageState === 'ERROR') {
    return <div className="flex flex-col items-center justify-center h-full p-4">
        <div className="w-full max-w-md bg-white/80 dark:bg-gray-800/80 p-6 rounded-2xl shadow-lg text-center">
            <h2 className="text-2xl font-bold text-red-500 mb-4">오류 발생</h2>
            <p className="text-gray-700 dark:text-gray-300 mb-4">앱을 시작하는 데 문제가 발생했습니다.</p>
            <div className="bg-red-50 dark:bg-gray-700 p-4 rounded-lg text-left">
              <p className="font-semibold text-red-700 dark:text-red-300">오류 메시지:</p>
              <p className="text-sm text-red-600 dark:text-red-200 break-words">{state.error}</p>
            </div>
            <button onClick={() => window.location.reload()} className="mt-6 w-full py-2 px-4 bg-rose-500 text-white font-bold rounded-lg hover:bg-rose-600 transition-colors">
                페이지 새로고침
            </button>
        </div>
    </div>;
  }

  // The router no longer needs props, as they are accessed via context.
  return <CustomerRouter />;
};

interface CustomerViewProps {
  onExitToLanding: () => void;
}

export const CustomerView: React.FC<CustomerViewProps> = ({ onExitToLanding }) => {
  return (
    <CustomerSessionProvider onExitToLanding={onExitToLanding}>
        <div className="min-h-full p-4 max-w-3xl mx-auto flex flex-col">
            <CustomerViewContent />
        </div>
    </CustomerSessionProvider>
  );
};