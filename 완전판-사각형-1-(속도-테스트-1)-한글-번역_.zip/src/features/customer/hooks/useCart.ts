import { useState, useEffect, useMemo } from 'react';
import { Cart, MenuItem, CartItem } from '../../../shared/types';
import { STORAGE_KEYS } from '../../../shared/constants';

export const useCart = () => {
    const [cart, setCart] = useState<Cart>({});
    
    useEffect(() => {
        const reorderItemJSON = sessionStorage.getItem(STORAGE_KEYS.REORDER_ITEM);
        if (reorderItemJSON) {
            try {
                const itemToReorder: CartItem = JSON.parse(reorderItemJSON);
                setCart(prevCart => {
                    const existingItem = prevCart[itemToReorder.id];
                    const newQuantity = existingItem ? existingItem.quantity + itemToReorder.quantity : itemToReorder.quantity;
                    return { ...prevCart, [itemToReorder.id]: { ...itemToReorder, quantity: newQuantity } };
                });
            } catch (e) {
                console.error("Failed to parse reorder item from sessionStorage", e);
            } finally {
                sessionStorage.removeItem(STORAGE_KEYS.REORDER_ITEM);
            }
        }
    }, []);

    const handleCartChange = (item: Pick<MenuItem, 'id' | 'name' | 'price' | 'category'>, quantity: number) => {
        setCart(prevCart => {
            const newCart = { ...prevCart };
            if (quantity > 0) {
                newCart[item.id] = { id: item.id, name: item.name, price: item.price, quantity, category: item.category };
            } else {
                delete newCart[item.id];
            }
            return newCart;
        });
    };

    const cartItems = useMemo(() => Object.values(cart), [cart]);
    const totalAmount = useMemo(() => cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0), [cartItems]);
    const totalItems = useMemo(() => cartItems.reduce((sum, item) => sum + item.quantity, 0), [cartItems]);
    
    return { cart, cartItems, totalAmount, totalItems, handleCartChange };
};