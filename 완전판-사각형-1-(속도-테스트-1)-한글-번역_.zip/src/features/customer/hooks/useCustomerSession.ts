import { useReducer, useEffect, useCallback, useRef } from 'react';
import { Order, MenuItem, PaymentInfo } from '../../../shared/types';
import { customerApi } from '../../../shared/api/customer';
import { STORAGE_KEYS } from '../../../shared/constants';
import { useTableAuth } from './useTableAuth';
import { supabase } from '../../../shared/api/supabaseClient';

type PageState = 'LOADING' | 'TABLE_INPUT' | 'PIN_INPUT' | 'INFO' | 'MENU' | 'ORDER_PLACED' | 'ORDER_STATUS' | 'ERROR' | 'REDIRECTING';

export interface CustomerState {
  pageState: PageState;
  tableNumber: number | null;
  menu: MenuItem[];
  paymentInfo: PaymentInfo | null;
  operatingDay: 1 | 2;
  latestOrder: Order | null;
  error: string | null;
  existingOrders: Order[];
  pinMode: 'setup' | 'confirm' | 'verify';
  pinToConfirm: string | null;
  mergedTables: number[];
  redirectInfo: {
      originalTable: number;
      mainTable: number;
  } | null;
}

type CustomerAction =
  | { type: 'INITIAL_DATA_LOADED'; payload: { menu: MenuItem[]; operatingDay: 1 | 2; paymentInfo: PaymentInfo } }
  | { type: 'INITIAL_DATA_LOADING_FAILED'; payload: { error: string } }
  | { type: 'SESSION_RESTORED'; payload: { tableNumber: number; existingOrders: Order[]; latestOrder?: Order, mergedTables: number[] } }
  | { type: 'NEW_SESSION_STARTED' }
  | { type: 'TABLE_STATUS_CHECKED'; payload: { tableNumber: number, pinIsSet: boolean } }
  | { type: 'PIN_SETUP_ENTERED'; payload: { pin: string } }
  | { type: 'PIN_CONFIRMED_OR_VERIFIED' }
  | { type: 'BACK_TO_TABLE_INPUT' }
  | { type: 'ORDER_PLACED'; payload: { newOrder: Order } }
  | { type: 'DATA_POLLED'; payload: { orders: Order[]; operatingDay: 1 | 2, mergedTables: number[] } }
  | { type: 'RETURN_TO_STATUS' }
  | { type: 'GOTO_MENU' }
  | { type: 'PROCEED_TO_MENU' }
  | { type: 'START_REDIRECT'; payload: { originalTable: number; mainTable: number } };

const initialState: CustomerState = {
  pageState: 'LOADING',
  tableNumber: null,
  menu: [],
  paymentInfo: null,
  operatingDay: 1,
  latestOrder: null,
  error: null,
  existingOrders: [],
  pinMode: 'setup',
  pinToConfirm: null,
  mergedTables: [],
  redirectInfo: null,
};

function customerReducer(state: CustomerState, action: CustomerAction): CustomerState {
  switch (action.type) {
    case 'INITIAL_DATA_LOADED':
      return { ...state, ...action.payload };
    case 'INITIAL_DATA_LOADING_FAILED':
      return { ...state, pageState: 'ERROR', error: action.payload.error };
    case 'SESSION_RESTORED': {
      sessionStorage.setItem(STORAGE_KEYS.TABLE, String(action.payload.tableNumber));
      const { tableNumber, existingOrders, latestOrder, mergedTables } = action.payload;
      const hasOrderedBefore = sessionStorage.getItem(`${STORAGE_KEYS.HAS_ORDERED_PREFIX}${tableNumber}`) === 'true';
      let pageState: PageState = latestOrder ? 'ORDER_PLACED' : (existingOrders.length > 0 || hasOrderedBefore) ? 'ORDER_STATUS' : 'INFO';
      return { ...state, tableNumber, latestOrder: latestOrder || null, existingOrders, pageState, mergedTables };
    }
    case 'NEW_SESSION_STARTED':
      return { ...state, pageState: 'TABLE_INPUT' };
    case 'START_REDIRECT':
        return {
            ...state,
            pageState: 'REDIRECTING',
            redirectInfo: action.payload,
        };
    case 'TABLE_STATUS_CHECKED':
        return {
            ...state,
            redirectInfo: null, // Clear redirect info when moving to PIN input
            tableNumber: action.payload.tableNumber,
            pageState: 'PIN_INPUT',
            pinMode: action.payload.pinIsSet ? 'verify' : 'setup',
        };
    case 'PIN_SETUP_ENTERED':
        return { ...state, pinMode: 'confirm', pinToConfirm: action.payload.pin };
    case 'PIN_CONFIRMED_OR_VERIFIED': {
        const hasOrderedBefore = sessionStorage.getItem(`${STORAGE_KEYS.HAS_ORDERED_PREFIX}${state.tableNumber}`) === 'true';
        const pageState: PageState = (state.existingOrders.length > 0 || hasOrderedBefore) ? 'ORDER_STATUS' : 'INFO';
        sessionStorage.setItem(STORAGE_KEYS.TABLE, String(state.tableNumber));
        return { ...state, pageState: pageState, pinToConfirm: null };
    }
    case 'BACK_TO_TABLE_INPUT':
        sessionStorage.removeItem(STORAGE_KEYS.TABLE);
        return { ...state, pageState: 'TABLE_INPUT', tableNumber: null, error: null, pinToConfirm: null, mergedTables: [], redirectInfo: null };
    case 'ORDER_PLACED':
      sessionStorage.setItem(STORAGE_KEYS.LATEST_ORDER, JSON.stringify(action.payload.newOrder));
      return { ...state, latestOrder: action.payload.newOrder, pageState: 'ORDER_PLACED' };
    case 'RETURN_TO_STATUS':
      sessionStorage.removeItem(STORAGE_KEYS.LATEST_ORDER);
      return { ...state, latestOrder: null, pageState: 'ORDER_STATUS' };
    case 'PROCEED_TO_MENU':
      return { ...state, pageState: 'MENU' };
    case 'GOTO_MENU':
      return { ...state, pageState: 'MENU' };
    case 'DATA_POLLED': {
        if (action.payload.operatingDay !== state.operatingDay) {
            return { ...state, pageState: 'ERROR', error: '운영일이 변경되었습니다. 앱을 다시 시작해주세요.' };
        }
        return { ...state, existingOrders: action.payload.orders, operatingDay: action.payload.operatingDay, mergedTables: action.payload.mergedTables };
    }
    default:
      return state;
  }
}

interface UseCustomerSessionProps {
    onExitToLanding: () => void;
}

export const useCustomerSession = ({ onExitToLanding }: UseCustomerSessionProps) => {
    const [state, dispatch] = useReducer(customerReducer, initialState);
    const auth = useTableAuth();
    const stateRef = useRef(state);
    
    useEffect(() => {
        stateRef.current = state;
    }, [state]);
    
    useEffect(() => {
        const initialize = async () => {
          try {
            const { menu, operatingDay, paymentInfo } = await customerApi.fetchInitialData();
            dispatch({ type: 'INITIAL_DATA_LOADED', payload: { menu, operatingDay, paymentInfo } });
    
            const savedTable = sessionStorage.getItem(STORAGE_KEYS.TABLE);
            if (savedTable) {
                // If session is restored, we skip PIN check and go directly to status
                const tableNum = parseInt(savedTable, 10);
                const savedLatestOrderJSON = sessionStorage.getItem(STORAGE_KEYS.LATEST_ORDER);
                const latestOrder = savedLatestOrderJSON ? JSON.parse(savedLatestOrderJSON) : undefined;
                const { orders, mergedTables } = await customerApi.pollCustomerData(tableNum);
                dispatch({ type: 'SESSION_RESTORED', payload: { tableNumber: tableNum, existingOrders: orders, latestOrder, mergedTables } });
            } else {
                dispatch({ type: 'NEW_SESSION_STARTED' });
            }
          } catch (error: any) {
            dispatch({ type: 'INITIAL_DATA_LOADING_FAILED', payload: { error: error.message } });
          }
        };
        initialize();
      }, []);

    useEffect(() => {
        if (state.pageState === 'REDIRECTING' && state.redirectInfo) {
            const performRedirect = async () => {
                try {
                    const { mainTable } = state.redirectInfo!;
                    const { orders: mainTableOrders, mergedTables } = await customerApi.pollCustomerData(mainTable);
                    dispatch({ type: 'DATA_POLLED', payload: { orders: mainTableOrders, operatingDay: state.operatingDay, mergedTables } });
                    dispatch({ type: 'TABLE_STATUS_CHECKED', payload: { tableNumber: mainTable, pinIsSet: true } });
                } catch (error: any) {
                    dispatch({ type: 'INITIAL_DATA_LOADING_FAILED', payload: { error: error.message } });
                }
            };
            performRedirect();
        }
    }, [state.pageState, state.redirectInfo, state.operatingDay]);

    // Enhanced Real-time and Polling Logic
    useEffect(() => {
        if (!state.tableNumber || (state.pageState !== 'ORDER_STATUS' && state.pageState !== 'MENU')) return;

        const refreshData = async () => {
            if (document.hidden) return; // Don't refresh if tab is not active
            try {
                const tableNum = stateRef.current.tableNumber;
                if (tableNum) {
                    const data = await customerApi.pollCustomerData(tableNum);
                    dispatch({ type: 'DATA_POLLED', payload: data });
                }
            } catch (error) {
                console.error('Customer data refresh failed:', error);
            }
        };

        // 1. Real-time Subscription
        const mainTableNumber = (state.mergedTables && state.mergedTables.length > 0) ? state.mergedTables[0] : state.tableNumber;
        const channel = supabase.channel(`customer-table-group-${mainTableNumber}`);
        const tableNumbersInGroup = state.mergedTables.length > 0 ? state.mergedTables : [state.tableNumber];
        
        const orderSubscription = { event: '*', schema: 'public', table: 'orders', filter: `table_number=in.(${tableNumbersInGroup.join(',')})` } as const;
        const tableSubscription = { event: '*', schema: 'public', table: 'tables', filter: `table_number=in.(${tableNumbersInGroup.join(',')})` } as const;
        const settingsSubscription = { event: 'UPDATE', schema: 'public', table: 'settings', filter: 'key=eq.operating_day'} as const;

        channel
            .on('postgres_changes', orderSubscription, refreshData)
            .on('postgres_changes', tableSubscription, refreshData)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'order_items' }, (payload: any) => {
                 const currentOrderIds = new Set(stateRef.current.existingOrders.map(o => o.id));
                 if (payload.new?.order_id && currentOrderIds.has(payload.new.order_id)) {
                     refreshData();
                 }
            })
            .on('postgres_changes', settingsSubscription, (payload: any) => {
                const newDay = payload.new.value?.day;
                if (newDay && newDay !== stateRef.current.operatingDay) {
                    dispatch({ type: 'INITIAL_DATA_LOADING_FAILED', payload: { error: '운영일이 변경되었습니다. 앱을 다시 시작해주세요.' } });
                }
            })
            .subscribe((status, err) => {
                if (status === 'SUBSCRIBED') {
                    console.log(`✅ Customer real-time connection established for table group ${mainTableNumber}.`);
                }
                if (status === 'CHANNEL_ERROR') {
                    console.error(`❌ Customer real-time connection error for table group ${mainTableNumber}:`, err);
                }
            });

        // 2. Polling as a Fail-safe
        const intervalId = setInterval(refreshData, 1000); // Poll every 1 second

        return () => {
            clearInterval(intervalId);
            supabase.removeChannel(channel);
        };
    }, [state.tableNumber, state.mergedTables, state.pageState]);

    const handleSubmitTable = useCallback(async (tableNumber: number) => {
        try {
            const { pinIsSet, orders, mainTableNumber } = await auth.submitTable(tableNumber);
            
            if (mainTableNumber) {
                dispatch({ type: 'START_REDIRECT', payload: { originalTable: tableNumber, mainTable: mainTableNumber } });
            } else {
                dispatch({ type: 'DATA_POLLED', payload: { orders, operatingDay: state.operatingDay, mergedTables: [tableNumber] } });
                dispatch({ type: 'TABLE_STATUS_CHECKED', payload: { tableNumber, pinIsSet } });
            }
        } catch (error: any) {
            dispatch({ type: 'INITIAL_DATA_LOADING_FAILED', payload: { error: error.message }});
        }
    }, [auth, state.operatingDay]);
    
    const handlePinComplete = useCallback(async (pin: string) => {
        try {
            const result = await auth.submitPin(pin, {
                operatingDay: state.operatingDay,
                tableNumber: state.tableNumber!,
                pinMode: state.pinMode,
                pinToConfirm: state.pinToConfirm,
            });

            if (result?.mode === 'confirm') {
                dispatch({ type: 'PIN_SETUP_ENTERED', payload: { pin: result.pinToConfirm! } });
            } else if (result?.authenticated) {
                dispatch({ type: 'PIN_CONFIRMED_OR_VERIFIED' });
            }
        } catch (error: any) {
            if (error.message.includes('일치하지 않습니다')) {
                // PIN mismatch on confirmation, reset the setup flow
                setTimeout(() => {
                    dispatch({ type: 'TABLE_STATUS_CHECKED', payload: { tableNumber: state.tableNumber!, pinIsSet: false } });
                }, 1500);
            }
        }
    }, [auth, state.operatingDay, state.tableNumber, state.pinMode, state.pinToConfirm]);
    
    const handleBackToTableInput = useCallback(() => dispatch({ type: 'BACK_TO_TABLE_INPUT' }), []);

    const handleOrderPlaced = (newOrder: Order) => {
        if (state.tableNumber) sessionStorage.setItem(`${STORAGE_KEYS.HAS_ORDERED_PREFIX}${state.tableNumber}`, 'true');
        dispatch({ type: 'ORDER_PLACED', payload: { newOrder } });
    };

    const handleReturnToStatus = () => dispatch({ type: 'RETURN_TO_STATUS' });
    const handleProceedToMenu = () => dispatch({ type: 'PROCEED_TO_MENU' });
    const handleGotoMenu = () => dispatch({ type: 'GOTO_MENU' });
    const handleBackToStatusFromMenu = () => dispatch({ type: 'RETURN_TO_STATUS' });

    return {
        state,
        isSubmitting: auth.isSubmitting,
        pinError: auth.pinError,
        handleSubmitTable,
        handlePinComplete,
        handleBackToTableInput,
        handleOrderPlaced,
        handleReturnToStatus,
        handleProceedToMenu,
        handleGotoMenu,
        handleBackToStatusFromMenu,
        onExitToLanding,
    };
};