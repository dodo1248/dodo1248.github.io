
import { useState } from 'react';
import { Order, CartItem } from '../../../shared/types';
import { customerApi } from '../../../shared/api/customer';
import { useOptimisticOrders } from './useOptimisticOrders';
import { useOrderAggregation } from './useOrderAggregation';
import { STORAGE_KEYS } from '../../../shared/constants';

interface UseOrderStatusLogicProps {
    tableNumber: number;
    operatingDay: 1 | 2;
    onAddOrder: () => void;
    initialOrders: Order[];
}

export const useOrderStatusLogic = ({ tableNumber, operatingDay, onAddOrder, initialOrders }: UseOrderStatusLogicProps) => {
    const { orders, activeOrders, servedOrders, setOrders } = useOptimisticOrders(initialOrders);
    const [isCallModalOpen, setIsCallModalOpen] = useState(false);
    const [toastState, setToastState] = useState<{ show: boolean; message: string; type: 'success' | 'error' }>({ show: false, message: '', type: 'success' });
    const [isCalling, setIsCalling] = useState(false);
    const [cancelTargetOrder, setCancelTargetOrder] = useState<Order | null>(null);
    const [isCancelling, setIsCancelling] = useState(false);

    const displayToast = (message: string, type: 'success' | 'error' = 'success', duration = 3000) => {
        setToastState({ show: true, message, type });
        setTimeout(() => setToastState(prev => ({ ...prev, show: false })), duration);
    };

    const handleCallStaff = async (reason: string) => {
        setIsCalling(true);
        try {
            await customerApi.callStaff(operatingDay, tableNumber, reason);
            displayToast('스태프를 호출했습니다.');
        } catch (error: any) {
            displayToast(`호출에 실패했습니다: ${error.message}`, 'error');
            console.error("Staff call failed", error);
        } finally {
            setIsCalling(false);
            setIsCallModalOpen(false);
        }
    };

    const handleCancelOrder = async () => {
        if (!cancelTargetOrder) return;
        setIsCancelling(true);
        const originalOrders = orders;
        try {
            // Optimistically update UI
            setOrders(currentOrders => currentOrders.filter(o => o.id !== cancelTargetOrder.id));
            await customerApi.cancelOrder(operatingDay, cancelTargetOrder.id);
            displayToast('주문이 성공적으로 취소되었습니다.');
        } catch (error: any) {
            // Revert on failure
            setOrders(originalOrders);
            displayToast(`주문 취소에 실패했습니다: ${error.message}`, 'error');
            console.error("Order cancellation failed", error);
        } finally {
            setIsCancelling(false);
            setCancelTargetOrder(null);
        }
    };

    const handleReorder = (item: CartItem) => {
        const reorderItem: CartItem = {
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: 1,
            category: item.category,
        };
        sessionStorage.setItem(STORAGE_KEYS.REORDER_ITEM, JSON.stringify(reorderItem));
        onAddOrder();
    };

    const { totalSpent, aggregatedItems } = useOrderAggregation(orders);

    return {
        activeOrders,
        servedOrders,
        totalSpent,
        aggregatedItems,
        isCallModalOpen,
        openCallModal: () => setIsCallModalOpen(true),
        closeCallModal: () => setIsCallModalOpen(false),
        toastState,
        isCalling,
        cancelTargetOrder,
        openCancelModal: setCancelTargetOrder,
        closeCancelModal: () => setCancelTargetOrder(null),
        isCancelling,
        handleCallStaff,
        handleCancelOrder,
        handleReorder,
    };
};
