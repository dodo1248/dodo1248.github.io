import { useState, useEffect, useMemo } from 'react';
import { Order, OrderStatus } from '../../../shared/types';

export const useOptimisticOrders = (liveOrders: Order[]) => {
    const [orders, setOrders] = useState<Order[]>(liveOrders);

    useEffect(() => {
        // Sync with live data from parent, which is polling the server.
        setOrders(liveOrders);
    }, [liveOrders]);

    const activeOrders = useMemo(() => orders.filter(o => o.status !== OrderStatus.SERVED && o.status !== OrderStatus.CANCELLED), [orders]);
    const servedOrders = useMemo(() => orders.filter(o => o.status === OrderStatus.SERVED), [orders]);

    return { orders, activeOrders, servedOrders, setOrders };
};
