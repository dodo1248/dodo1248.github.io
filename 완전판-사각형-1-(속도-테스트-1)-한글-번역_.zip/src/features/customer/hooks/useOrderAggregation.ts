
import { useMemo } from 'react';
import { Order, OrderStatus } from '../../../shared/types';

export const useOrderAggregation = (orders: Order[]) => {
    return useMemo(() => {
        const validOrders = orders.filter(o => o.status !== OrderStatus.CANCELLED);
        if (validOrders.length === 0) return { totalSpent: 0, aggregatedItems: [] };
        
        const total = validOrders.reduce((sum, order) => sum + order.totalPrice, 0);

        const allItems = validOrders.flatMap(order => order.items);
        const itemMap = new Map<number, { id: number; name: string; quantity: number; price: number }>();
        
        allItems.forEach(item => {
            const existing = itemMap.get(item.id);
            if (existing) {
                existing.quantity += item.quantity;
            } else {
                itemMap.set(item.id, {
                    id: item.id,
                    name: item.name,
                    quantity: item.quantity,
                    price: item.price,
                });
            }
        });

        const aggregated = Array.from(itemMap.values()).sort((a, b) => a.name.localeCompare(b.name));
        return { totalSpent: total, aggregatedItems: aggregated };
    }, [orders]);
};
