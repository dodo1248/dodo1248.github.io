import { useState, useCallback } from 'react';
import { customerApi } from '../../../shared/api/customer';
import { Order } from '../../../shared/types';

interface SubmitTableResult {
    pinIsSet: boolean;
    orders: Order[];
    mainTableNumber?: number;
}

interface SubmitPinOptions {
    operatingDay: 1 | 2;
    tableNumber: number;
    pinMode: 'setup' | 'confirm' | 'verify';
    pinToConfirm: string | null;
}

interface SubmitPinResult {
    authenticated: boolean;
    mode?: 'setup' | 'confirm' | 'verify';
    pinToConfirm?: string | null;
}

export const useTableAuth = () => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [pinError, setPinError] = useState('');

    const submitTable = useCallback(async (tableNumber: number): Promise<SubmitTableResult> => {
        setIsSubmitting(true);
        try {
            const { status, pinIsSet, mainTableNumber } = await customerApi.checkTableStatus(tableNumber);
            
            // The staff call status (`CALLED`) should not block the customer from ordering.
            // The check for this status has been intentionally removed.

            if (mainTableNumber) {
                // This is a merged table, the session hook will handle redirecting.
                // We don't need to poll for orders here.
                return { pinIsSet: true, orders: [], mainTableNumber };
            }

            const { orders } = await customerApi.pollCustomerData(tableNumber);
            return { pinIsSet, orders };
        } finally {
            setIsSubmitting(false);
        }
    }, []);

    const submitPin = useCallback(async (pin: string, options: SubmitPinOptions): Promise<SubmitPinResult | undefined> => {
        setIsSubmitting(true);
        setPinError('');

        try {
            const { tableNumber, pinMode, pinToConfirm } = options;
            
            if (pinMode === 'setup') {
                return { authenticated: false, mode: 'confirm', pinToConfirm: pin };
            }
            
            if (pinMode === 'confirm') {
                if (pin !== pinToConfirm) {
                    setPinError('PIN이 일치하지 않습니다. 다시 설정해주세요.');
                    throw new Error('PIN이 일치하지 않습니다. 다시 설정해주세요.');
                }
                await customerApi.setTablePin(tableNumber, pin);
                return { authenticated: true };
            }
            
            if (pinMode === 'verify') {
                const { isValid } = await customerApi.verifyTablePin(tableNumber, pin);
                if (!isValid) {
                    setPinError('PIN이 일치하지 않습니다.');
                    return { authenticated: false };
                }
                return { authenticated: true };
            }

        } catch (error: any) {
            // Only set pinError for actual API errors if not already set for mismatch
            if (!pinError) {
                setPinError(error.message || '오류가 발생했습니다.');
            }
            throw error; // Re-throw to be caught by the calling component if needed
        } finally {
            setIsSubmitting(false);
        }
    }, [pinError]);


    return {
        isSubmitting,
        pinError,
        submitTable,
        submitPin,
    };
};