import React from 'react';
import { TableInput } from '../pages/TableInput';
import { InfoPage } from '../pages/InfoPage';
import { MenuPage } from '../pages/MenuPage';
import { OrderPlaced } from '../pages/OrderPlaced';
import { OrderStatusPage } from '../pages/OrderStatusPage';
import { PinInputPage } from '../pages/PinInputPage';
import { Loading } from '../../../shared/components/Loading';
import { useCustomerContext } from '../contexts/CustomerSessionContext';

export const CustomerRouter: React.FC = () => {
    const { state, handleReturnToStatus, handleBackToTableInput } = useCustomerContext();

    switch (state.pageState) {
        case 'TABLE_INPUT':
            return <TableInput />;
        
        case 'REDIRECTING':
            if (state.redirectInfo) {
                return (
                    <div className="min-h-screen">
                        <Loading 
                            message={`${state.redirectInfo.originalTable}번 테이블은 ${state.redirectInfo.mainTable}번과 합석 상태입니다. 주문 화면으로 이동합니다...`} 
                        />
                    </div>
                );
            }
            // Fallback
            handleBackToTableInput(); 
            return null;

        case 'PIN_INPUT':
            return <PinInputPage />;
        
        case 'INFO':
            return <InfoPage />;

        case 'MENU':
            if (state.tableNumber && state.menu.length > 0) {
                return <MenuPage />
            }
            return <div className="min-h-screen"><Loading message="메뉴를 준비하는 중..." /></div>;

        case 'ORDER_PLACED':
            if (state.latestOrder && state.paymentInfo) {
                return <OrderPlaced />;
            }
            // Fallback: If required data is missing, go back to the status page.
            handleReturnToStatus();
            return null;

        case 'ORDER_STATUS':
             if (state.tableNumber) {
                return <OrderStatusPage />
             }
             // Fallback: If table number is missing, return to the start.
             handleBackToTableInput();
             return null;
        
        default:
            return <div>잘못된 페이지 상태입니다.</div>
    }
}