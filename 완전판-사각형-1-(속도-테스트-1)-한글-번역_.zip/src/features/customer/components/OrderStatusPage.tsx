import React, { useState, useMemo } from 'react';
import { Order, OrderStatus, CartItem } from '../../../shared/types';
import { customerApi } from '../../../shared/api/customer';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { Toast } from '../../../shared/components/Toast';
import { Modal } from '../../../shared/components/Modal';
import { CallStaffModal } from './CallStaffModal';
import { useOptimisticOrders } from '../hooks/useOptimisticOrders';
import { STORAGE_KEYS } from '../../../shared/constants';
import { CustomerOrderCard } from './CustomerOrderCard';

export const OrderStatusPage: React.FC<{ tableNumber: number, operatingDay: 1|2, onAddOrder: () => void, onBack: () => void, isDarkMode: boolean, toggleDarkMode: () => void, orders: Order[] }> = ({ tableNumber, operatingDay, onAddOrder, onBack, isDarkMode, toggleDarkMode, orders: liveOrders }) => {
  const { orders, activeOrders, servedOrders, setOrders } = useOptimisticOrders(liveOrders);
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error'>('success');
  const [isCalling, setIsCalling] = useState(false);
  const [cancelTargetOrder, setCancelTargetOrder] = useState<Order | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  
  const displayToast = (message: string, type: 'success' | 'error' = 'success', duration = 3000) => {
    setToastMessage(message);
    setToastType(type);
    setShowToast(true);
    setTimeout(() => setShowToast(false), duration);
  };

  const handleCallStaff = async (reason: string) => {
    setIsCalling(true);
    try {
        await customerApi.callStaff(operatingDay, tableNumber, reason);
        displayToast('스태프를 호출했습니다.');
    } catch (error: any) {
        displayToast(`호출에 실패했습니다: ${error.message}`, 'error');
        console.error("Staff call failed", error);
    } finally {
        setIsCalling(false);
        setIsCallModalOpen(false);
    }
  };

  const handleCancelOrder = async () => {
    if (!cancelTargetOrder) return;
    setIsCancelling(true);
    const originalOrders = orders;
    try {
      // Optimistically update UI
      setOrders(currentOrders => currentOrders.filter(o => o.id !== cancelTargetOrder.id));
      await customerApi.cancelOrder(operatingDay, cancelTargetOrder.id);
      displayToast('주문이 성공적으로 취소되었습니다.');
    } catch (error: any) {
      // Revert on failure
      setOrders(originalOrders);
      displayToast(`주문 취소에 실패했습니다: ${error.message}`, 'error');
      console.error("Order cancellation failed", error);
    } finally {
      setIsCancelling(false);
      setCancelTargetOrder(null);
    }
  };

  const handleReorder = (item: CartItem) => {
    const reorderItem: CartItem = {
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: 1,
      category: item.category,
    };
    sessionStorage.setItem(STORAGE_KEYS.REORDER_ITEM, JSON.stringify(reorderItem));
    onAddOrder();
  };

  const { totalSpent, aggregatedItems } = useMemo(() => {
    const validOrders = orders.filter(o => o.status !== OrderStatus.CANCELLED);
    if (validOrders.length === 0) return { totalSpent: 0, aggregatedItems: [] };
    
    const total = validOrders.reduce((sum, order) => sum + order.totalPrice, 0);

    const allItems = validOrders.flatMap(order => order.items);
    const itemMap = new Map<number, { name: string; quantity: number; price: number }>();
    
    allItems.forEach(item => {
        const existing = itemMap.get(item.id);
        if (existing) {
            existing.quantity += item.quantity;
        } else {
            itemMap.set(item.id, {
                name: item.name,
                quantity: item.quantity,
                price: item.price,
            });
        }
    });

    const aggregated = Array.from(itemMap.values()).sort((a, b) => a.name.localeCompare(b.name));
    return { totalSpent: total, aggregatedItems: aggregated };
  }, [orders]);


  return (
    <div className="pb-48 max-w-md mx-auto">
        <div className="sticky top-0 bg-white/80 dark:bg-black/70 backdrop-blur-xl z-10 py-4 -mx-4 px-4 transition-colors duration-300 border-b border-pink-100 dark:border-pink-500/20 shadow-sm shadow-pink-100/30 dark:shadow-black/20">
            <div className="flex justify-between items-center max-w-md mx-auto">
              <button onClick={onBack} className="text-gray-600 dark:text-gray-300 font-bold text-lg hover:text-rose-500 dark:hover:text-rose-400">{'<'} 테이블 선택</button>
              <h1 className="text-center text-xl sm:text-2xl font-black text-gray-800 dark:text-white truncate px-2">테이블 {tableNumber}번 주문현황</h1>
              <button onClick={toggleDarkMode} className="p-2 rounded-full bg-white/50 dark:bg-gray-800/50 text-2xl">
                {isDarkMode ? '☀️' : '🌙'}
              </button>
            </div>
        </div>

        {totalSpent > 0 && (
            <Card className="my-4" padding="p-0">
                <div className="p-4">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-white">이번 방문 총 주문 내역 🧾</h2>
                </div>
                <div className="bg-rose-50/40 dark:bg-gray-800/40 px-4 py-3 max-h-48 overflow-y-auto border-y border-rose-100 dark:border-gray-700/50">
                    <div className="space-y-3">
                        {aggregatedItems.map(item => (
                            <div key={item.name} className="flex justify-between items-center text-sm">
                                <p className="text-gray-700 dark:text-gray-300">{item.name} <span className="font-mono text-gray-500 dark:text-gray-400">x{item.quantity}</span></p>
                                <p className="font-semibold text-gray-800 dark:text-gray-100">{(item.price * item.quantity).toLocaleString()}원</p>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="p-4">
                    <div className="flex justify-between items-baseline">
                        <span className="text-xl font-bold text-gray-800 dark:text-gray-200">총 결제 금액</span>
                        <span className="text-3xl font-black text-rose-500 dark:text-rose-400">{totalSpent.toLocaleString()}원</span>
                    </div>
                </div>
            </Card>
        )}
        
        {activeOrders.length === 0 && servedOrders.length === 0 && orders.filter(o => o.status === OrderStatus.CANCELLED).length === 0 ? (
            <Card className="mt-8 text-center py-10">
                <p className="text-gray-600 dark:text-gray-300 text-lg">아직 주문 내역이 없어요.</p>
                <p className="text-gray-500 dark:text-gray-400 mt-2">새로운 주문을 추가해보세요!</p>
            </Card>
        ) : (
            <div className="space-y-8 mt-6">
                <div>
                    <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">진행 중인 주문</h2>
                    {activeOrders.length === 0 ? (
                        <Card padding="p-4"><p className="text-center text-gray-500 dark:text-gray-400">현재 진행 중인 주문이 없습니다.</p></Card>
                    ) : (
                        <div className="space-y-6">
                            {activeOrders.map(order => (
                                <CustomerOrderCard key={order.id} order={order} onReorder={handleReorder} />
                            ))}
                        </div>
                    )}
                </div>

                {servedOrders.length > 0 && (
                  <div>
                    <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">완료된 주문</h2>
                    <div className="space-y-4">
                        {servedOrders.map(order => (
                            <CustomerOrderCard key={order.id} order={order} onReorder={handleReorder} />
                        ))}
                    </div>
                  </div>
                )}
            </div>
        )}

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-black/70 backdrop-blur-xl border-t border-rose-500/20 dark:border-rose-500/20">
            <div className="max-w-md mx-auto space-y-4">
                <Button onClick={onAddOrder}>추가 주문하기</Button>
                <Button variant="secondary" onClick={() => setIsCallModalOpen(true)} disabled={isCalling}>
                    {isCalling ? "호출 중..." : "🙋‍♂️ 스태프 호출"}
                </Button>
            </div>
        </div>
        <CallStaffModal 
            isOpen={isCallModalOpen}
            onClose={() => setIsCallModalOpen(false)}
            onCall={handleCallStaff}
            isLoading={isCalling}
        />
        <Modal isOpen={!!cancelTargetOrder} onClose={() => setCancelTargetOrder(null)} title="주문 취소 확인">
          <div>
            <p className="text-center text-lg dark:text-gray-200">정말로 주문을 취소하시겠습니까?</p>
            <div className="mt-4 p-3 bg-yellow-100 dark:bg-yellow-900/40 rounded-lg text-center">
              <p className="text-sm font-bold text-yellow-800 dark:text-yellow-200">
                주문이 취소되면 입금하신 금액은<br/>스태프를 통해 직접 환불받으셔야 합니다.
              </p>
            </div>
            <div className="flex justify-center space-x-4 mt-6">
              <Button variant="secondary" onClick={() => setCancelTargetOrder(null)} className="w-1/2">닫기</Button>
              <Button 
                onClick={handleCancelOrder} 
                isLoading={isCancelling} 
                className="w-1/2 !bg-red-500 hover:!bg-red-600 !shadow-red-400/50"
              >
                취소 확정
              </Button>
            </div>
          </div>
        </Modal>
        <Toast message={toastMessage} show={showToast} type={toastType} />
    </div>
  )
};