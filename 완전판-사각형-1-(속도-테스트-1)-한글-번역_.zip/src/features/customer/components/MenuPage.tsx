import React, { useState, useEffect, useMemo, useRef } from 'react';
// FIX: Import MenuItem type to be used in component props.
import { MenuCategory, Order, CartItem, MenuItem } from '../../../shared/types';
import { customerApi } from '../../../shared/api/customer';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { ImageWithLoader } from '../../../shared/components/ImageWithLoader';
import { Modal } from '../../../shared/components/Modal';
import { Loading } from '../../../shared/components/Loading';
import { CartModal } from './CartModal';
import { MAIN_CATEGORIES } from '../../../shared/constants';
import { useCart } from '../hooks/useCart';
import { ExistingOrderSummary } from './ExistingOrderSummary';

// Co-located component for rendering a single menu item card
const MenuItemCard: React.FC<{
    item: MenuItem;
    quantity: number;
    onCartChange: (item: MenuItem, quantity: number) => void;
}> = ({ item, quantity, onCartChange }) => {

    const quantityTextStyle: React.CSSProperties = {
        textShadow: '-1px -1px 0 #ef7490, 1px -1px 0 #ef7490, -1px 1px 0 #ef7490, 1px 1px 0 #ef7490'
    };
    
    return (
        <Card
            padding="p-4"
            className={`transition-all duration-300 ${item.isSoldOut ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-2xl hover:-translate-y-1'} ${quantity > 0 ? 'ring-2 ring-rose-400 dark:ring-rose-500' : ''}`}
        >
            <div className="flex space-x-4 items-center">
                <div className="w-24 h-24 flex-shrink-0 relative">
                    <ImageWithLoader src={item.imageUrl} alt={item.name} className="w-full h-full object-cover rounded-2xl" />
                    {item.isSoldOut && (
                        <div className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center">
                            <span className="text-white text-lg font-bold">품절</span>
                        </div>
                    )}
                </div>

                <div className="flex flex-col flex-grow justify-between min-h-[6rem]">
                    <div>
                        <h3 className="font-bold text-lg text-gray-800 dark:text-white leading-tight">{item.name}</h3>
                        <p className="text-gray-600 dark:text-gray-300 font-semibold text-md mt-1">{item.price.toLocaleString()}원</p>
                    </div>
                    
                    {!item.isSoldOut && (
                         <div className="relative h-10 w-28 self-end mt-2">
                            <div className={`absolute inset-0 transition-all duration-300 ${quantity > 0 ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100 scale-100'}`}>
                                <button
                                    onClick={() => onCartChange(item, 1)}
                                    className="w-full h-full rounded-full font-bold bg-rose-500 text-white backdrop-blur-sm hover:bg-rose-600 transition-colors"
                                    aria-label={`${item.name} 장바구니에 담기`}
                                >
                                  담기
                                </button>
                            </div>
                            <div className={`absolute inset-0 flex items-center justify-between transition-all duration-300 ${quantity > 0 ? 'opacity-100 scale-100' : 'opacity-0 scale-90 pointer-events-none'}`}>
                                <button
                                    onClick={() => onCartChange(item, quantity - 1)}
                                    className="w-10 h-10 rounded-full bg-rose-100 dark:bg-gray-700 text-rose-600 dark:text-rose-300 text-2xl font-bold flex items-center justify-center transition-transform hover:scale-110"
                                    aria-label={`${item.name} 수량 줄이기`}
                                >-</button>
                                <span
                                    className="text-lg font-bold w-8 text-center tabular-nums text-white"
                                    style={quantityTextStyle}
                                >{quantity}</span>
                                <button
                                    onClick={() => onCartChange(item, quantity + 1)}
                                    className="w-10 h-10 rounded-full bg-rose-500 text-white text-2xl font-bold flex items-center justify-center transition-transform hover:scale-110"
                                    aria-label={`${item.name} 수량 늘리기`}
                                >+</button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </Card>
    );
};


export const MenuPage: React.FC<{ menu: MenuItem[], tableNumber: number; operatingDay: 1 | 2; onOrderPlaced: (newOrder: Order) => void; onBack: () => void; existingOrders?: Order[] }> = ({ menu, tableNumber, operatingDay, onOrderPlaced, onBack, existingOrders = [] }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [orderRequest, setOrderRequest] = useState('');
  const [isCartVisible, setIsCartVisible] = useState(false);
  const [isRuleModalOpen, setIsRuleModalOpen] = useState(false);
  const { cart, cartItems, totalAmount, totalItems, handleCartChange } = useCart();

  const isFirstOrder = useMemo(() => existingOrders.length === 0, [existingOrders]);

  const handleOrder = async () => {
    if (cartItems.length === 0) {
        alert('메뉴를 1개 이상 담아주세요.');
        return;
    }

    const currentOrderHasMainDish = cartItems.some(item => MAIN_CATEGORIES.includes(item.category));

    if (isFirstOrder && !currentOrderHasMainDish) {
      setIsRuleModalOpen(true);
      return;
    }

    setIsLoading(true);
    try {
        const newOrder = await customerApi.placeOrder(operatingDay, tableNumber, cartItems, orderRequest);
        onOrderPlaced(newOrder);
    } catch (e: any) {
        alert('주문에 실패했습니다: ' + e.message);
    } finally {
        setIsLoading(false);
    }
  };
  
  const [animateCart, setAnimateCart] = useState(false);
  const prevTotalItems = useRef<number>(0);
  useEffect(() => {
    if (totalItems !== prevTotalItems.current) {
        setAnimateCart(true);
        const timer = setTimeout(() => setAnimateCart(false), 400);
        return () => clearTimeout(timer);
    }
    prevTotalItems.current = totalItems;
  }, [totalItems]);

  const groupedMenu = useMemo(() => {
    const categories: MenuCategory[] = ['HEART 메인 (메인 안주 1)', 'WATT 메인 (메인 안주 2)', 'BEAT 사이드 (사이드 안주)', '기타 (라면 및 음료)'];
    return categories.map(category => ({
        category,
        items: menu.filter(item => item.category === category)
    })).filter(group => group.items.length > 0);
  }, [menu]);

  return (
    <div className="pb-32">
        {isLoading && (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center" aria-live="assertive">
                <Loading message="주문을 주방에 전달하는 중..." />
            </div>
        )}
         <style>{`
            @keyframes cart-bump { 0% { transform: scale(1); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
            .animate-cart-bump { animation: cart-bump 0.4s ease-out; }
        `}</style>
        <div className="sticky top-0 bg-white/80 dark:bg-black/70 backdrop-blur-xl z-20 py-4 -mx-4 px-4 transition-colors duration-300 border-b border-pink-100 dark:border-pink-500/20 shadow-sm shadow-pink-100/30 dark:shadow-black/20">
             <div className="relative flex justify-center items-center max-w-3xl mx-auto">
                <button onClick={onBack} className="absolute left-0 text-gray-600 dark:text-gray-300 font-bold p-2 transition-colors hover:text-rose-500 dark:hover:text-rose-400">{'<'} 현황</button>
                <div className="text-center">
                    <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100">HEART Beat WATT</h1>
                    <p className="font-semibold text-rose-600 dark:text-rose-400">테이블 {tableNumber}번</p>
                </div>
                <div className="absolute right-0">
                    <button 
                        onClick={() => setIsCartVisible(true)} 
                        disabled={isLoading}
                        className={`flex items-center justify-center rounded-full font-bold transition-all duration-300 ease-in-out transform disabled:opacity-70 disabled:cursor-not-allowed ${
                            totalItems > 0 
                            ? 'bg-gradient-to-br from-pink-500 to-rose-500 text-white shadow-lg shadow-rose-500/50 px-4 py-2 hover:-translate-y-1' 
                            : 'bg-white/95 dark:bg-gray-800/80 w-11 h-11'
                        }`}
                        aria-label={`장바구니 확인, ${totalItems}개 품목, 총 ${totalAmount}원`}
                    >
                        <div className="flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" 
                                className={`h-6 w-6 transition-colors ${totalItems > 0 ? 'text-white' : 'text-gray-700 dark:text-gray-200'}`} 
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                            <div className={`overflow-hidden transition-all duration-300 ease-in-out whitespace-nowrap text-sm ${totalItems > 0 ? 'max-w-40 ml-2' : 'max-w-0'}`}>
                                <span>{totalItems}개 · {totalAmount.toLocaleString()}원</span>
                            </div>
                        </div>
                    </button>
                </div>
            </div>
        </div>

        <div className="mt-4">
            {isFirstOrder ? (
                <div 
                    className="p-4 bg-yellow-100 dark:bg-yellow-900/40 rounded-2xl text-center border border-yellow-300 dark:border-yellow-700/50"
                    style={{ animation: 'fade-in-up 0.5s ease-out forwards', opacity: 0 }}
                >
                    <p className="font-bold text-yellow-800 dark:text-yellow-200">
                        💡 첫 주문 안내
                    </p>
                    <p className="mt-1 text-sm text-yellow-700 dark:text-yellow-300 leading-relaxed">
                        테이블의 첫 주문에는 메인 메뉴(HEART 또는 WATT)가 1개 이상 반드시 포함되어야 합니다. 추가 주문부터는 자유롭게 주문하실 수 있습니다.
                    </p>
                </div>
            ) : (
                <ExistingOrderSummary orders={existingOrders} />
            )}
        </div>
        
        <div className="mt-4 space-y-12">
            {groupedMenu.map(({ category, items }) => (
                <div key={category}>
                    <h2 className="text-xl font-bold text-gray-700 dark:text-gray-200 mb-4 bg-pink-100/50 dark:bg-pink-900/20 backdrop-blur-md rounded-2xl p-3 text-center">{category}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {items.map((item, itemIndex) => (
                            <div
                                key={item.id}
                                style={{ animation: 'fade-in-up 0.5s ease-out forwards', opacity: 0, animationDelay: `${itemIndex * 80}ms` }}
                            >
                                <MenuItemCard 
                                    item={item}
                                    quantity={cart[item.id]?.quantity || 0}
                                    onCartChange={handleCartChange}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>

        <div className={`fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-black/70 backdrop-blur-xl border-t border-rose-500/20 dark:border-rose-500/20 z-20 transition-transform duration-300 ${totalItems > 0 ? 'translate-y-0' : 'translate-y-full'}`}>
            <div className="max-w-3xl mx-auto">
                <Button onClick={handleOrder} isLoading={isLoading}>
                    {totalItems}개 · {totalAmount.toLocaleString()}원 주문하기
                </Button>
            </div>
        </div>

        <CartModal
            isOpen={isCartVisible}
            onClose={() => setIsCartVisible(false)}
            cart={cart}
            onCartChange={handleCartChange}
            onOrder={handleOrder}
            isLoading={isLoading}
            orderRequest={orderRequest}
            setOrderRequest={setOrderRequest}
        />
        
        <Modal isOpen={isRuleModalOpen} onClose={() => setIsRuleModalOpen(false)} title="첫 주문 안내">
            <p className="text-center text-gray-700 dark:text-gray-300 mb-4">
                첫 주문에는 메인 메뉴(HEART 또는 WATT)가 1개 이상 반드시 포함되어야 합니다.
            </p>
            <Button onClick={() => setIsRuleModalOpen(false)} variant="secondary">확인</Button>
        </Modal>
    </div>
  );
};
