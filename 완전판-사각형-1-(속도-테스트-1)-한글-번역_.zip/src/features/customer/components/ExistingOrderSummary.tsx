
import React from 'react';
import { Card } from '../../../shared/components/Card';
import { Order } from '../../../shared/types';
import { useOrderAggregation } from '../hooks/useOrderAggregation';

interface ExistingOrderSummaryProps {
    orders: Order[];
}

export const ExistingOrderSummary: React.FC<ExistingOrderSummaryProps> = ({ orders }) => {

    const { totalSpent, aggregatedItems } = useOrderAggregation(orders);

    return (
        <Card padding="p-0" style={{ animation: 'fade-in-up 0.5s ease-out forwards', opacity: 0 }}>
            <div className="p-4 bg-rose-50/70 dark:bg-gray-800/70 rounded-t-3xl">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white text-center">🧾 현재까지 주문 내역</h2>
            </div>
            <div className="bg-rose-50/40 dark:bg-gray-800/40 px-4 py-3 max-h-48 overflow-y-auto border-y border-rose-100 dark:border-gray-700/50">
                <div className="space-y-3">
                    {aggregatedItems.map(item => (
                        <div key={item.id} className="flex justify-between items-center text-sm">
                            <p className="text-gray-700 dark:text-gray-300">{item.name} <span className="font-mono text-gray-500 dark:text-gray-400">x{item.quantity}</span></p>
                            <p className="font-semibold text-gray-800 dark:text-gray-100">{(item.price * item.quantity).toLocaleString()}원</p>
                        </div>
                    ))}
                </div>
            </div>
            <div className="p-4">
                <div className="flex justify-between items-baseline">
                    <span className="text-lg font-bold text-gray-800 dark:text-gray-200">현재까지 총액</span>
                    <span className="text-2xl font-black text-rose-500 dark:text-rose-400">{totalSpent.toLocaleString()}원</span>
                </div>
            </div>
        </Card>
    );
};
