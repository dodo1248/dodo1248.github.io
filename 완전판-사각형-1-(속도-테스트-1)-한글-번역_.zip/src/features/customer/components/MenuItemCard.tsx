import React from 'react';
import { MenuItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';

const getMenuItemIcon = (itemName: string): string => {
    if (itemName.includes('골뱅이')) return '🥟';
    if (itemName.includes('두부대패김치')) return '🥩';
    if (itemName.includes('닭꼬치')) return '🍢';
    if (itemName.includes('치즈김치전')) return '🧀';
    if (itemName.includes('나쵸')) return '🌮';
    if (itemName.includes('콘치즈')) return '🌽';
    if (itemName.includes('꿀토마토')) return '🍅';
    if (itemName.includes('국물라면')) return '🍜';
    if (itemName.includes('불닭')) return '🔥';
    if (itemName.includes('콜라') || itemName.includes('사이다')) return '🥤';
    if (itemName.includes('물')) return '💧';
    return '🍴'; // Default icon
};

export const MenuItemCard: React.FC<{
    item: MenuItem;
    quantity: number;
    onCartChange: (item: MenuItem, quantity: number) => void;
}> = ({ item, quantity, onCartChange }) => {

    const quantityTextStyle: React.CSSProperties = {
        textShadow: '-1px -1px 0 #ef7490, 1px -1px 0 #ef7490, -1px 1px 0 #ef7490, 1px 1px 0 #ef7490'
    };
    
    const handleCartChangeWithFeedback = (item: MenuItem, quantity: number) => {
        if (navigator.vibrate) {
            navigator.vibrate(30);
        }
        onCartChange(item, quantity);
    };

    const iconGlowStyle: React.CSSProperties = quantity > 0 ? 
        { textShadow: '0 0 12px rgba(255, 255, 255, 0.8), 0 0 24px rgba(239, 116, 144, 0.9)' } : 
        { textShadow: '0 0 8px rgba(255, 255, 255, 0.5), 0 0 16px rgba(239, 116, 144, 0.7)' };

    return (
        <Card
            padding="p-4"
            className={`transition-all duration-300 relative ${item.isSoldOut ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-2xl hover:-translate-y-1'} ${quantity > 0 ? 'ring-2 ring-rose-500 shadow-lg shadow-rose-500/30' : ''}`}
        >
            <div className="flex space-x-4 items-center min-h-[6rem]">
                <div className="w-20 h-20 flex-shrink-0 flex items-center justify-center">
                    <span 
                        className="text-5xl transition-all duration-300"
                        style={iconGlowStyle}
                        aria-hidden="true"
                    >
                        {getMenuItemIcon(item.name)}
                    </span>
                </div>

                <div className="flex flex-col flex-grow justify-between self-stretch">
                    <div>
                        <h3 className="font-bold text-lg text-white leading-tight">{item.name}</h3>
                        <p className="text-gray-300 font-semibold text-md mt-1">{item.price.toLocaleString()}원</p>
                    </div>
                    
                    {!item.isSoldOut && (
                        <div className="flex items-center justify-end h-10 mt-2">
                            {quantity === 0 ? (
                                <button
                                    onClick={() => handleCartChangeWithFeedback(item, 1)}
                                    className="w-28 h-full rounded-full font-bold bg-rose-500 text-white hover:bg-rose-600 transition-colors"
                                    aria-label={`${item.name} 장바구니에 담기`}
                                >
                                  담기
                                </button>
                            ) : (
                                <div className="flex items-center justify-between w-28 h-full">
                                    <button
                                        onClick={() => handleCartChangeWithFeedback(item, quantity - 1)}
                                        className="w-10 h-10 rounded-full bg-gray-700 text-rose-300 text-2xl font-bold flex items-center justify-center transition-transform hover:scale-110"
                                        aria-label={`${item.name} 수량 줄이기`}
                                    >-</button>
                                    <span
                                        className="text-lg font-bold w-8 text-center tabular-nums text-white"
                                        style={quantityTextStyle}
                                    >{quantity}</span>
                                    <button
                                        onClick={() => handleCartChangeWithFeedback(item, quantity + 1)}
                                        className="w-10 h-10 rounded-full bg-rose-500 text-white text-2xl font-bold flex items-center justify-center transition-transform hover:scale-110"
                                        aria-label={`${item.name} 수량 늘리기`}
                                    >+</button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {item.isSoldOut && (
                <div className="absolute inset-0 bg-black/70 rounded-3xl flex items-center justify-center z-10">
                    <span className="text-white text-2xl font-black tracking-widest -rotate-12 border-4 border-white px-4 py-2 rounded-lg">품절</span>
                </div>
            )}
        </Card>
    );
};