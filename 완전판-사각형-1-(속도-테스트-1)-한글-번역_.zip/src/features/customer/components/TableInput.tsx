import React, { useState } from 'react';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { Logo } from '../../../shared/components/Logo';

export const TableInput: React.FC<{ onSubmit: (table: number) => void; onBack: () => void; isDarkMode: boolean; isLoading: boolean; }> = ({ onSubmit, onBack, isDarkMode, isLoading }) => {
    const [input, setInput] = useState('');
    const [error, setError] = useState<string | null>(null);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading) return;
        setError(null); // Reset error on new submission
        const num = parseInt(input, 10);
        if (isNaN(num) || num <= 0) {
            setError('유효한 테이블 번호를 입력해주세요.');
            return;
        }
        if (num > 60) { // Add validation for tables 1-60
            setError('테이블 번호는 1번부터 60번까지입니다.');
            return;
        }
        onSubmit(num);
    };
    
    return (
        <div className="flex flex-col items-center justify-center min-h-screen">
             <div className="w-full max-w-sm">
                <div className="w-full text-left mb-2">
                    <button onClick={onBack} className="text-gray-600 dark:text-gray-300 font-bold p-2 transition-colors hover:text-rose-500 dark:hover:text-rose-400">{'<'} 홈으로</button>
                </div>
                <div className="flex justify-center mb-4">
                    <Logo isDarkMode={isDarkMode} />
                </div>
                <Card className="w-full">
                    <form onSubmit={handleSubmit}>
                        <label htmlFor="table-number" className="block text-center text-lg font-bold text-gray-700 dark:text-gray-200 mb-4">
                            테이블 번호를 입력해주세요
                        </label>
                        <input
                            id="table-number"
                            type="number"
                            value={input}
                            onChange={(e) => {
                                setInput(e.target.value);
                                if (error) setError(null); // Clear error while typing
                            }}
                            className="w-full bg-white dark:bg-gray-700 text-gray-800 dark:text-white text-center text-2xl p-4 border-2 border-pink-200 dark:border-gray-600 rounded-2xl focus:ring-0 focus:border-rose-500 dark:focus:border-rose-400 focus:shadow-[0_0_15px_rgba(239,116,144,0.4)] outline-none transition-all duration-300 disabled:opacity-70"
                            placeholder="예: 5"
                            autoFocus
                            disabled={isLoading}
                        />
                        {error && <p className="text-red-500 text-center mt-3 text-sm font-semibold">{error}</p>}
                        <Button type="submit" className="mt-6" isLoading={isLoading}>{isLoading ? '확인 중...' : '주문 시작'}</Button>
                    </form>
                </Card>
            </div>
        </div>
    );
};