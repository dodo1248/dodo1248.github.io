
import React, { useState, useEffect } from 'react';
import { Modal } from '../../../shared/components/Modal';

interface CallStaffModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCall: (reason: string) => void;
    isLoading: boolean;
}

export const CallStaffModal: React.FC<CallStaffModalProps> = ({ isOpen, onClose, onCall, isLoading }) => {
    const callReasons = ["기본 안주 리필", "수저/앞접시 요청", "냅킨/물티슈 요청", "기타 문의/메뉴판"];
    const [clickedReason, setClickedReason] = useState<string | null>(null);

    const handleCallClick = (reason: string) => {
        setClickedReason(reason);
        onCall(reason);
    };

    useEffect(() => {
        if (!isOpen) {
            setClickedReason(null);
        }
    }, [isOpen]);
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="스태프 호출">
            <p className="text-center text-gray-600 dark:text-gray-300 mb-6">필요한 서비스를 선택해주세요.</p>
            <div className="grid grid-cols-2 gap-4">
                {callReasons.map(reason => (
                    <button 
                        key={reason}
                        onClick={() => handleCallClick(reason)}
                        disabled={isLoading}
                        className="p-4 bg-rose-100/60 dark:bg-gray-800/60 border-2 border-rose-300 dark:border-gray-600 rounded-2xl text-center font-bold text-rose-700 dark:text-rose-200 transition-all hover:bg-rose-100 hover:border-rose-400 dark:hover:bg-gray-700/80 disabled:opacity-50 disabled:cursor-wait min-h-[72px] flex items-center justify-center"
                    >
                        {isLoading && clickedReason === reason ? (
                            <svg className="animate-spin h-6 w-6 text-rose-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="http://www.w3.org/2000/svg">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : (
                            reason
                        )}
                    </button>
                ))}
            </div>
        </Modal>
    )
}