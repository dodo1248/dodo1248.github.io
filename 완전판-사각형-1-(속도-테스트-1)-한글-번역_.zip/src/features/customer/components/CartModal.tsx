

import React from 'react';
import { Cart, CartItem, MenuItem } from '../../../shared/types';
import { Modal } from '../../../shared/components/Modal';
import { Button } from '../../../shared/components/Button';
import { MAX_ORDER_REQUEST_LENGTH } from '../../../shared/constants';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: Cart;
  onCartChange: (item: Pick<MenuItem, 'id' | 'name' | 'price' | 'category'>, quantity: number) => void;
  onOrder: () => void;
  isLoading: boolean;
  orderRequest: string;
  setOrderRequest: (req: string) => void;
}

export const CartModal: React.FC<CartModalProps> = ({ isOpen, onClose, cart, onCartChange, onOrder, isLoading, orderRequest, setOrderRequest }) => {
  const cartItems: CartItem[] = Object.values(cart);
  const totalAmount = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const footerContent = (
      <div>
          <div className="flex justify-between items-center mb-4">
              <span className="font-bold text-lg text-gray-700 dark:text-gray-200">총 주문 금액</span>
              <span className="font-black text-2xl text-rose-500 dark:text-rose-400">{totalAmount.toLocaleString()}원</span>
          </div>
          <Button onClick={onOrder} isLoading={isLoading}>
              {`${totalAmount.toLocaleString()}원 주문하기`}
          </Button>
      </div>
  );

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title="장바구니"
        footer={cartItems.length > 0 ? footerContent : undefined}
    >
        {cartItems.length === 0 ? (
            <p className="text-center text-gray-500 dark:text-gray-400 py-8">장바구니에 담긴 메뉴가 없습니다.</p>
        ) : (
            <div className="space-y-4">
                <div className="space-y-4">
                    {cartItems.map(item => (
                        <div key={item.id} className="flex items-center justify-between">
                             <div>
                                <p className="font-bold text-gray-800 dark:text-gray-100">{item.name}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">{(item.price * item.quantity).toLocaleString()}원</p>
                            </div>
                            <div className="flex items-center space-x-3">
                                <button onClick={() => onCartChange(item, item.quantity - 1)} className="w-8 h-8 rounded-full bg-rose-100 dark:bg-gray-700 text-rose-600 dark:text-rose-300 text-2xl font-bold flex items-center justify-center">-</button>
                                <span className="text-lg font-bold w-6 text-center dark:text-white">{item.quantity}</span>
                                <button onClick={() => onCartChange(item, item.quantity + 1)} className="w-8 h-8 rounded-full bg-rose-500 text-white text-2xl font-bold flex items-center justify-center">+</button>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="pt-4 border-t border-rose-500/20 dark:border-rose-800/50">
                    <label htmlFor="order-request" className="block text-sm font-bold text-gray-700 dark:text-gray-200 mb-2">요청사항</label>
                    <textarea
                        id="order-request"
                        value={orderRequest}
                        onChange={(e) => setOrderRequest(e.target.value)}
                        className="w-full bg-white dark:bg-gray-800 text-gray-800 dark:text-white p-2 border-2 border-pink-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-rose-500 outline-none transition-colors duration-300"
                        placeholder={`예: 덜 맵게 해주세요 (최대 ${MAX_ORDER_REQUEST_LENGTH}자)`}
                        maxLength={MAX_ORDER_REQUEST_LENGTH}
                        rows={2}
                    />
                </div>
            </div>
        )}
    </Modal>
  );
}