import React, { useState } from 'react';
import { PaymentInfo, Order } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';
import { Button } from '../../../shared/components/Button';
import { STORAGE_KEYS } from '../../../shared/constants';

export const OrderPlaced: React.FC<{
    onConfirm: () => void;
    paymentInfo: PaymentInfo;
    order: Order;
}> = ({ onConfirm, paymentInfo, order }) => {
    const [isDepositConfirmed, setIsDepositConfirmed] = useState(false);

    const handleCopy = async () => {
        try {
            await navigator.clipboard.writeText(paymentInfo.accountNumber);
            alert('계좌번호가 복사되었습니다!');
        } catch (err) {
            console.error('Failed to copy: ', err);
            alert('계좌번호 복사에 실패했습니다.');
        }
    };
    
    const handleConfirmClick = () => {
        sessionStorage.removeItem(STORAGE_KEYS.LATEST_ORDER);
        onConfirm();
    };

    const qrCodeImageUrl = paymentInfo.qrCodeUrl;

    if (isDepositConfirmed) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen text-center animate-fade-in p-4">
                <Card className="w-full max-w-md p-4 sm:p-6">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/40 rounded-2xl mb-4 text-center">
                        <h2 className="text-xl font-bold text-blue-800 dark:text-blue-200">👍 입금 확인 요청 완료!</h2>
                    </div>
                    
                    <div className="my-6 space-y-4">
                        <p className="text-gray-700 dark:text-gray-300 text-lg leading-relaxed">
                            스태프가 곧 자리로 찾아가<br/>입금 내역을 확인할 예정입니다.
                        </p>
                        <div className="p-4 bg-yellow-100 dark:bg-yellow-900/40 rounded-xl text-yellow-800 dark:text-yellow-200 font-bold">
                            <p>은행 앱의 '입금 완료' 화면을</p>
                            <p>미리 준비해주세요!</p>
                        </div>
                    </div>

                    <Button onClick={handleConfirmClick} variant="primary">
                        내 주문 현황 보기
                    </Button>
                </Card>
            </div>
        );
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen text-center animate-fade-in p-4">
            <Card className="w-full max-w-md p-4 sm:p-6">
                <div className="p-3 bg-green-100 dark:bg-green-900/40 rounded-2xl mb-4 text-center">
                    <h2 className="text-xl font-bold text-green-800 dark:text-green-200">✅ 주문 접수 완료!</h2>
                    <p className="text-sm text-green-700 dark:text-green-300 mt-1">아래 정보로 입금 후, 완료 버튼을 눌러주세요.</p>
                </div>
                
                <div className="flex flex-col items-center space-y-3 my-5">
                    <div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">입금하실 금액</p>
                        <p className="text-3xl font-black text-rose-500 dark:text-rose-400">{order.totalPrice.toLocaleString()}원</p>
                    </div>
                    
                    <img 
                        src={qrCodeImageUrl} 
                        alt="결제 QR 코드" 
                        className="w-32 h-32 mx-auto rounded-lg shadow-md bg-white"
                    />
                    
                    <button 
                        onClick={handleCopy} 
                        className="flex items-center justify-between bg-gray-100 dark:bg-gray-700 p-3 rounded-lg w-full max-w-xs transition-colors hover:bg-gray-200 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-rose-400"
                    >
                        <span className="font-bold text-base text-gray-700 dark:text-gray-200 text-left flex-1 break-words">
                            {paymentInfo.accountNumber}
                        </span>
                        <div className="flex items-center text-pink-600 dark:text-pink-300 flex-shrink-0 ml-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                              <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z" />
                              <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h6a2 2 0 00-2-2H5z" />
                            </svg>
                            <span className="font-bold text-sm">복사</span>
                        </div>
                    </button>
                </div>

                <div className="mt-5 pt-4 border-t border-pink-200/50 dark:border-rose-800/50">
                    <Button onClick={() => setIsDepositConfirmed(true)} variant="primary" glow={true}>
                        입금 완료했어요
                    </Button>
                </div>
            </Card>
        </div>
    );
}