
import React from 'react';
import { Order, OrderStatus, CartItem } from '../../../shared/types';
import { Card } from '../../../shared/components/Card';

interface CustomerOrderCardProps {
  order: Order;
  onReorder: (item: CartItem) => void;
}

const orderStatusToKorean: Record<OrderStatus, string> = {
  [OrderStatus.PENDING_PAYMENT]: '결제 대기 중',
  [OrderStatus.PAYMENT_SUBMITTED]: '결제 확인 중',
  [OrderStatus.PAYMENT_CONFIRMED]: '주문 접수',
  [OrderStatus.IN_KITCHEN]: '조리 중',
  [OrderStatus.READY_TO_SERVE]: '준비 완료',
  [OrderStatus.SERVED]: '서빙 완료',
  [OrderStatus.CANCELLED]: '주문 취소',
};

const ItemStatusIcon: React.FC<{ status: OrderStatus }> = ({ status }) => {
    switch (status) {
        case OrderStatus.PAYMENT_SUBMITTED:
            return <span title={orderStatusToKorean[OrderStatus.PAYMENT_SUBMITTED]} className="text-lg">📄</span>;
        case OrderStatus.PAYMENT_CONFIRMED:
            return <span title={orderStatusToKorean[OrderStatus.PAYMENT_CONFIRMED]} className="text-lg">👍</span>;
        case OrderStatus.IN_KITCHEN:
            return <span title={orderStatusToKorean[OrderStatus.IN_KITCHEN]} className="text-lg animate-pulse">🍳</span>;
        case OrderStatus.READY_TO_SERVE:
            return <span title={orderStatusToKorean[OrderStatus.READY_TO_SERVE]} className="text-lg">🎁</span>;
        case OrderStatus.SERVED:
            return <span title={orderStatusToKorean[OrderStatus.SERVED]} className="text-lg">✅</span>;
        default:
            return null;
    }
};

const getOverallProgress = (items: CartItem[] = []) => {
    if (items.length === 0) return 0;
    
    const statusWeight: Record<OrderStatus, number> = {
        [OrderStatus.PENDING_PAYMENT]: 0,
        [OrderStatus.PAYMENT_SUBMITTED]: 0.1,
        [OrderStatus.PAYMENT_CONFIRMED]: 0.2,
        [OrderStatus.IN_KITCHEN]: 0.5,
        [OrderStatus.READY_TO_SERVE]: 0.8,
        [OrderStatus.SERVED]: 1.0,
        [OrderStatus.CANCELLED]: 0,
    };

    const totalWeight = items.reduce((acc, item) => acc + (statusWeight[item.status!] || 0), 0);
    return (totalWeight / items.length) * 100;
};


export const CustomerOrderCard: React.FC<CustomerOrderCardProps> = React.memo(({ order, onReorder }) => {
  const isAllServed = order.items.every(i => i.status === OrderStatus.SERVED);
  const progress = getOverallProgress(order.items);

  if (isAllServed) {
    return (
      <Card className="bg-gray-50/80 dark:bg-gray-800/70">
        <div className="flex justify-between items-center mb-2">
          <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(order.timestamp).toLocaleString()}</p>
          <div className="flex items-center space-x-1 text-green-600 dark:text-green-400 font-bold text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>모두 서빙 완료</span>
          </div>
        </div>
        <ul className="divide-y divide-pink-500/10 dark:divide-gray-700/50">
          {order.items.map(item => (
            <li key={item.uniqueId} className="flex justify-between items-center py-2 gap-4">
              <div className="flex-grow min-w-0">
                <p className="text-gray-700 dark:text-gray-300 font-medium">{item.name} x{item.quantity}</p>
                <p className="text-gray-500 dark:text-gray-400 text-sm">{(item.price * item.quantity).toLocaleString()}원</p>
              </div>
              <button
                onClick={() => onReorder(item)}
                className="px-4 py-2 text-base bg-rose-100 dark:bg-gray-700 text-rose-600 dark:text-rose-300 font-bold rounded-full hover:bg-rose-200 dark:hover:bg-gray-600 transition-all hover:scale-105 active:scale-95 flex-shrink-0"
              >
                다시 담기
              </button>
            </li>
          ))}
        </ul>
        <div className="flex justify-between pt-2 mt-2 border-t border-pink-500/20 dark:border-gray-700/60">
          <span className="font-bold text-lg text-gray-800 dark:text-gray-100">총 금액</span>
          <span className="font-bold text-lg text-rose-500 dark:text-rose-400">{order.totalPrice.toLocaleString()}원</span>
        </div>
      </Card>
    )
  }

  // Active Order Card
  return (
    <Card>
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <p className="font-bold text-lg text-rose-500 dark:text-rose-400">{orderStatusToKorean[order.status]}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(order.timestamp).toLocaleString()}</p>
        </div>
        <div className="overflow-hidden h-2 text-xs flex rounded bg-pink-200 dark:bg-gray-700">
          <div style={{ width: `${progress}%` }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-gradient-to-r from-pink-400 to-rose-500 transition-all duration-500"></div>
        </div>
      </div>

      <ul className="divide-y divide-pink-500/10 dark:divide-gray-700/50">
        {order.items.map(item => (
          <li key={item.uniqueId} className="flex justify-between items-center py-2">
            <div className="flex items-center space-x-3">
                <ItemStatusIcon status={item.status!} />
                <span className="text-gray-700 dark:text-gray-300">{item.name} x{item.quantity}</span>
            </div>
            <span className="font-medium text-gray-800 dark:text-gray-100">{(item.price * item.quantity).toLocaleString()}원</span>
          </li>
        ))}
      </ul>
      <div className="flex justify-between pt-2 mt-2 border-t border-pink-500/20 dark:border-gray-700/60">
        <span className="font-bold text-lg text-gray-800 dark:text-gray-100">총 금액</span>
        <span className="font-bold text-lg text-rose-500 dark:text-rose-400">{order.totalPrice.toLocaleString()}원</span>
      </div>
      {order.status === OrderStatus.PAYMENT_SUBMITTED && (
        <div className="mt-4 pt-4 border-t border-pink-100 dark:border-gray-700/50">
          <button
            onClick={() => alert("주문 취소는 스태프에게 직접 문의해주세요.")}
            className="w-full text-center py-2 text-sm text-red-500 dark:text-red-400 font-bold rounded-lg border-2 border-red-300 dark:border-red-500/50 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
          >
            주문 취소 문의
          </button>
        </div>
      )}
    </Card>
  );
});
